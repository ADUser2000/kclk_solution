# identity/keycloak-user-logs-spi

## Getting Started

Download links:

SSH clone URL: ssh://git@git.jetbrains.space/comm-itpro/identity/keycloak-user-logs-spi.git

HTTPS clone URL: https://git.jetbrains.space/comm-itpro/identity/keycloak-user-logs-spi.git

## How to add and configure spi in keycloak (using docker-compose)

1. Prepare docker-compose file for keycloak. Preferred keycloak image is quay.io/keycloak/keycloak:24.0.5
2. Build the spi project using Gradle (gradle clean jar)
3. Add obtained jar file to /opt/keycloak/providers/ as volume to your keycloak docker container:
```
volumes:
  - "./keycloak-user-logs-spi/build/libs/keycloak-user-logs-spi-1.0-SNAPSHOT.jar:/opt/keycloak/providers/keycloak-user-logs-spi-1.0-SNAPSHOT.jar"
```
4. keycloak-user-logs-spi provides advanced logging for user-info via custom endpoint. 
It is available at: /realms/{realm}/user-info-endpoint. An auth token is required in the request header.