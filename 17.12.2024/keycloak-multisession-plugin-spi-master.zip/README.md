# identity/keycloak-multisession-plugin-spi



## Getting Started

Download links:

SSH clone URL: ssh://git@git.jetbrains.space/comm-itpro/identity/keycloak-multisession-plugin-spi.git

HTTPS clone URL: https://git.jetbrains.space/comm-itpro/identity/keycloak-multisession-plugin-spi.git



These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

## Prerequisites

What things you need to install the software and how to install them.

```
Examples
```

## Deployment

Add additional notes about how to deploy this on a production system.

## Resources

Add links to external resources for this project, such as CI server, bug tracker, etc.
