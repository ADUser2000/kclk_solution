package ru.mkb.event.listener.provider;

import java.util.stream.Collectors;
import lombok.extern.java.Log;
import org.keycloak.events.Event;
import org.keycloak.events.EventListenerProvider;
import org.keycloak.events.EventType;
import org.keycloak.events.admin.AdminEvent;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.models.UserSessionModel;
import org.keycloak.models.UserSessionProvider;

@Log
public class SingleLoginProvider implements EventListenerProvider {

  private static final String ATTR_REMOVED_SESSIONS = "removed-sessions";

  private final KeycloakSession session;
  private final UserSessionProvider userSessionProvider;

  public SingleLoginProvider(KeycloakSession session) {
    this.session = session;
    this.userSessionProvider = session.getProvider(UserSessionProvider.class);
  }

  @Override
  public void onEvent(Event event) {
    if (EventType.LOGIN == event.getType()) {
      var realm = session.realms().getRealm(event.getRealmId());
      var user = session.users().getUserById(realm, event.getUserId());

      if (user != null) {
        handleLogin(realm, user, event.getSessionId());
      }
    }
  }

  @Override
  public void onEvent(AdminEvent event, boolean includeRepresentation) {

  }

  @Override
  public void close() {

  }

  private void handleLogin(RealmModel realmModel, UserModel userModel, String currentSessionId) {
    userModel.removeAttribute(ATTR_REMOVED_SESSIONS);
    var res = userSessionProvider.getUserSessionsStream(realmModel, userModel)
        .filter(it -> !it.getId().equals(currentSessionId))
        .peek(it -> removeSession(realmModel, it))
        .map(UserSessionModel::getId)
        .collect(Collectors.toList());
    userModel.setAttribute(ATTR_REMOVED_SESSIONS, res);
  }

  private void removeSession(RealmModel realmModel, UserSessionModel sessionModel) {
    userSessionProvider.removeUserSession(realmModel, sessionModel);
  }
}