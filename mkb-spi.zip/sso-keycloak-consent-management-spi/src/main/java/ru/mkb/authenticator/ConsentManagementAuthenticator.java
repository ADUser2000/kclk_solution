package ru.mkb.authenticator;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.ConsentManagementAuthenticatorFactory;
import ru.mkb.dto.ConsentServiceDto;
import ru.mkb.exception.ConsentServiceException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import static jakarta.ws.rs.core.Response.Status;
import static ru.mkb.dto.ConsentServiceDto.ConsentData;
import static ru.mkb.dto.UserIdentityDto.CryptoProfileResponse;
import static ru.mkb.dto.UserIdentityDto.DocumentActionRequest;
import static ru.mkb.dto.UserIdentityDto.DocumentActionResponse;
import static ru.mkb.dto.UserIdentityDto.DocumentInfo;

public class ConsentManagementAuthenticator implements Authenticator {

    private static final HttpClient httpClient = HttpClient.newBuilder().version(HttpClient.Version.HTTP_2).build();
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        Map<String, String> config = context.getAuthenticatorConfig().getConfig();
        if (config == null) {
            context.failure(AuthenticationFlowError.INTERNAL_ERROR, context
                    .form().setError("Authenticator not configured.")
                    .createErrorPage(Status.INTERNAL_SERVER_ERROR));
            return;
        }
        String username = config.get(ConsentManagementAuthenticatorFactory.CONF_BASIC_AUTH_USER);
        String password = config.get(ConsentManagementAuthenticatorFactory.CONF_BASIC_AUTH_PASSWORD);
        String consentUrl = config.get(ConsentManagementAuthenticatorFactory.CONF_CONSENTS_SERVICE_URL);
        String userIdentityUrl = config.get(ConsentManagementAuthenticatorFactory.CONF_USER_IDENTITY_URL);

        if (userIdentityUrl == null || userIdentityUrl.isBlank() || consentUrl == null|| consentUrl.isBlank()
                || username == null || username.isBlank() || password == null) {
            context.failure(AuthenticationFlowError.INTERNAL_ERROR, context
                    .form().setError("Basic Auth credentials are not configured for the authenticator.")
                    .createErrorPage(Status.INTERNAL_SERVER_ERROR));
            return;
        }

        String authValue = username + ":" + password;
        String basicAuthHeader = "Basic " + Base64.getEncoder().encodeToString(authValue.getBytes(StandardCharsets.UTF_8));

        UserModel user = context.getUser();
        String consentId = context.getAuthenticationSession().getClientNote("consent_id");
        String inn = context.getAuthenticationSession().getClientNote("inn");
        String kpp = context.getAuthenticationSession().getClientNote("kpp");
        String personSsoId = user.getId();
        String clientId = context.getAuthenticationSession().getClient().getClientId();

        try {
            ConsentData consentData = getConsentData(consentId, inn, kpp, personSsoId, clientId, basicAuthHeader, consentUrl);

            if (consentData == null || consentData.organization() == null || consentData.official() == null) {
                context.failure(AuthenticationFlowError.INVALID_CREDENTIALS,
                        context.form().setError("Не удалось получить данные о согласии.")
                                .createErrorPage(Status.BAD_REQUEST));
                return;
            }

            String organizationId = consentData.organization().organizationId();
            String officialId = consentData.official().officialId();

            CryptoProfileResponse cryptoProfiles = getCryptoProfiles(officialId, organizationId, userIdentityUrl);
            DocumentActionResponse documentActions = getDocumentActions(officialId, organizationId, userIdentityUrl);

            if (documentActions == null || documentActions.result().actions().isEmpty() || !documentActions.result().actions().get(0).canSign()) {
                context.failure(AuthenticationFlowError.ACCESS_DENIED,
                        context.form().setError("Подписание данного согласия невозможно.")
                                .createErrorPage(Status.BAD_REQUEST));
                return;
            }

            context.getAuthenticationSession().setAuthNote("consentDataJson", objectMapper.writeValueAsString(consentData));
            context.getAuthenticationSession().setAuthNote("cryptoProfilesJson", objectMapper.writeValueAsString(cryptoProfiles));
            context.getAuthenticationSession().setAuthNote("consentId", consentId);

            context.success();

        } catch (Exception e) {
            context.failure(AuthenticationFlowError.INTERNAL_ERROR,
                    context.form().setError("Внутренняя ошибка сервера при обработке согласия.")
                            .createErrorPage(Status.INTERNAL_SERVER_ERROR));
        }
    }

    private ConsentData getConsentData(String consentId, String inn, String kpp, String personSsoId, String clientId, String authHeader, String baseUrl) throws Exception {
        String url = String.format("%s/consents/%s?inn=%s&personSsoId=%s&clientId=%s" + (kpp != null ? "&kpp=%s" : ""),
                baseUrl, consentId, inn, personSsoId, clientId, kpp);

        HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .uri(URI.create(url))
                .header("X-Correlation-Id", UUID.randomUUID().toString())
                .header("Authorization", authHeader)
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            try {
                ConsentServiceDto.ErrorResponse errorResponse = objectMapper.readValue(response.body(), ConsentServiceDto.ErrorResponse.class);
                throw new ConsentServiceException(
                        errorResponse.error().message(),
                        errorResponse.error().code()
                );
            } catch (Exception parseException) {
                throw new RuntimeException("Consents service returned status " + response.statusCode());
            }
        }

        return objectMapper.readValue(response.body(), ConsentData.class);
    }

    private CryptoProfileResponse getCryptoProfiles(String officialId, String organizationId, String baseUrl) throws Exception {
        String url = String.format("%s/api/v1/signing/crypto-profiles?officialId=%s&organizationId=%s&documentTypeCode=ACCOUNTS_CONSENT",
                baseUrl, officialId, organizationId);

        HttpRequest request = HttpRequest.newBuilder().GET().uri(URI.create(url)).build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        return objectMapper.readValue(response.body(), CryptoProfileResponse.class);
    }

    private DocumentActionResponse getDocumentActions(String officialId, String organizationId, String baseUrl) throws Exception {
        String url = String.format("%s/api/v1/signing/documents/actions", baseUrl);

        DocumentActionRequest requestBody =
                new DocumentActionRequest("ACCOUNTS_CONSENT", Collections.singletonList(new DocumentInfo()));

        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(requestBody)))
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("officialId", officialId)
                .header("organizationId", organizationId)
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        return objectMapper.readValue(response.body(), DocumentActionResponse.class);
    }


    @Override
    public void action(AuthenticationFlowContext context) {
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}
