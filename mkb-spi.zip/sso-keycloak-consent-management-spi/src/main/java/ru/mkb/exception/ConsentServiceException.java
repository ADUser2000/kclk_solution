package ru.mkb.exception;

import lombok.Getter;

@Getter
public class ConsentServiceException extends Exception {
    private final String errorCode;
    public ConsentServiceException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
}
