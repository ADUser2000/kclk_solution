package ru.mkb.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class UserIdentityDto {
    private UserIdentityDto() {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CryptoProfileResponse(
            String error,
            CryptoProfileResult result
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CryptoProfileResult(
            @JsonProperty("cryptoProfiles") List<CryptoProfile> cryptoProfiles
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CryptoProfile(
            String cryptoProfileId,
            String profileType,
            List<Certificate> certificates
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Certificate(
            String id,
            String certType,
            String certificateNumber
    ) {}


    public record DocumentActionRequest(
            String documentType,
            List<DocumentInfo> documents
    ) {}

    public record DocumentInfo(String documentId, Float amount, String accountNumber) {
        public DocumentInfo() {
            this(null, null, null);
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record DocumentActionResponse(
            String error,
            String description,
            ActionResult result
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ActionResult(
            List<Action> actions
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Action(
            String documentId,
            boolean canSign,
            boolean canRevokeSign,
            boolean canSendAfterSign,
            boolean canCancelProcessSign
    ) {}
}
