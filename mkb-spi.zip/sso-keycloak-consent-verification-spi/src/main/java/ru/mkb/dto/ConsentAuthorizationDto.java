package ru.mkb.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class ConsentAuthorizationDto {
    private ConsentAuthorizationDto() {}

    public record AuthorizeRequest(
            String message,
            String signature,
            String organizationId,
            String officialId,
            String clientId
    ) {}

    public record AuthorizeResponse(
            String consentId,
            String status
    ) {}

    public record AuthorizeErrorResponse(
            String code,
            String message
    ) {}
}
