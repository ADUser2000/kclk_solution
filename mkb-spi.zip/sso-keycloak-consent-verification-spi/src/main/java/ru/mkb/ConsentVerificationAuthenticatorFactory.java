package ru.mkb;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.authenticator.ConsentVerificationAuthenticator;

import java.util.Arrays;
import java.util.List;

public class ConsentVerificationAuthenticatorFactory implements AuthenticatorFactory {

    public static final String PROVIDER_ID = "sso-keycloak-consent-verification-spi";

    public static final String CONF_CONSENTS_URL = "consents.service.url";
    public static final String CONF_BASIC_AUTH_USER = "basic.auth.user";
    public static final String CONF_BASIC_AUTH_PASSWORD = "basic.auth.password";

    @Override
    public String getId() { return PROVIDER_ID; }

    @Override
    public Authenticator create(KeycloakSession session) {
        return new ConsentVerificationAuthenticator();
    }

    @Override
    public String getDisplayType() { return "SSO Consent: Verification"; }

    @Override
    public String getHelpText() { return "Verifies the signed consent by sending it to the Consents Service."; }

    @Override
    public boolean isConfigurable() { return true; }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return Arrays.asList(
                new ProviderConfigProperty(CONF_CONSENTS_URL, "Consents Service Base URL", "...", ProviderConfigProperty.STRING_TYPE, null),
                new ProviderConfigProperty(CONF_BASIC_AUTH_USER, "Basic Auth Username", "...", ProviderConfigProperty.STRING_TYPE, null),
                new ProviderConfigProperty(CONF_BASIC_AUTH_PASSWORD, "Basic Auth Password", "...", ProviderConfigProperty.PASSWORD, null)
        );
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return new AuthenticationExecutionModel.Requirement[] {
                AuthenticationExecutionModel.Requirement.REQUIRED,
                AuthenticationExecutionModel.Requirement.DISABLED
        };
    }

    @Override
    public boolean isUserSetupAllowed() { return false; }
    @Override
    public String getReferenceCategory() { return "sso-consent"; }
    @Override
    public void init(Config.Scope config) {}
    @Override
    public void postInit(KeycloakSessionFactory factory) {}
    @Override
    public void close() {}
}