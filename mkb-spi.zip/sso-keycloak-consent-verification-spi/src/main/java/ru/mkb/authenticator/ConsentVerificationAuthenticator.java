package ru.mkb.authenticator;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.ConsentVerificationAuthenticatorFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import static jakarta.ws.rs.core.Response.Status;
import static ru.mkb.dto.ConsentAuthorizationDto.AuthorizeErrorResponse;
import static ru.mkb.dto.ConsentAuthorizationDto.AuthorizeRequest;
import static ru.mkb.dto.ConsentAuthorizationDto.AuthorizeResponse;
import static ru.mkb.dto.ConsentServiceDto.ConsentData;

@Log
public class ConsentVerificationAuthenticator implements Authenticator {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final HttpClient httpClient = HttpClient.newHttpClient();

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        String consentId = context.getAuthenticationSession().getAuthNote("consentId");
        String consentDataJson = context.getAuthenticationSession().getAuthNote("consentDataJson");
        String messageBase64 = context.getAuthenticationSession().getAuthNote("consentMessageBase64");
        String signature = context.getAuthenticationSession().getAuthNote("consentSignature");
        String clientId = context.getAuthenticationSession().getClient().getClientId();

        if (consentId == null || consentDataJson == null || messageBase64 == null || signature == null) {
            context.failure(AuthenticationFlowError.INTERNAL_ERROR, context.
                    form().setError("Отсутствуют полные данные для верификации согласия.").createErrorPage(Status.INTERNAL_SERVER_ERROR));
            return;
        }

        try {
            ConsentData consentData = objectMapper.readValue(consentDataJson, ConsentData.class);

            AuthorizeRequest requestBody = new AuthorizeRequest(
                    messageBase64,
                    signature,
                    consentData.organization().organizationId(),
                    consentData.official().officialId(),
                    clientId
            );

            authorizeConsentInService(context, consentId, requestBody);

            context.getAuthenticationSession().setUserSessionNote("consentId", consentId);

            context.success();

        } catch (Exception e) {
            log.warning("Consent verification failed: " + e.getMessage());
            context.failure(AuthenticationFlowError.INVALID_CREDENTIALS, context.
                    form().setError("Не удалось проверить подпись согласия. " + e.getMessage()).createErrorPage(Status.BAD_REQUEST));
        }
    }

    private void authorizeConsentInService(AuthenticationFlowContext context, String consentId, AuthorizeRequest requestBody) throws Exception {
        Map<String, String> config = context.getAuthenticatorConfig().getConfig();
        if (config == null) throw new IllegalStateException("Authenticator is not configured.");

        String consentsUrl = config.get(ConsentVerificationAuthenticatorFactory.CONF_CONSENTS_URL);
        String username = config.get(ConsentVerificationAuthenticatorFactory.CONF_BASIC_AUTH_USER);
        String password = config.get(ConsentVerificationAuthenticatorFactory.CONF_BASIC_AUTH_PASSWORD);
        if (consentsUrl == null || username == null || password == null) {
            throw new IllegalStateException("Authenticator is not fully configured.");
        }

        String authValue = username + ":" + password;
        String basicAuthHeader = "Basic " + Base64.getEncoder().encodeToString(authValue.getBytes(StandardCharsets.UTF_8));
        String bodyJson = objectMapper.writeValueAsString(requestBody);

        String url = String.format("%s/consent/authorize/%s", consentsUrl, consentId);
        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(bodyJson))
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("Authorization", basicAuthHeader)
                .header("X-Correlation-Id", UUID.randomUUID().toString())
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            String errorMessage = "Verification failed with status: " + response.statusCode();
            try {
                AuthorizeErrorResponse error = objectMapper.readValue(response.body(), AuthorizeErrorResponse.class);
                errorMessage += ". Message: " + error.message();
            } catch (Exception parseException) {
                errorMessage += ". Body: " + response.body();
            }
            throw new RuntimeException(errorMessage);
        }

        AuthorizeResponse successResponse = objectMapper.readValue(response.body(), AuthorizeResponse.class);
        log.info("Consent " + successResponse.consentId() + " successfully authorized with status " + successResponse.status());
    }

    @Override
    public void action(AuthenticationFlowContext context) {
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}
