package ru.mkb.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

public enum Permission {
    READ_ACCOUNTS_BASIC("ReadAccountsBasic", "Просмотр основной информации по счетам"),
    READ_ACCOUNTS_DETAIL("ReadAccountsDetail", "Просмотр детальной информации по счетам"),
    READ_BALANCES("ReadBalances", "Просмотр балансов"),
    READ_PARTY("ReadParty", "Просмотр информации о стороне"),
    READ_PRODUCTS("ReadProducts", "Просмотр информации о продуктах"),
    READ_STANDING_ORDERS_BASIC("ReadStandingOrdersBasic", "Просмотр основной информации о регулярных платежах"),
    READ_STANDING_ORDERS_DETAIL("ReadStandingOrdersDetail", "Просмотр детальной информации о регулярных платежах"),
    READ_TRANSACTIONS_BASIC("ReadTransactionsBasic", "Просмотр основной информации по транзакциям"),
    READ_TRANSACTIONS_CREDITS("ReadTransactionsCredits", "Просмотр кредитовых транзакций"),
    READ_TRANSACTIONS_DEBITS("ReadTransactionsDebits", "Просмотр дебетовых транзакций"),
    READ_TRANSACTIONS_DETAIL("ReadTransactionsDetail", "Просмотр детальной информации по транзакциям"),
    READ_PAYMENT_CARDS("ReadPaymentCards", "Просмотр информации о платежных картах"),
    UNKNOWN("Unknown", "Неизвестное разрешение");

    private final String jsonValue;
    @Getter
    private final String description;

    Permission(String jsonValue, String description) {
        this.jsonValue = jsonValue;
        this.description = description;
    }

    @JsonValue
    public String getJsonValue() {
        return jsonValue;
    }

    @JsonCreator
    public static Permission fromValue(String value) {
        return Stream.of(Permission.values())
                .filter(p -> p.jsonValue.equalsIgnoreCase(value))
                .findFirst()
                .orElse(UNKNOWN);
    }
}
