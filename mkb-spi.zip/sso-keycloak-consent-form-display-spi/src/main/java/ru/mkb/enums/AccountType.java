package ru.mkb.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.stream.Stream;

public enum AccountType {
    SETTLEMENT("Settlement", "Расчетный счет"),
    SPECIAL("Special", "Специальный счет"),
    BSK("BSK", "Банковское сопровождение контракта"),
    DEPOSIT("Deposit", "Депозитный счет"),
    LOANS("Loans", "Кредитный счет"),
    LETTER_OF_CREDIT("LetterOfCredit", "Аккредитив"),
    GUARANTEES("Guarantees", "Гарантия"),
    INVESTMENT("Investment", "Инвестиционный счет"),
    OTHER("Other", "Прочее"),
    UNKNOWN("Unknown", "Неизвестный тип");

    private final String jsonValue;
    @Getter
    private final String description;

    AccountType(String jsonValue, String description) {
        this.jsonValue = jsonValue;
        this.description = description;
    }

    @JsonValue
    public String getJsonValue() {
        return jsonValue;
    }

    @JsonCreator
    public static AccountType fromValue(String value) {
        return Stream.of(AccountType.values())
                .filter(type -> type.jsonValue.equalsIgnoreCase(value))
                .findFirst()
                .orElse(UNKNOWN);
    }
}