package ru.mkb;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.authenticator.ConsentFormDisplayAuthenticator;

import java.util.Arrays;
import java.util.List;

public class ConsentFormDisplayAuthenticatorFactory implements AuthenticatorFactory {
    public static final String PROVIDER_ID = "sso-keycloak-consent-from-display-spi";

    public static final String CONF_BASIC_AUTH_USER = "basic.auth.user";
    public static final String CONF_BASIC_AUTH_PASSWORD = "basic.auth.password";
    public static final String CONF_CONSENTS_SERVICE_URL = "consents.service.url";

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public Authenticator create(KeycloakSession session) {
        return new ConsentFormDisplayAuthenticator();
    }

    @Override
    public String getDisplayType() {
        return "SSO Consent: Display Form";
    }

    @Override
    public String getHelpText() {
        return "Displays the consent form to the user for signing or rejection. Requires Basic Auth credentials for the rejection API.";
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return Arrays.asList(
                new ProviderConfigProperty(
                        CONF_CONSENTS_SERVICE_URL,
                        "Consents Service Base URL",
                        "The base URL for the Consents Service (e.g., https://consents-service.example.com).",
                        ProviderConfigProperty.STRING_TYPE,
                        null
                ),
                new ProviderConfigProperty(
                        CONF_BASIC_AUTH_USER,
                        "Basic Auth Username",
                        "Username for Basic Authentication to the Consents Service.",
                        ProviderConfigProperty.STRING_TYPE,
                        null
                ),
                new ProviderConfigProperty(
                        CONF_BASIC_AUTH_PASSWORD,
                        "Basic Auth Password",
                        "Password for Basic Authentication to the Consents Service.",
                        ProviderConfigProperty.PASSWORD,
                        null
                )
        );
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return new AuthenticationExecutionModel.Requirement[]{
                AuthenticationExecutionModel.Requirement.REQUIRED,
                AuthenticationExecutionModel.Requirement.DISABLED
        };
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }

    @Override
    public String getReferenceCategory() {
        return "sso-consent";
    }

    @Override
    public void init(Config.Scope config) {}
    @Override
    public void postInit(KeycloakSessionFactory factory) {}
    @Override
    public void close() {}
}
