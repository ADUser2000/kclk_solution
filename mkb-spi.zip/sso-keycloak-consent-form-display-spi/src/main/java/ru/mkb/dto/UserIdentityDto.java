package ru.mkb.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public final class UserIdentityDto {
    private UserIdentityDto() {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CryptoProfileResponse(
            String error,
            CryptoProfileResult result
    ) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CryptoProfileResult(
            @JsonProperty("cryptoProfiles") List<CryptoProfile> cryptoProfiles
    ) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CryptoProfile(
            String cryptoProfileId,
            String profileType,
            List<Certificate> certificates
    ) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Certificate(
            String id,
            String certType,
            String certificateNumber
    ) {
    }
}
