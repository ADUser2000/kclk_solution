package ru.mkb.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import ru.mkb.enums.AccountType;
import ru.mkb.enums.Permission;

import java.util.List;

public final class ConsentServiceDto {
    private ConsentServiceDto() {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ConsentData(
            String consentId,
            String creationDateTime,
            List<Permission> permissions,
            String expirationDateTime,
            String transactionFromDateTime,
            String transactionToDateTime,
            Organization organization,
            Official official,
            String bankName,
            Account accounts
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Organization(
            String organizationId,
            String inn,
            String kpp,
            String organizationName
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Official(
            String officialId,
            String name
    ) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Account(
            String accountId,
            String accountNumber,
            String accountName,
            AccountType accountType,
            String currency
    ) {}
}
