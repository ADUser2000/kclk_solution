package ru.mkb.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class ConsentRejectionDto {
    private ConsentRejectionDto() {}

    public record RejectResponse(
            String consentId,
            String status
    ) {}

    public record RejectErrorResponse(
            String code,
            String message
    ) {}
}
