package ru.mkb.authenticator;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.ConsentFormDisplayAuthenticatorFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import static jakarta.ws.rs.core.Response.Status;
import static ru.mkb.dto.ConsentRejectionDto.RejectErrorResponse;
import static ru.mkb.dto.ConsentRejectionDto.RejectResponse;
import static ru.mkb.dto.ConsentServiceDto.ConsentData;
import static ru.mkb.dto.UserIdentityDto.CryptoProfileResponse;

@Log
public class ConsentFormDisplayAuthenticator implements Authenticator {

    private static final String CONSENT_FORM_FTL = "consent-form.ftl";

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final HttpClient httpClient = HttpClient.newHttpClient();

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        try {
            String consentDataJson = context.getAuthenticationSession().getAuthNote("consentDataJson");
            String cryptoProfilesJson = context.getAuthenticationSession().getAuthNote("cryptoProfilesJson");
            if (consentDataJson == null || cryptoProfilesJson == null) {
                context.failure(AuthenticationFlowError.INTERNAL_ERROR, context
                        .form().setError("Отсутствуют данные для формирования формы согласия.").createErrorPage(Status.INTERNAL_SERVER_ERROR));
                return;
            }

            ConsentData consentData = objectMapper.readValue(consentDataJson, ConsentData.class);
            CryptoProfileResponse cryptoProfiles = objectMapper.readValue(cryptoProfilesJson, CryptoProfileResponse.class);

            LoginFormsProvider form = context.form();
            form.setAttribute("consent", consentData);
            form.setAttribute("cryptoProfiles", cryptoProfiles.result().cryptoProfiles());
            form.setAttribute("redirectUri", context.getAuthenticationSession().getRedirectUri());
            form.setAttribute("state", context.getAuthenticationSession().getClientNote("state"));
            form.setAttribute("nonce", context.getAuthenticationSession().getClientNote("nonce"));
            form.setAttribute("clientId", context.getAuthenticationSession().getClient().getClientId());

            context.challenge(form.createForm(CONSENT_FORM_FTL));

        } catch (Exception e) {
            context.failure(AuthenticationFlowError.INTERNAL_ERROR, context
                    .form().setError("Ошибка подготовки формы согласия.").createErrorPage(Status.INTERNAL_SERVER_ERROR));
        }
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();

        if (formData.containsKey("deny")) {
            handleDeny(context);
        } else if (formData.containsKey("sign")) {
            handleSign(context, formData);
        } else {
            context.challenge(context.form().createForm(CONSENT_FORM_FTL));
        }
    }

    private void handleDeny(AuthenticationFlowContext context) {
        String consentId = context.getAuthenticationSession().getAuthNote("consentId");

        if (consentId == null || consentId.isBlank()) {
            log.info("consentId {%s} is blank".formatted(consentId));
            context.cancelLogin();
            return;
        }

        try {
            rejectConsentInService(context, consentId);
            log.info("Consent rejection for ID {%s} successfully sent to the service.".formatted(consentId));
        } catch (Exception e) {
            log.warning("Failed to notify Consents Service about rejection for consent ID {%s}. Error: %s"
                    .formatted(consentId, e.getMessage()));
        }

        context.cancelLogin();
    }

    private void handleSign(AuthenticationFlowContext context, MultivaluedMap<String, String> formData) {
        String base64Message = formData.getFirst("base64Message");
        String signature = formData.getFirst("signature");

        if (base64Message == null || base64Message.isBlank() || signature == null || signature.isBlank()) {
            LoginFormsProvider form = context.form().setError("Не были предоставлены полные данные подписи.");
            context.challenge(form.createForm("consent-form.ftl"));
            return;
        }

        context.getAuthenticationSession().setAuthNote("consentMessageBase64", base64Message);
        context.getAuthenticationSession().setAuthNote("consentSignature", signature);

        String cryptoProfileId = formData.getFirst("cryptoProfileId");
        if (cryptoProfileId != null) {
            context.getAuthenticationSession().setAuthNote("chosenCryptoProfileId", cryptoProfileId);
        }

        context.success();
    }

    private void rejectConsentInService(AuthenticationFlowContext context, String consentId) throws Exception {
        Map<String, String> config = context.getAuthenticatorConfig().getConfig();
        if (config == null) throw new IllegalStateException("Authenticator is not configured.");

        String consentsServiceUrl = config.get(ConsentFormDisplayAuthenticatorFactory.CONF_CONSENTS_SERVICE_URL);
        String username = config.get(ConsentFormDisplayAuthenticatorFactory.CONF_BASIC_AUTH_USER);
        String password = config.get(ConsentFormDisplayAuthenticatorFactory.CONF_BASIC_AUTH_PASSWORD);

        if (username == null || password == null || consentsServiceUrl == null)
            throw new IllegalStateException("Basic Auth credentials are not configured.");

        String authValue = username + ":" + password;
        String basicAuthHeader = "Basic " + Base64.getEncoder().encodeToString(authValue.getBytes(StandardCharsets.UTF_8));

        String url = String.format("%s/consent/reject/%s", consentsServiceUrl, consentId);
        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.noBody())
                .uri(URI.create(url))
                .header("Authorization", basicAuthHeader)
                .header("X-Correlation-Id", UUID.randomUUID().toString())
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            String errorMessage = "Failed to reject consent. Status code: " + response.statusCode();
            try {
                RejectErrorResponse error = objectMapper.readValue(response.body(), RejectErrorResponse.class);
                errorMessage += ". Service message: " + error.message();
            } catch (Exception parseException) {
                errorMessage += ". Response body: " + response.body();
            }
            throw new RuntimeException(errorMessage);
        }

        RejectResponse successResponse = objectMapper.readValue(response.body(), RejectResponse.class);
        log.info("Consent " + successResponse.consentId() + " successfully rejected with status " + successResponse.status());
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession keycloakSession, RealmModel realmModel, UserModel userModel) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession keycloakSession, RealmModel realmModel, UserModel userModel) {
    }

    @Override
    public void close() {
    }
}
