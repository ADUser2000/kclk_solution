package ru.mkb.keycloak.userdetails.provider;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.HttpHeaders;
import lombok.extern.java.Log;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.config.SslConfigs;
import org.keycloak.Config;
import org.keycloak.events.Event;
import org.keycloak.events.EventListenerProvider;
import org.keycloak.events.EventListenerProviderFactory;
import org.keycloak.events.EventType;
import org.keycloak.events.admin.AdminEvent;
import org.keycloak.events.admin.OperationType;
import org.keycloak.events.admin.ResourceType;
import org.keycloak.models.*;
import org.keycloak.models.utils.KeycloakModelUtils;
import ru.mkb.keycloak.userdetails.dto.UserEventDTO;
import ru.mkb.keycloak.userdetails.dto.UserRegistrationEventDTO;
import ru.mkb.keycloak.userdetails.type.UserEventType;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

@Log
public class LoginEventListenerProvider implements EventListenerProviderFactory, EventListenerProvider {
    private static final String BOOTSTRAP_URL = "BOOTSTRAP_URL";
    private static final String TOPIC = "TOPIC";
    private static final String STRING_SERIALIZER = "org.apache.kafka.common.serialization.StringSerializer";
    private static final String LOGIN_EVENT_LISTENER_ID = "login_event_listener";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final String ISO_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'";
    private static final String INCORRECT_OTP_CODE_EVENT_MESSAGE = "invalid_login_sms";
    private static final String IDENTIFY_DATE_TIME = "identifyDateTime";
    private static final String TWO_FACTOR_TYPE = "two_factor_type";
    private static final String USER_AGENT = "User-Agent";
    private static final String INVALID_USER_CREDENTIALS = "invalid_user_credentials";
    private static final String USER_NOT_FOUND = "user_not_found";
    private static final String INVALID_CERTIFICATION_VALIDATION = "invalid_certification_validation";
    private static final String INVALID_LOGIN_QR_CODE = "invalid_login_qr_code";
    private static final String LOGIN_RECOVERY = "login_recovery";
    private static final String EVENT_RECOVERY_TYPE = "event_recovery_type";
    private static final String SSO_ENTITY_SSO_EVENTS = "Sso.Entity.SsoEvents";
    private static final String MTLS_ENABLED = "MTLS_ENABLED";
    private static final String KEYSTORE_TYPE = "PKCS12";
    private static final String KEYSTORE_PASSWORD = "KEYSTORE_PASSWORD";
    private static final String ABSOLUTE_KEYSTORE_PATH = "ABSOLUTE_KEYSTORE_PATH";
    private static final String SENT_TEMPORARY_BLOCK_EVENT = "sentTemporaryBlockEvent";
    private static final String ROOT_SIEBEL_ID = "rootSiebelId";

    private KeycloakSession keycloakSession;

    @Override
    public String getId() {
        return LOGIN_EVENT_LISTENER_ID;
    }

    @Override
    public EventListenerProvider create(KeycloakSession keycloakSession) {
        this.keycloakSession = keycloakSession;
        return this;
    }

    @Override
    public void init(Config.Scope scope) {}

    @Override
    public void postInit(KeycloakSessionFactory keycloakSessionFactory) {}

    @Override
    public void close() {}

    @Override
    public void onEvent(Event event) {

        String userEventJson = "";

        log.info("Event: %s with userId: %s and error: %s".formatted(event.getType(), event.getUserId(), event.getError()));

        if (isInvalidUserCredentials(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.INVALID_LOGIN_CREDENTIALS);
        } else if (isInvalidLoginSms(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.INVALID_LOGIN_SMS);
        } else if (isInvalidLoginQrCode(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.INVALID_LOGIN_QR_CODE);
        } else if (isInvalidCertificationValidation(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.INVALID_CERTIFICATION_VALIDATION);
        } else if (isLoginRecovery(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.LOGIN_RECOVERY);
        } else if (isLogout(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.USER_LOGOUT);
        } else if (isCodeToToken(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.ACCESS_TOKEN_ISSUED, new UserEventDTO.AdditionalData(event.getSessionId()));
        } else if (isLoginEvent(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.LOGIN_SUCCESS, new UserEventDTO.AdditionalData(getTwoFactorType(), getIdentifyDateTime(), getEventDateTime(event.getTime()), event.getSessionId(), "", null, ""));
        } else if (isPasswordRecovery(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.PASSWORD_RECOVERY);
        } else if (isTemporarilyDisabledTOTP(event)) {
            userEventJson = buildUserEventJson(event, UserEventType.LOGIN_TEMPORARY_BLOCK);
        } else if (isTemporarilyDisabledLogin(event)) {
            Optional<UserModel> userModel = findUserById(event.getUserId());
                if (userModel.isPresent() && userModel.get().getAttributes().get(SENT_TEMPORARY_BLOCK_EVENT) == null) {
                    userModel.get().setAttribute(SENT_TEMPORARY_BLOCK_EVENT, Collections.singletonList(String.valueOf(true)));
                    userEventJson = buildUserEventJson(event, UserEventType.LOGIN_TEMPORARY_BLOCK);
                }
        }

        if (userEventJson.isEmpty()) {
            return;
        }

        sendToKafka(userEventJson, SSO_ENTITY_SSO_EVENTS);
    }

    private static boolean isTemporarilyDisabledTOTP(Event event) {
        return event.getType().equals(EventType.UPDATE_TOTP_ERROR) && event.getError().equals(UserEventType.LOGIN_TEMPORARY_BLOCK.getValue());
    }

    private static boolean isTemporarilyDisabledLogin(Event event) {
        return event.getType().equals(EventType.LOGIN_ERROR) && event.getError().equals(UserEventType.USER_TEMPORARILY_DISABLED.getValue());
    }

    private String buildUserEventJson(Event event, UserEventType userEventType) {
        return buildUserEventJson(event, userEventType, null);
    }

    private String buildUserEventJson(Event event, UserEventType userEventType, UserEventDTO.AdditionalData additionalData) {
        return convertUserEventObjectToJson(new UserEventDTO(event.getUserId(), getRootSiebelId(event), getEventDateTime(event.getTime()), formatDateTime(LocalDateTime.now()), userEventType, getClientIpAddress(), getUserAgent(), additionalData));
    }

    private boolean isPasswordRecovery(Event event) {
        return event.getType().equals(EventType.RESET_PASSWORD) && isRecoveryEvent();
    }

    private static boolean isLoginEvent(Event event) {
        return event.getType().equals(EventType.LOGIN);
    }

    private static boolean isCodeToToken(Event event) {
        return event.getType().equals(EventType.CODE_TO_TOKEN) || event.getType().equals(EventType.REFRESH_TOKEN);
    }

    private static boolean isLogout(Event event) {
        return event.getType().equals(EventType.LOGOUT);
    }

    private static boolean isLoginRecovery(Event event) {
        return event.getType().equals(EventType.RESET_PASSWORD) && event.getDetails().containsKey(LOGIN_RECOVERY);
    }

    private static boolean isInvalidCertificationValidation(Event event) {
        return event.getType().equals(EventType.LOGIN_ERROR) && event.getError().equals(INVALID_CERTIFICATION_VALIDATION);
    }

    private static boolean isInvalidLoginQrCode(Event event) {
        return event.getType().equals(EventType.LOGIN_ERROR) && event.getError().equals(INVALID_LOGIN_QR_CODE);
    }

    private static boolean isInvalidLoginSms(Event event) {
        return event.getType().equals(EventType.UPDATE_TOTP_ERROR) && event.getError().equals(INCORRECT_OTP_CODE_EVENT_MESSAGE);
    }

    private static boolean isInvalidUserCredentials(Event event) {
        return event.getType().equals(EventType.LOGIN_ERROR) && (event.getError().equals(INVALID_USER_CREDENTIALS) || event.getError().equals(USER_NOT_FOUND));
    }

    private boolean isRecoveryEvent() {
        return Optional.ofNullable(keycloakSession.getContext()).map(KeycloakContext::getAuthenticationSession).map(authenticationSessionModel -> authenticationSessionModel.getAuthNote(EVENT_RECOVERY_TYPE)).isPresent();
    }

    private String getTwoFactorType() {
        return Optional.ofNullable(keycloakSession.getContext().getAuthenticationSession()).map(authenticationSessionModel -> authenticationSessionModel.getClientNote(TWO_FACTOR_TYPE)).orElse("");
    }

    private String getIdentifyDateTime() {
        return Optional.ofNullable(keycloakSession.getContext()).map(KeycloakContext::getAuthenticationSession).map(authenticationSessionModel -> authenticationSessionModel.getClientNote(IDENTIFY_DATE_TIME)).orElse("");
    }

    private String getRootSiebelId(Event event) {
        if (event.getUserId() == null || event.getUserId().isEmpty()) {
            return "";
        }

        return Optional.ofNullable(keycloakSession.getContext())
                .map(KeycloakContext::getAuthenticationSession)
                .map(authenticationSessionModel -> authenticationSessionModel.getAuthNote(ROOT_SIEBEL_ID))
                .filter(str -> !str.isBlank())
                .orElseGet(() -> getRootSiebelIdFromUserManager(event.getRealmId(), event.getUserId()));
    }

    private String getRootSiebelIdFromUserManager(String realmId, String userId) {
        try {
            StringBuilder rootSiebelId = new StringBuilder();
            KeycloakModelUtils.runJobInTransaction(keycloakSession.getKeycloakSessionFactory(), s -> {
                RealmModel realm = keycloakSession.realms().getRealm(realmId);
                UserModel userModel = s.users().getUserById(realm, userId);
                rootSiebelId.append(userModel.getFirstAttribute(ROOT_SIEBEL_ID));
            });

            return rootSiebelId.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private String getRootSiebelIdFromUserManagerAdmin(String realmId, String userId) {
        try {
            StringBuilder rootSiebelId = new StringBuilder();
            KeycloakModelUtils.runJobInTransaction(keycloakSession.getKeycloakSessionFactory(), s -> {
                RealmModel realm = keycloakSession.realms().getRealm(realmId);
                UserModel userModel = keycloakSession.users().getUserById(realm, userId);

                log.info("UserId: %s is userModel not null %s".formatted(userId, userModel != null));
                rootSiebelId.append(userModel != null ? userModel.getFirstAttribute(ROOT_SIEBEL_ID) : "");
            });

            return rootSiebelId.toString();
        } catch (Exception e) {
            log.info("UserId: %s exception getting RootSiebelId: %s".formatted(userId, e));
            return "";
        }
    }

    private String getRemoteIpAddress() {
        try {
            org.keycloak.common.ClientConnection connection = keycloakSession.getContext().getConnection();

            if (connection != null) {
                return connection.getRemoteAddr();
            }
            return "";
        } catch (Exception ex) {
            return "";
        }
    }

    public String getClientIpAddress() {
        HttpHeaders httpRequest = keycloakSession.getContext().getRequestHeaders();

        final String ipAddress = getRemoteIpAddress();
        final String xForwardedFor = Optional.ofNullable(httpRequest)
                .map(httpHeaders -> httpHeaders.getHeaderString("X-Forwarded-For"))
                .orElse(null);
        final String xOriginalForwardedFor = Optional.ofNullable(httpRequest)
                .map(httpHeaders -> httpHeaders.getHeaderString("x-original-forwarded-for"))
                .orElse(null);

        log.info("IP address data: remote %s, xForwardedFor %s, xOriginalForwardedFor %s".formatted(ipAddress, xForwardedFor, xOriginalForwardedFor));
        if (xOriginalForwardedFor != null) {
            return xOriginalForwardedFor;
        }
        if (xForwardedFor != null) {
            return xForwardedFor.split(",")[0].trim();
        }
        return ipAddress;
    }

    private String getUserAgent() {
        return Optional.ofNullable(keycloakSession.getContext().getAuthenticationSession())
                .map(authenticationSessionModel -> authenticationSessionModel.getClientNote(USER_AGENT))
                .orElseGet(() -> Optional.ofNullable(keycloakSession.getContext())
                        .map(KeycloakContext::getRequestHeaders)
                        .map(HttpHeaders::getRequestHeaders)
                        .map(stringStringMultivaluedMap -> stringStringMultivaluedMap.get(USER_AGENT))
                        .flatMap(strings -> strings.stream().findFirst())
                        .orElse(""));
    }

    private Optional<UserModel> findUserById(String userId) {
        if (userId == null) {
            return Optional.empty();
        }
        RealmModel realmModel = Optional.ofNullable(keycloakSession.getContext()).map(KeycloakContext::getRealm)
                .orElse(keycloakSession.realms().getRealmByName("vbo"));
        return Optional.ofNullable(keycloakSession.users().getUserById(realmModel, userId));
    }

    private String convertObjectToJson(UserRegistrationEventDTO userRegistrationEventDTO) {
        try {
            return OBJECT_MAPPER.writeValueAsString(userRegistrationEventDTO);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private String convertUserEventObjectToJson(UserEventDTO userEventDTO) {
        try {
            return OBJECT_MAPPER.writeValueAsString(userEventDTO);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onEvent(AdminEvent adminEvent, boolean b) {
        if (isEventCreateUser(adminEvent)) {
            String userId = getUserId(adminEvent);
            log.info("userID: %s start event creation".formatted(userId));
            String rootSiebelId = getRootSiebelIdFromUserManagerAdmin(adminEvent.getRealmId(), userId);
            log.info("userID: %s Getting rootSiebel id: %s ".formatted(userId, rootSiebelId));
            if (rootSiebelId.isEmpty()) {
                throw new RuntimeException("Root Siebel Id is empty for user " + userId);
            }
            String requestJson = convertObjectToJson(new UserRegistrationEventDTO(userId, rootSiebelId, getEventDateTime(adminEvent.getTime()), formatDateTime(LocalDateTime.now())));
            String userEventJson = convertUserEventObjectToJson(new UserEventDTO(userId, rootSiebelId, getEventDateTime(adminEvent.getTime()), formatDateTime(LocalDateTime.now()), UserEventType.ACCOUNT_CREATED, "", getUserAgent(), null));
            log.info("userID: %s Ready to sent rootSiebelId to kafka with data: %s".formatted(userId, requestJson));
            sendToKafka(requestJson, getEnv(TOPIC));
            sendToKafka(userEventJson, SSO_ENTITY_SSO_EVENTS);
        } else if (isEventUpdateUser(adminEvent)) {
            String userId = getUserId(adminEvent);
            Optional<UserModel> userModel = Optional.ofNullable(keycloakSession.users().getUserById(keycloakSession.getContext().getRealm(), userId));
            String rootSiebelId = getRootSiebelIdFromUserManager(adminEvent.getRealmId(), userId);
            String userEventJson = convertUserEventObjectToJson(new UserEventDTO(userId, rootSiebelId, getEventDateTime(adminEvent.getTime()), formatDateTime(LocalDateTime.now()), UserEventType.USER_UPDATE, "", getUserAgent(), new UserEventDTO.AdditionalData(userModel.map(UserModel::isEnabled).orElse(false))));
            sendToKafka(userEventJson, SSO_ENTITY_SSO_EVENTS);
        } else if (isEventDeleteSession(adminEvent)) {
            String userId = getUserId(adminEvent).replace("/logout", "");
            String rootSiebelId = getRootSiebelIdFromUserManager(adminEvent.getRealmId(), userId);
            String userEventJson = convertUserEventObjectToJson(new UserEventDTO(userId, rootSiebelId, getEventDateTime(adminEvent.getTime()), formatDateTime(LocalDateTime.now()), UserEventType.ADMIN_DELETE_USER_SESSION, "", getUserAgent(), null));
            sendToKafka(userEventJson, SSO_ENTITY_SSO_EVENTS);
        }
    }

    private static String formatDateTime(LocalDateTime localDateTime) {
        ZonedDateTime now = localDateTime.atZone(ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_DATE_TIME_FORMAT);
        return now.format(formatter);
    }

    private static String getEventDateTime(Long time) {
        Instant instant = Instant.ofEpochMilli(time);
        return formatDateTime(LocalDateTime.ofInstant(instant, ZoneId.systemDefault()));
    }

    private static void sendToKafka(String requestJson, String topic) {
        Properties props = new Properties();
        props.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, getEnv(BOOTSTRAP_URL));
        props.put("key.serializer", STRING_SERIALIZER);
        props.put("value.serializer", STRING_SERIALIZER);

        if (isMTLSEnabled()) {
            props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
            props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, KEYSTORE_TYPE);
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, getEnv(ABSOLUTE_KEYSTORE_PATH));
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, getEnv(KEYSTORE_PASSWORD));

            props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, KEYSTORE_TYPE);
            props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, getEnv(ABSOLUTE_KEYSTORE_PATH));
            props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, getEnv(KEYSTORE_PASSWORD));
        }

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            ProducerRecord<String, String> record = new ProducerRecord<>(topic, requestJson);
            producer.send(record, (metadata, exception) -> {
                if (exception != null) {
                    exception.printStackTrace();
                } else {
                    log.info("Сообщение отправлено в топик: %s".formatted(topic));
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getUserId(AdminEvent adminEvent) {
        return adminEvent.getResourcePath().replace("users/", "");
    }

    private static String getEnv(String environment) {
        return Optional.ofNullable(System.getenv(environment))
                .orElseThrow(() -> new RuntimeException("Not found environment variable: %s".concat(environment)));
    }

    private static boolean isMTLSEnabled() {
        return Optional.ofNullable(System.getenv(MTLS_ENABLED)).map(Boolean::parseBoolean).orElse(false);
    }

    private static boolean isEventCreateUser(AdminEvent adminEvent) {
        return ResourceType.USER.equals(adminEvent.getResourceType()) && OperationType.CREATE.equals(adminEvent.getOperationType());
    }

    private static boolean isEventUpdateUser(AdminEvent adminEvent) {
        return ResourceType.USER.equals(adminEvent.getResourceType()) && OperationType.UPDATE.equals(adminEvent.getOperationType());
    }

    private static boolean isEventDeleteSession(AdminEvent adminEvent) {
        return Optional.ofNullable(adminEvent.getResourcePath()).orElse("").contains("logout");
    }
}
