package ru.mkb.keycloak.userdetails.dto;

import ru.mkb.keycloak.userdetails.type.UserEventType;

public record UserEventDTO(
        String personSsoId,
        String rootSiebelId,
        String createDate,
        String deliveryDate,
        UserEventType eventType,
        String ipAddress,
        String userAgent,
        AdditionalData additionalData) {

    public record AdditionalData(
        String authenticationMethod,
        String identifyDateTime,
        String authDateTime,
        String sessionId,
        String blockType,
        Boolean enabled,
        String blockDuration) {

        public AdditionalData(String sessionId) {
            this("", "", "", sessionId, "", null, "");
        }

        public AdditionalData(Boolean enabled) {
            this("", "", "", "", "", enabled, "");
        }

        public AdditionalData(String authenticationMethod, String identifyDateTime, String authDateTime, String sessionId, String blockType, Boolean enabled, String blockDuration) {
            this.authenticationMethod = authenticationMethod;
            this.identifyDateTime = identifyDateTime;
            this.authDateTime = authDateTime;
            this.sessionId = sessionId;
            this.blockType = blockType;
            this.enabled = enabled;
            this.blockDuration = blockDuration;
        }
    }
}


