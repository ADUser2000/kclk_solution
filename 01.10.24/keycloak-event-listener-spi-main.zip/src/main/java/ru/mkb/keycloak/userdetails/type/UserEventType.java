package ru.mkb.keycloak.userdetails.type;

import lombok.Getter;

@Getter
public enum UserEventType {
    LOGIN_SUCCESS("login_success"),
    LOGIN_ERROR("login_error"),
    INVALID_LOGIN_CREDENTIALS("invalid_login_credentials"),
    INVALID_LOGIN_SMS("invalid_login_sms"),
    INVALID_LOGIN_QR_CODE("invalid_login_qr_code"),
    INVALID_CERTIFICATION_VALIDATION("invalid_certification_validation"),
    ACCESS_TOKEN_ISSUED("access_token_issued"),
    ACCOUNT_CREATED("account_created"),
    USER_UPDATE("user_update"),
    LOGIN_RECOVERY("login_recovery"),
    PASSWORD_RECOVERY("password_recovery"),
    USER_LOGOUT("user_logout"),
    ADMIN_DELETE_USER_SESSION("admin_delete_user_session"),
    LOGIN_TEMPORARY_BLOCK("login_temporary_block"),
    USER_TEMPORARILY_DISABLED("user_temporarily_disabled");

    private final String value;

    UserEventType(String value) {
        this.value = value;
    }

}
