package ru.mkb.keycloak.userdetails.dto;

public record UserRegistrationEventDTO(String personSsoId, String rootSiebelId, String createDate, String deliveryDate) {}
