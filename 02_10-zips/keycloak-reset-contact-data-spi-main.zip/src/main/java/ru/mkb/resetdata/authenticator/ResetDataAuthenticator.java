package ru.mkb.resetdata.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.events.Errors;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.resetdata.dto.PersonDTO;
import ru.mkb.resetdata.service.UserDataService;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Log
public class ResetDataAuthenticator implements Authenticator {
    private static final String PAGE = "access-recovery-email.ftl";
    private static final String PHONE = "phone";
    private static final String EMAIL = "email";
    private static final String ONLY_DIGIT_REGEX = "\\D";
    private static final String EMAIL_TO = "emailTo";
    private static final String LOGINS = "LOGINS";
    private static final String ROOT_SIEBEL_ID = "rootSiebelId";
    private static final String ATTEMPTED_USERNAME = "ATTEMPTED_USERNAME";
    private static final String SYSTEM_ERROR = "SystemError";
    private static final String OFFICIAL_NOT_FOUND = "OfficialNotFound";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        context.challenge(context.form().createForm(PAGE));
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> decodedFormParameters = context.getHttpRequest().getDecodedFormParameters();

        Optional<String> backButtonAction = Optional.ofNullable(decodedFormParameters.getFirst("backButton"));

        if (backButtonAction.isPresent()) {
            context.resetFlow();
            return;
        }

        String email = extractEmail(decodedFormParameters);
        String phone = extractPhoneNumber(decodedFormParameters);

        PersonDTO.Request.Person person = new PersonDTO.Request.Person(phone, email);
        Optional<PersonDTO.Response.UserDataResponse> userDataResponse = Optional.empty();

        try {
            userDataResponse = Optional.ofNullable(new UserDataService().requestUserData(person, context));
        } catch (Exception e) {
            createErrorPage(context);
        }

        if (userDataResponse.map(PersonDTO.Response.UserDataResponse::error).isPresent()) {
            PersonDTO.Response.UserDataResponse.Error error = userDataResponse.map(PersonDTO.Response.UserDataResponse::error).get();
            if (error.errorCodeDescriptor().equals(OFFICIAL_NOT_FOUND)) {
                context.form().setAttribute("invalidEmail", email);
                context.form().setAttribute("invalidPhone", extractPhoneNumberWithFormat(decodedFormParameters));
                userNotFoundError(context);
                return;
            } else {
                createErrorPage(context, error.errorCodeDescriptor());
            }
        }
        context.getAuthenticationSession().setAuthNote(EMAIL_TO, email);

        userDataResponse.map(PersonDTO.Response.UserDataResponse::result)
                .map(PersonDTO.Response.UserDataResponse.Result::personKeycloakId)
                .ifPresentOrElse(personKeycloakId -> {

                    List<UserModel> userModels = personKeycloakId.stream()
                            .map(keycloakId -> context.getSession().users().getUserById(context.getRealm(), keycloakId))
                            .filter(Objects::nonNull)
                            .toList();

                    String logins = userModels.stream()
                            .map(UserModel::getUsername)
                            .collect(Collectors.joining(","));

                    context.getAuthenticationSession().setAuthNote(LOGINS, logins);

                    UserModel userModel = userModels.stream().findFirst().orElseThrow(RuntimeException::new);
                    context.setUser(userModel);
                    context.getAuthenticationSession().setAuthNote(ATTEMPTED_USERNAME, "");
                    context.getAuthenticationSession().setAuthNote(ROOT_SIEBEL_ID, Optional.ofNullable(context.getUser()).map(um -> um.getFirstAttribute(ROOT_SIEBEL_ID)).orElse(""));
                    context.success();
        }, () -> userNotFoundError(context));
    }

    private static String extractPhoneNumber(MultivaluedMap<String, String> decodedFormParameters) {
        return Optional.ofNullable(decodedFormParameters.get(PHONE)).orElse(List.of()).stream().findFirst()
                .map(phoneNumber -> phoneNumber.replaceAll(ONLY_DIGIT_REGEX, ""))
                .orElseThrow(() -> new RuntimeException("phone is empty"));
    }

    private static String extractPhoneNumberWithFormat(MultivaluedMap<String, String> decodedFormParameters) {
        return Optional.ofNullable(decodedFormParameters.get(PHONE)).orElse(List.of()).stream().findFirst()
                .orElseThrow(() -> new RuntimeException("phone is empty"));
    }

    private static String extractEmail(MultivaluedMap<String, String> decodedFormParameters) {
        return Optional.ofNullable(decodedFormParameters.get(EMAIL)).orElse(List.of()).stream().findFirst()
                .orElseThrow(() -> new RuntimeException("email is empty"));
    }

    private static void userNotFoundError(AuthenticationFlowContext context) {
        context.getEvent().clone().error(Errors.USER_NOT_FOUND);
        context.forceChallenge(context.form().setError("User not found").createForm(PAGE));
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        createErrorPage(context, SYSTEM_ERROR);
    }

    private void createErrorPage(AuthenticationFlowContext context, String error) {
        context.resetFlow();
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(error)
                        .createErrorPage(Response.Status.BAD_REQUEST));
        context.clearUser();
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {

    }

    @Override
    public void close() {
    }
}