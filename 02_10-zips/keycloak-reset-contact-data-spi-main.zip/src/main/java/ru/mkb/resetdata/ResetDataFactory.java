package ru.mkb.resetdata;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.credential.PasswordCredentialModel;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.resetdata.authenticator.ResetDataAuthenticator;
import ru.mkb.resetdata.constant.ResetDataConstants;

import java.util.List;

public class ResetDataFactory implements AuthenticatorFactory {
    private static final String PROVIDER_ID = "reset-data";
    private static final String SPI_NAME = "SPI: reset by contact data";
    private static final ResetDataAuthenticator SINGLETON = new ResetDataAuthenticator();


    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return List.of(
                new ProviderConfigProperty(ResetDataConstants.USER_DATA_SERVICE_URL, "User data service url", "example: http://localhost:8080/.", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(ResetDataConstants.USER_DATA_SERVICE_AUTHORIZATION, "Enabled authorization", "", ProviderConfigProperty.BOOLEAN_TYPE, false),
                new ProviderConfigProperty(ResetDataConstants.USER_DATA_SERVICE_LOGIN, "login", "Login for user data service url", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(ResetDataConstants.USER_DATA_SERVICE_PASSWORD, "password", "password for user data service url", ProviderConfigProperty.STRING_TYPE, ""));
    }

    @Override
    public void init(Config.Scope config) {

    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getReferenceCategory() {
        return PasswordCredentialModel.TYPE;
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    public static final AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
            AuthenticationExecutionModel.Requirement.REQUIRED
    };

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }

    @Override
    public String getDisplayType() {
        return SPI_NAME;
    }

    @Override
    public String getHelpText() {
        return SPI_NAME;
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }
}