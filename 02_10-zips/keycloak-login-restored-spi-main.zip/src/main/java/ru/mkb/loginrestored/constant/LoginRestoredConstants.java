package ru.mkb.loginrestored.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class LoginRestoredConstants {
	public String REGISTRATION_SERVICE_URL = "registration_service_url";
	public String EMAIL_FROM = "email_from";
	public String SUBJECT = "subject";
	public String BUTTON_LINK = "button_link";
	public String DEV_MODE = "dev_mode";
}
