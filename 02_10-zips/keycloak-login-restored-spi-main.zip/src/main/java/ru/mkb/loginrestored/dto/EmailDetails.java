package ru.mkb.loginrestored.dto;

public record EmailDetails(
        String subject,
        String body,
        String from,
        String to,
        String cc,
        String bcc,
        boolean isHtml,
        int clientCode,
        String siebelId
) {
    @Override
    public String toString() {
        return "EmailDetails{" +
                "subject='" + subject + '\'' +
                ", body='" + body + '\'' +
                ", from='" + from + '\'' +
                ", to='" + to + '\'' +
                ", cc='" + cc + '\'' +
                ", bcc='" + bcc + '\'' +
                ", isHtml=" + isHtml +
                ", clientCode=" + clientCode +
                ", siebelId='" + siebelId + '\'' +
                '}';
    }
}
