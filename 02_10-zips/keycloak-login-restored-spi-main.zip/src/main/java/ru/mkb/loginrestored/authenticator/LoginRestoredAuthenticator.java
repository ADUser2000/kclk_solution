package ru.mkb.loginrestored.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.events.EventBuilder;
import org.keycloak.events.EventType;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.loginrestored.constant.LoginRestoredConstants;
import ru.mkb.loginrestored.dto.EmailDetails;
import ru.mkb.loginrestored.service.SendEmailService;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Log
public class LoginRestoredAuthenticator implements Authenticator {
    private static final String RESET_CREDENTIALS_PAGE = "login-restored.ftl";
    private static final String RESET_FLOW = "resetFlow";
    private static final String TEMPLATES_EMAIL_HTML = "templates/email.html";
    private static final String EMAIL_TO = "emailTo";
    private static final String ROOT_SIEBEL_ID_ATTRIBUTE = "rootSiebelId";
    private static final String LOGIN_PLACEHOLDER = "%login%";
    private static final String BUTTON_LINK = "%redirect_url%";
    private static final String ROW_TEMPLATE = "<tr>\n<td style=\"padding:0pt 0.0pt 08.0pt 0.0pt; font-size: 14pt\">%s</td>\n</tr>";
    private static final String LOGINS = "LOGINS";
    private static final String SYSTEM_ERROR = "SystemError";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        String buttonLink = getButtonLink(context);

        String logins = context.getAuthenticationSession().getAuthNote(LOGINS);

        String generatedLoginTable = generateLoginTable(splitString(logins));
        String htmlTemplate = getEmailTemplate().replace(LOGIN_PLACEHOLDER, generatedLoginTable).replace(BUTTON_LINK, buttonLink);

        if (isNotDevMode(context)) {
            try {
                String emailTo = context.getAuthenticationSession().getAuthNote(EMAIL_TO);
                new SendEmailService().send(createEmailDetails(context, htmlTemplate, emailTo), context);
            } catch (Exception e) {
                createErrorPage(context);
                return;
            }
        }
        createEvent(context, EventType.RESET_PASSWORD, "login_recovery");

        context.challenge(context.form().createForm(RESET_CREDENTIALS_PAGE));
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(SYSTEM_ERROR)
                        .createErrorPage(Response.Status.BAD_REQUEST));
    }

    private static void createEvent(AuthenticationFlowContext context, EventType eventType, String details) {
        EventBuilder eventBuilder = context.newEvent();
        eventBuilder.event(eventType);
        eventBuilder.user(Optional.ofNullable(context.getUser())
                .map(UserModel::getId)
                .orElse(null));
        eventBuilder.session(context.getAuthenticationSession().getParentSession().getId());
        eventBuilder.detail(details, "success");
        eventBuilder.success();
    }

    private EmailDetails createEmailDetails(AuthenticationFlowContext context, String htmlTemplate, String emailTo) {
        return new EmailDetails(getSubject(context), htmlTemplate, getEmailFrom(context), emailTo, null, null, true, 0, getRootSiebelId(context.getUser()));
    }

    @SneakyThrows
    private String getEmailTemplate() {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(TEMPLATES_EMAIL_HTML)) {
            return new BufferedReader(new InputStreamReader(Objects.requireNonNull(inputStream)))
                    .lines().collect(Collectors.joining("\n"));
        }
    }

    private static String getRootSiebelId(UserModel userModel) {
        return userModel.getAttributes().get(ROOT_SIEBEL_ID_ATTRIBUTE).stream().findFirst()
                .orElseThrow(() -> new RuntimeException("Not fount rootSiebelId for user: %s".concat(userModel.getId())));
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> decodedFormParameters = context.getHttpRequest().getDecodedFormParameters();
        Optional<String> backButtonAction = Optional.ofNullable(decodedFormParameters.getFirst("backButton"));

        if (backButtonAction.isPresent()) {
            context.resetFlow();
            return;
        }

        Optional<String> resetFlow = Optional.ofNullable(decodedFormParameters.getFirst(RESET_FLOW));

        if (resetFlow.isPresent()) {
            context.resetFlow();
        } else {
            context.fork();
        }
    }

    public static String generateLoginTable(List<String> logins) {
        return logins.stream()
                .map(login -> String.format(ROW_TEMPLATE, login))
                .collect(Collectors.joining());
    }

    public static List<String> splitString(String string) {
        if (string == null || string.isEmpty()) {
            return List.of();
        }
        return Arrays.stream(string.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    private boolean isNotDevMode(AuthenticationFlowContext context) {
        return !Boolean.parseBoolean(context.getAuthenticatorConfig().getConfig().get(LoginRestoredConstants.DEV_MODE));
    }

    private String getButtonLink(AuthenticationFlowContext context) {
        return context.getAuthenticatorConfig().getConfig().get(LoginRestoredConstants.BUTTON_LINK);
    }

    private String getSubject(AuthenticationFlowContext context) {
        return context.getAuthenticatorConfig().getConfig().get(LoginRestoredConstants.SUBJECT);
    }

    private String getEmailFrom(AuthenticationFlowContext context) {
        return context.getAuthenticatorConfig().getConfig().get(LoginRestoredConstants.EMAIL_FROM);
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}