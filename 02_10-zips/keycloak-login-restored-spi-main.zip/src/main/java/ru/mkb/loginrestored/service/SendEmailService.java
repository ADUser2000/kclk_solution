package ru.mkb.loginrestored.service;

import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.loginrestored.constant.LoginRestoredConstants;
import ru.mkb.loginrestored.dto.EmailDetails;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

@Log
public class SendEmailService {

	@SneakyThrows
	public void send(EmailDetails registrationDTO, AuthenticationFlowContext context) {
		String emailServiceUrl = getEmailServiceUrl(context);
		SimpleHttp simpleHttp = SimpleHttp.doPost(emailServiceUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.json(registrationDTO);

		log.info("userId: %s | make request to: %s".formatted(context.getUser().getId(), emailServiceUrl));
		try (SimpleHttp.Response response = simpleHttp.asResponse()) {
			log.info("userId: %s | Response with status code: %s".formatted(context.getUser(), response.getStatus()));
			log.info("userId: %s | Response data: %s".formatted(context.getUser().getId(), response.asString()));

            if (response.getStatus() != 200) {
				throw new RuntimeException("userId: %s | Error during send email: %s".formatted(context.getUser().getId(), response.getStatus()));
			}
			log.info(response.asString());
        }
    }

	private String getEmailServiceUrl(AuthenticationFlowContext context) {
		return context.getAuthenticatorConfig().getConfig().get(LoginRestoredConstants.REGISTRATION_SERVICE_URL);
	}
}
