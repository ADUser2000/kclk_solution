package ru.mkb.loginrestored;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.credential.PasswordCredentialModel;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.loginrestored.authenticator.LoginRestoredAuthenticator;
import ru.mkb.loginrestored.constant.LoginRestoredConstants;

import java.util.List;

public class LoginRestoredFactory implements AuthenticatorFactory {
    public static final String PROVIDER_ID = "login-restored";
    public static final LoginRestoredAuthenticator SINGLETON = new LoginRestoredAuthenticator();
    public static final String SPI_NAME = "SPI: login restored";

    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return List.of(
                new ProviderConfigProperty(LoginRestoredConstants.DEV_MODE, "Dev mode", "Enabled sending email", ProviderConfigProperty.BOOLEAN_TYPE, false),
                new ProviderConfigProperty(LoginRestoredConstants.REGISTRATION_SERVICE_URL, "Email service url", "example: http://localhost:8080/.", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(LoginRestoredConstants.EMAIL_FROM, "Email from", "example@mlb.ru", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(LoginRestoredConstants.SUBJECT, "Subject", "", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(LoginRestoredConstants.BUTTON_LINK, "Button link", "", ProviderConfigProperty.STRING_TYPE, "")
        );
    }

    @Override
    public void init(Config.Scope config) {

    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getReferenceCategory() {
        return PasswordCredentialModel.TYPE;
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    public static final AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
            AuthenticationExecutionModel.Requirement.REQUIRED
    };

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }
    @Override
    public String getDisplayType() {
        return SPI_NAME;
    }

    @Override
    public String getHelpText() {
        return SPI_NAME;
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }
}