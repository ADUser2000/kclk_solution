package ru.mkb.accessbyqr.util;

public class HttpUtil {
    public static String extractBrowserInfo(String userAgent) {
        String browser = "Unknown Browser";

        if (userAgent.contains("MSIE") || userAgent.contains("Trident/")) {
            browser = "Internet Explorer";
        } else if (userAgent.contains("Firefox")) {
            browser = "Firefox";
        } else if (userAgent.contains("Chrome")) {
            // Chrome user agent contains both "Chrome" and "Safari"
            browser = "Chrome";
        } else if (userAgent.contains("Safari") && !userAgent.contains("Chrome")) {
            browser = "Safari";
        } else if (userAgent.contains("Opera") || userAgent.contains("OPR")) {
            browser = "Opera";
        }

        return browser;
    }

    public static String extractOS(String userAgent) {
        String os = "Unknown OS";

        if (userAgent.contains("Windows")) {
            os = "Windows";
        } else if (userAgent.contains("Macintosh") || userAgent.contains("Mac OS X")) {
            os = "Mac OS";
        } else if (userAgent.contains("X11")) {
            os = "UNIX";
        } else if (userAgent.contains("Android")) {
            os = "Android";
        } else if (userAgent.contains("iPhone") || userAgent.contains("iPad")) {
            os = "iOS";
        }

        return os;
    }
}
