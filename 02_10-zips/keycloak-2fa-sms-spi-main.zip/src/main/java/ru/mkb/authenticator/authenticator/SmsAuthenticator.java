package ru.mkb.authenticator.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.common.util.SecretGenerator;
import org.keycloak.common.util.Time;
import org.keycloak.events.EventBuilder;
import org.keycloak.events.EventType;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.*;
import org.keycloak.services.managers.BruteForceProtector;
import org.keycloak.sessions.AuthenticationSessionModel;
import org.keycloak.utils.StringUtil;
import ru.mkb.authenticator.constant.LocalizationMessageConstants;
import ru.mkb.authenticator.constant.TwoFAConstants;
import ru.mkb.authenticator.dto.NotificationDTO;
import ru.mkb.authenticator.dto.SmsParamDTO;
import ru.mkb.authenticator.service.SmsService;

import java.util.List;
import java.util.Optional;
import java.util.logging.Level;

@Log
public class SmsAuthenticator implements Authenticator {
	private static final String TPL_CODE = "2fa-sms.ftl";
	private static final String EXPIRED_OTP_CODE_EVENT_MESSAGE = "Expired OTP code";
	private static final String RESET_CREDENTIALS = "reset-credentials";
	private static final String CLIENT_CODE = "clientCode";
	private static final String SMSCODE = "SMSCODE";
	private static final String FIO = "FIO";
	private static final String MOBILE_NUMBER_PATTERN_REGEXP = "(\\d)(\\d{3})(\\d{3})(\\d{2})(\\d+)";
	private static final String INVALID_LOGIN_SMS = "invalid_login_sms";
	private static final String LOGIN_TEMPORARY_BLOCK = "login_temporary_block";
	private static final String MAGIC_LINK_TOKEN_REQUEST = "mlt";

	@Override
	public void authenticate(AuthenticationFlowContext context) {
		setUser(context);

		String ttlOtpCode = ttlOtpCode(context);
		if (isTemporarilyDisabled(context)) {
			createFailureTemporarilyDisabled(context);
			return;
		}

		if (getUser(context).isPresent() && ttlOtpCode == null) {
			context.getSession().loginFailures().removeUserLoginFailure(context.getRealm(), context.getUser().getId());
		}

		if (ttlOtpCode == null || Long.parseLong(ttlOtpCode) < System.currentTimeMillis()) {
			sendSms(context);
		} else {
			if (attemptValidateCount(context) <= 2) {
				context.form().setError(LocalizationMessageConstants.SMS_AUTH_CODE_INVALID);
			}
			fillForm(context, resendTimeSecond(ttlOtpCode));
			context.challenge(context.form().createForm(TPL_CODE));
		}
	}

	private static Optional<UserModel> getUser(AuthenticationFlowContext context) {
		return Optional.ofNullable(context.getUser());
	}

	private static void setUser(AuthenticationFlowContext context) {
		Optional<String> authNoteUserId = getAuthNoteUserId(context);
		if (isResetCredentials(context) && authNoteUserId.isPresent()) {
			context.setUser(context.getSession().users().getUserById(context.getRealm(), authNoteUserId.get()));
		}
	}

	private static Optional<String> getAuthNoteUserId(AuthenticationFlowContext context) {
		return Optional.ofNullable(context.getAuthenticationSession().getAuthNote(TwoFAConstants.RESET_CREDENTIALS_USER_ID));
	}

	private static void sendSms(AuthenticationFlowContext context) {
		AuthenticatorConfigModel config = context.getAuthenticatorConfig();
		String mobileNumber = getMobileNumber(context);

		int length = Integer.parseInt(config.getConfig().get(TwoFAConstants.CODE_LENGTH));
		int ttl = Integer.parseInt(config.getConfig().get(TwoFAConstants.CODE_TTL));

		AuthenticationSessionModel authSession = context.getAuthenticationSession();
		String otp = SecretGenerator.getInstance().randomString(length, SecretGenerator.DIGITS);
		authSession.setAuthNote(TwoFAConstants.CODE, otp);
		authSession.setAuthNote(TwoFAConstants.CODE_TTL, Long.toString(System.currentTimeMillis() + (ttl * 1000L)));
		String mnemonicType = config.getConfig().get(TwoFAConstants.MNEMONIC_TYPE);
		String clientCode = context.getAuthenticationSession().getAuthNote(mobileNumber + CLIENT_CODE);
		try {
			if (Boolean.parseBoolean(config.getConfig().getOrDefault(TwoFAConstants.SIMULATION_MODE, "false"))) {
				log.log(Level.WARNING, String.format("***** SIMULATION MODE ***** Would send SMS to %s with code: %s", mobileNumber, otp));
			} else if (getUser(context).isEmpty()){
				log.log(Level.WARNING, String.format("***** Failed attempted restore login with mobile number %s", mobileNumber));
			} else {
				NotificationDTO notificationDTO = new NotificationDTO(mobileNumber, clientCode, mnemonicType, List.of(new SmsParamDTO(SMSCODE, otp),new SmsParamDTO(FIO, formatFullName(context.getAuthenticationSession().getAuthNote(FIO)))));
				new SmsService().send(notificationDTO, context);
			}

			fillForm(context, ttl);
			context.challenge(context.form().createForm(TPL_CODE));
		} catch (Exception e) {
			log.warning("userId: %s".formatted(context.getUser().getId()) +  e.getMessage());
			context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
				context.form().setError(LocalizationMessageConstants.SMS_AUTH_SYSTEM_ERROR)
					.createErrorPage(Response.Status.INTERNAL_SERVER_ERROR));
		}
	}

	public static String formatFullName(String fullName) {
		// Разделяем строку на части по пробелам
		String[] parts = fullName.trim().split("\\s+");
		if (parts.length == 0) {
			return "";  // Возвращаем пустую строку, если строка не содержит компонентов
		}

		// Обработка разных случаев количества слов
		String lastName = parts[0];  // Фамилия всегда предполагается первой
		String firstName = parts.length > 1 ? parts[1] : "";
		String middleName = parts.length > 2 ? parts[2] : "";

		// Преобразуем фамилию
		String formattedLastName = lastName.substring(0, 1).toUpperCase() + lastName.substring(1).toLowerCase();

		// Формируем строку в зависимости от наличия имени и отчества
		if (!firstName.isEmpty() && !middleName.isEmpty()) {
			char firstInitial = Character.toUpperCase(firstName.charAt(0));
			char middleInitial = Character.toUpperCase(middleName.charAt(0));
			return String.format("%s %c. %c.", formattedLastName, firstInitial, middleInitial);
		} else if (!firstName.isEmpty()) {
			char firstInitial = Character.toUpperCase(firstName.charAt(0));
			return String.format("%s %c.", formattedLastName, firstInitial);
		} else {
			return formattedLastName;  // Только фамилия
		}
	}

	private static boolean isResetCredentials(AuthenticationFlowContext context) {
		return context.getFlowPath().equals(RESET_CREDENTIALS);
	}

	private static String getMobileNumber(AuthenticationFlowContext context) {
		return context.getAuthenticationSession().getAuthNote(TwoFAConstants.PHONE);
	}

	@Override
	public void action(AuthenticationFlowContext context) {
		if (isTemporarilyDisabled(context)) {
			createFailureTemporarilyDisabled(context);
			return;
		}
		MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
		Optional<String> backButtonAction = Optional.ofNullable(formData.getFirst("backButton"));

		if (backButtonAction.isPresent()) {
			context.resetFlow();
			return;
		}

		String ttl = ttlOtpCode(context);

		if (isActionResendSMS(context)) {
			if (isCodeExpired(ttl)) {
				sendSms(context);
			}
			return;
		}

		String enteredCode = String.join("", formData.get(TwoFAConstants.CODE));
		String code = getCode(context);

		if (code == null || ttl == null) {
			fillForm(context, 0);
			context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
					context.form().setError(LocalizationMessageConstants.SMS_AUTH_SYSTEM_ERROR)
							.createErrorPage(Response.Status.INTERNAL_SERVER_ERROR));
			return;
		}

		validateCode(context, enteredCode, ttl, code);
	}

	private void validateCode(AuthenticationFlowContext context, String enteredCode, String ttl, String code) {
		if (enteredCode.equals(code)) {
			if (isCodeExpired(ttl)) {
				// expired
				decreaseAttemptValidateCount(context);
				fillForm(context, resendTimeSecond(ttl));
				createEvent(context, EventType.UPDATE_TOTP_ERROR, EXPIRED_OTP_CODE_EVENT_MESSAGE);
				context.forceChallenge(context.form().setError(LocalizationMessageConstants.SMS_AUTH_CODE_INVALID).createForm(TPL_CODE));
			} else {
				createEvent(context, EventType.UPDATE_TOTP);
				// valid
				context.success();
			}
		} else {
			// invalid
			decreaseAttemptValidateCount(context);
			fillForm(context, resendTimeSecond(ttl));

			createEvent(context, EventType.UPDATE_TOTP_ERROR, INVALID_LOGIN_SMS);

			context.forceChallenge(context.form().setError(LocalizationMessageConstants.SMS_AUTH_CODE_INVALID).createForm(TPL_CODE));

			Optional<UserModel> user = getUser(context);
			if (user.isPresent()) {
				String userId = user.get().getId();
				context.getSession().getProvider(BruteForceProtector.class).failedLogin(context.getRealm(), user.get(), context.getConnection());

				if (isTemporarilyDisabled(context)) {
					createFailureTemporarilyDisabled(context);
					createEvent(context, EventType.UPDATE_TOTP_ERROR, LOGIN_TEMPORARY_BLOCK, userId);
				}
			}
		}
	}

	private static void createEvent(AuthenticationFlowContext context, EventType eventType) {
		createEvent(context, eventType, "");
	}

	private static void createEvent(AuthenticationFlowContext context, EventType eventType, String errorMessage) {
		String userId = Optional.ofNullable(context.getUser())
				.map(UserModel::getId)
				.orElse(null);
		createEvent(context, eventType, errorMessage, userId);
	}

	private static void createEvent(AuthenticationFlowContext context, EventType eventType, String errorMessage, String userId) {
		EventBuilder eventBuilder = context.newEvent();
		eventBuilder.event(eventType);
		eventBuilder.user(userId);
		eventBuilder.session(context.getAuthenticationSession().getParentSession().getId());
		if (StringUtil.isNotBlank(errorMessage)) {
			eventBuilder.error(errorMessage);
		} else {
			eventBuilder.success();
		}
	}

	private void createFailureTemporarilyDisabled(AuthenticationFlowContext context) {
		context.getAuthenticationSession().removeClientNote(MAGIC_LINK_TOKEN_REQUEST);
		context.resetFlow();
		String userId = context.getUser().getId();
		context.failureChallenge(AuthenticationFlowError.USER_TEMPORARILY_DISABLED,
				context.form().setError(LocalizationMessageConstants.TEMPORARILY_DISABLED)
						.setAttribute("temporarilyBlockSecond", temporarilyBlockSecond(context, userId))
						.createErrorPage(Response.Status.BAD_REQUEST));
		context.clearUser();
		context.getAuthenticationSession().setAuthNote(TwoFAConstants.BLOCKED, "true");
	}

	private static Boolean isActionResendSMS(AuthenticationFlowContext context) {
		return Optional.ofNullable(context.getHttpRequest().getDecodedFormParameters().getFirst(TwoFAConstants.RESEND_SMS))
				.map(Boolean::parseBoolean)
				.orElse(false);
	}

	private static boolean isCodeExpired(String ttl) {
		return Long.parseLong(ttl) < System.currentTimeMillis();
	}

	private static String getCode(AuthenticationFlowContext context) {
		String code;
		if (Boolean.parseBoolean(context.getAuthenticatorConfig().getConfig().getOrDefault(TwoFAConstants.SIMULATION_MODE, "false"))) {
			code = context.getAuthenticatorConfig().getConfig().getOrDefault(TwoFAConstants.TEST_OTP_CODE, "12345");
		} else {
			code = context.getAuthenticationSession().getAuthNote(TwoFAConstants.CODE);
		}
		return code;
	}

	private static void fillForm(AuthenticationFlowContext context, long ttlOtpCode) {
		LoginFormsProvider form = context.form();
		form.setAttribute("realm", context.getRealm());
		form.setAttribute("mobileNumber", formatMobileNumber(getMobileNumber(context)));
		form.setAttribute("resendTime", ttlOtpCode);
		form.setAttribute("attemptValidateCount", attemptValidateCount(context));
		form.setAttribute("pageTitle", context.getAuthenticatorConfig().getConfig().get(TwoFAConstants.PAGE_TITLE));
	}

	private static String ttlOtpCode(AuthenticationFlowContext context) {
		return context.getAuthenticationSession().getAuthNote(TwoFAConstants.CODE_TTL);
	}

	private static int attemptValidateCount(AuthenticationFlowContext context) {
		return Optional.ofNullable(context.getAuthenticationSession().getAuthNote(TwoFAConstants.ATTEMPT_VALIDATE_COUNT))
				.map(Integer::parseInt)
				.orElseGet(() -> {
					String defaultAttemptCount = context.getAuthenticatorConfig().getConfig().getOrDefault(TwoFAConstants.DEFAULT_COUNT_ATTEMPT_VALIDATION, "3");
					context.getAuthenticationSession().setAuthNote(TwoFAConstants.ATTEMPT_VALIDATE_COUNT, defaultAttemptCount);
					return Integer.valueOf(defaultAttemptCount);
				});
	}


	private void decreaseAttemptValidateCount(AuthenticationFlowContext context) {
		int newAttemptValidateCount = attemptValidateCount(context) - 1;
		context.getAuthenticationSession().setAuthNote(TwoFAConstants.ATTEMPT_VALIDATE_COUNT, String.valueOf(newAttemptValidateCount));
	}

	private static boolean isTemporarilyDisabled(AuthenticationFlowContext context) {
		return getUser(context).isPresent() && context.getSession().getProvider(BruteForceProtector.class).isTemporarilyDisabled(context.getSession(), context.getRealm(), context.getUser());
	}

	private static long resendTimeSecond(String ttl) {
		return Math.max((Long.parseLong(ttl) - Time.currentTimeMillis()) / 1000, 0L);
	}

	private long temporarilyBlockSecond(AuthenticationFlowContext context, String userId) {
		UserLoginFailureModel failure = context.getSession().loginFailures().getUserLoginFailure(context.getRealm(), userId);
		if (failure != null) {
			return Math.max(failure.getFailedLoginNotBefore() - Time.currentTimeMillis() / 1000, 0L);
		}
		return 0L;
	}

	private static String formatMobileNumber(String mobileNumber) {
		return String.valueOf(mobileNumber).replaceFirst(MOBILE_NUMBER_PATTERN_REGEXP, "+$1 $2 ***-**-$5");
	}

	@Override
	public boolean requiresUser() {
		return false;
	}

	@Override
	public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
		return false;
	}

	@Override
	public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
	}

	@Override
	public void close() {
	}

}
