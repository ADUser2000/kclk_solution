package ru.mkb.authenticator.service;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.authenticator.constant.TwoFAConstants;
import ru.mkb.authenticator.dto.NotificationDTO;

@Log
public class SmsService {

	@SneakyThrows
	public void send(NotificationDTO notificationDTO, AuthenticationFlowContext context) {
		String smsServiceUrl = context.getAuthenticatorConfig().getConfig().get(TwoFAConstants.NOTIFICATION_URL);
		SimpleHttp simpleHttp = SimpleHttp.doPost(smsServiceUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.json(notificationDTO);

		log.info("userId: %s make request to: %s".formatted(context.getUser().getId(), smsServiceUrl));
        try (SimpleHttp.Response response = simpleHttp.asResponse()) {
            log.info("userId: %s Response with status code: %s".formatted(context.getUser(), response.getStatus()));
            log.info("userId: %s | Response data: %s".formatted(context.getUser().getId(), response.asString()));
            if (response.getStatus() != 200) {
                throw new RuntimeException("userId: %s Error send sms code. Response status code: %s".formatted(context.getUser().getId(), response.getStatus()));
            }
        }
    }
}
