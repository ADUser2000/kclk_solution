package ru.mkb.changepassword;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.credential.PasswordCredentialModel;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.changepassword.authenticator.ChangePasswordAuthenticator;
import ru.mkb.changepassword.constant.ChangePasswordConstants;

import java.util.List;

public class ChangePasswordFactory implements AuthenticatorFactory {
    public static final String PROVIDER_ID = "change-password";
    public static final ChangePasswordAuthenticator SINGLETON = new ChangePasswordAuthenticator();

    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return List.of(
                new ProviderConfigProperty(ChangePasswordConstants.REGISTRATION_SERVICE_URL, "Registration service url", "example: http://localhost:8080/.", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(ChangePasswordConstants.DEV_MODE, "dev mode", "Turn off doing request to registration service", ProviderConfigProperty.BOOLEAN_TYPE, false)
        );
    }

    @Override
    public void init(Config.Scope config) {

    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getReferenceCategory() {
        return PasswordCredentialModel.TYPE;
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    public static final AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
            AuthenticationExecutionModel.Requirement.REQUIRED
    };

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }
    @Override
    public String getDisplayType() {
        return "SPI: change password";
    }

    @Override
    public String getHelpText() {
        return "SPI: change password";
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }
}