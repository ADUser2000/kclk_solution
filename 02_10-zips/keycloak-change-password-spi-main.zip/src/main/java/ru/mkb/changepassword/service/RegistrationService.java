package ru.mkb.changepassword.service;

import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.changepassword.constant.ChangePasswordConstants;
import ru.mkb.changepassword.dto.RegistrationDTO;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

@Log
public class RegistrationService {

	public static final int TIMEOUT_15SEC = 15 * 1000;

	@SneakyThrows
	public void sendLogin(RegistrationDTO registrationDTO, AuthenticationFlowContext context) {
		String registrationServiceUrl = getRegistrationServiceUrl(context);
		SimpleHttp simpleHttp = SimpleHttp.doPost(registrationServiceUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.json(registrationDTO);

		simpleHttp.connectTimeoutMillis(TIMEOUT_15SEC);
		simpleHttp.socketTimeOutMillis(TIMEOUT_15SEC);

		log.info("userId: %s | make request to: %s".formatted(context.getUser().getId(), registrationServiceUrl));
        try (SimpleHttp.Response response = simpleHttp.asResponse()) {
			log.info("userId: %s | Response with status code: %s".formatted(context.getUser(), response.getStatus()));
			log.info("userId: %s | Response data: %s".formatted(context.getUser().getId(), response.asString()));

            if (response.getStatus() != 200) {
                throw new RuntimeException("userId: %s | Error during registration: %s".formatted(context.getUser().getId(), response.getStatus()));
            }
        }
    }

	private String getRegistrationServiceUrl(AuthenticationFlowContext context) {
		return context.getAuthenticatorConfig().getConfig().get(ChangePasswordConstants.REGISTRATION_SERVICE_URL);
	}
}
