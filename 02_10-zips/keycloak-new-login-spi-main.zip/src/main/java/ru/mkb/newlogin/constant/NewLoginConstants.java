package ru.mkb.newlogin.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class NewLoginConstants {
	public String USER_DATA_SERVICE_URL = "userDataServiceUrl";
	public String USER_DATA_SERVICE_AUTHORIZATION = "userDataServiceAuthorization";
	public String USER_DATA_SERVICE_LOGIN = "userDataServiceLogin";
	public String USER_DATA_SERVICE_PASSWORD = "userDataServicePassword";
}
