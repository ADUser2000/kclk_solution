package ru.mkb.newlogin.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.newlogin.dto.PersonDTO;
import ru.mkb.newlogin.service.UserDataService;

import java.util.*;

@Log
public class NewLoginAuthenticator implements Authenticator {
    private static final String NEW_LOGIN_PAGE = "new-login.ftl";
    private static final String LOGIN = "login";
    private static final String NOT_AVAILABLE_LOGIN_MESSAGE = "notAvailableLogin";
    private static final String OLD_LOGIN = "oldLogin";
    private static final String LOGIN_OPTIONS = "loginOptions";
    private static final int MAX_LOGINS = 3;
    private static final int MIN_LASTNAME_LENGTH = 6;
    private static final String MAGIC_LINK_TOKEN_REQUEST = "magic_link_token";
    private static final String SYSTEM_ERROR = "SystemError";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        try {
            PersonDTO.Request.Person person = new PersonDTO.Request.Person(context.getUser().getId());
            PersonDTO.Response.PersonData personData = new UserDataService().requestUserData(person, context);
            if (personData != null && personData.error() != null) {
                createErrorPage(context, personData.error().errorCodeDescriptor());
            } else {
                String lastNameTranslit = personData.getLastNameTranslit();
                setLogins(context, generateOneUniqueLogin(context, lastNameTranslit), lastNameTranslit);
                context.challenge(context.form().createForm(NEW_LOGIN_PAGE));
            }
        } catch (Exception e) {
            createErrorPage(context);
        }
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
        String login = Optional.ofNullable(formData.getFirst(LOGIN)).orElse("").trim().toLowerCase();

        boolean loginAvailable = isLoginAvailable(context, login);

        if (!login.isEmpty() && loginAvailable) {
            UserModel user = context.getUser();
            context.getAuthenticationSession().setAuthNote(LOGIN, login);
            Optional.ofNullable(user.getAttributes().get(MAGIC_LINK_TOKEN_REQUEST)).orElse(List.of()).stream().findFirst()
                    .ifPresentOrElse(mlt -> {
                        context.success();
                    }, context::resetFlow);
        } else {
            try {
                PersonDTO.Request.Person person = new PersonDTO.Request.Person(context.getUser().getId());
                PersonDTO.Response.PersonData personData = new UserDataService().requestUserData(person, context);
                if (personData != null && personData.error() != null) {
                    createErrorPage(context, personData.error().errorCodeDescriptor());
                } else {
                    setLogins(context, login, personData.getLastNameTranslit());
                    context.forceChallenge(context.form().setError(NOT_AVAILABLE_LOGIN_MESSAGE).createForm(NEW_LOGIN_PAGE));
                }
            } catch (Exception e) {
                createErrorPage(context);
            }
        }
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        createErrorPage(context, SYSTEM_ERROR);
    }

    private void createErrorPage(AuthenticationFlowContext context, String message) {
        context.resetFlow();
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(message)
                        .createErrorPage(Response.Status.BAD_REQUEST));
        context.clearUser();
    }

    private void setLogins(AuthenticationFlowContext context, String login, String lastNameTranslit) {
        LoginFormsProvider form = context.form();
        form.setAttribute(OLD_LOGIN, login);
        form.setAttribute(LOGIN_OPTIONS, generateUniqueLogins(context, lastNameTranslit));
    }

    private String generateOneUniqueLogin(AuthenticationFlowContext context, String lastname) {
        return generateUniqueLogins(context, lastname, 1).stream().findFirst().orElse("");
    }

    private Set<String> generateUniqueLogins(AuthenticationFlowContext context, String lastname) {
        return generateUniqueLogins(context, lastname, MAX_LOGINS);
    }

    private Set<String> generateUniqueLogins(AuthenticationFlowContext context, String lastname, int count) {
        Set<String> uniqueLogins = new HashSet<>();
        Random random = new Random();

        // Преобразование lastname
        lastname = lastname.replaceAll("[^a-zA-Z]", "").toLowerCase(); // Убираем все, кроме букв

        while (uniqueLogins.size() < count) {
            String newLogin = generateLoginWithRandomDigits(lastname, random);
            if (isLoginAvailable(context, newLogin)) {
                uniqueLogins.add(newLogin);
            }
        }
        return uniqueLogins;
    }

    private static String generateLoginWithRandomDigits(String lastname, Random random) {
        StringBuilder loginBuilder = new StringBuilder(lastname);

        // Добавляем минимум 3 случайных цифры
        for (int i = 0; i < 3; i++) {
            loginBuilder.append(random.nextInt(10));
        }

        // Если общая длина меньше 6, добавляем еще цифры
        while (loginBuilder.length() < MIN_LASTNAME_LENGTH) {
            loginBuilder.append(random.nextInt(10));
        }

        return loginBuilder.toString();
    }

    private boolean isLoginAvailable(AuthenticationFlowContext context, String login) {
        return Optional.ofNullable(context.getSession().users().getUserByUsername(context.getRealm(), login)).isEmpty();
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {

    }

    @Override
    public void close() {
    }
}