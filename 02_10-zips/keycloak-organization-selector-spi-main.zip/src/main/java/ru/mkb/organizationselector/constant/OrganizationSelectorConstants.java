package ru.mkb.organizationselector.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class OrganizationSelectorConstants {
	public String CERTIFICATE_NUMBER_ATTRIBUTE = "certificateNumberAttribute";
	public String USER_DATA_SERVICE_URL = "userDataServiceUrl";
	public String SIGN_SERVICE_URL = "signServiceUrl";
	public String SIMULATION_MODE = "simulation";
	public String USER_DATA_SERVICE_AUTHORIZATION = "userDataServiceAuthorization";
	public String USER_DATA_SERVICE_LOGIN = "userDataServiceLogin";
	public String USER_DATA_SERVICE_PASSWORD = "userDataServicePassword";
}
