package ru.mkb.organizationselector.service;

import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.organizationselector.constant.OrganizationSelectorConstants;
import ru.mkb.organizationselector.dto.PersonDTO;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

@Log
public class SignService {

	@SneakyThrows
	public PersonDTO.Response.PersonData checkSign(PersonDTO.Request.Sign sign, AuthenticationFlowContext context) {
		String userDataServiceUrl = getSignServiceUrl(context);
		SimpleHttp simpleHttp = SimpleHttp.doPost(userDataServiceUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.json(sign);

		log.info("Make request to: %s".formatted(userDataServiceUrl));
        try (SimpleHttp.Response response = simpleHttp.asResponse()) {
            log.info("Response with status code: %s".formatted(response.getStatus()));

			if (response.getStatus() == 200 || response.getStatus() == 400) {
				return response.asJson(PersonDTO.Response.PersonData.class);
			} else {
				throw new RuntimeException("Error during check sign: %s".formatted(response.getStatus()));
			}
		}
    }

	private String getSignServiceUrl(AuthenticationFlowContext context) {
		return context.getAuthenticatorConfig().getConfig().get(OrganizationSelectorConstants.SIGN_SERVICE_URL);
	}
}
