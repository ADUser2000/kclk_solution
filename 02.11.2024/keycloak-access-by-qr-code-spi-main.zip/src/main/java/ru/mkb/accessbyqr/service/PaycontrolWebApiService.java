package ru.mkb.accessbyqr.service;

import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.accessbyqr.constant.AccessByQRConstants;
import ru.mkb.accessbyqr.dto.PaycontrolDTO;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

@Log
public class PaycontrolWebApiService {

	@SneakyThrows
	public String send(PaycontrolDTO.Request.InitSession initSession, AuthenticationFlowContext context) {
		String paycontrolWebApiUrl = context.getAuthenticatorConfig().getConfig().get(AccessByQRConstants.PAYCONTROL_WEB_API_URL);
		SimpleHttp simpleHttp = SimpleHttp.doPost(paycontrolWebApiUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.json(initSession);

		log.info("Make request to: %s".formatted(paycontrolWebApiUrl));
        try (SimpleHttp.Response response = simpleHttp.asResponse()) {
            log.info("Response with status code: %s".formatted(response.getStatus()));
            log.info("Response data: %s".formatted(response.asString()));

            if (response.getStatus() != 200) {
                throw new RuntimeException("Error getting PC session. Response status code: %s".formatted(response.getStatus()));
            }
            return response.asString().replace("\"","");
        }
    }
}
