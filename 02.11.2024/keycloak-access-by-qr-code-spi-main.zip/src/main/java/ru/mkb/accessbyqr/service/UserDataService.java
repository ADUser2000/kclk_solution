package ru.mkb.accessbyqr.service;

import jakarta.ws.rs.core.HttpHeaders;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.accessbyqr.constant.AccessByQRConstants;
import ru.mkb.accessbyqr.dto.SessionDTO;

import java.util.Base64;

@Log
public class UserDataService {

	public SessionDTO.Response.PersonData request(String sessionId, AuthenticationFlowContext context) throws Exception {
		String userDataServiceUrl = getUserDataServiceUrl(sessionId, context);
		int maxAttempts = 10;
		int attempts = 0;
		long initialDelay = 500; // начальная задержка
		SessionDTO.Response.PersonData personData = null;

		while (attempts < maxAttempts) {
			attempts++;
			long delay = initialDelay * (1L << (attempts - 1)); // экспоненциальная задержка
			SimpleHttp simpleHttp = SimpleHttp.doGet(userDataServiceUrl, context.getSession())
					.header(HttpHeaders.AUTHORIZATION, getBasicAuthorization(context));

			log.info("Попытка %s: запрос к URL: %s".formatted(attempts, userDataServiceUrl));
			try (SimpleHttp.Response response = simpleHttp.asResponse()) {
				int status = response.getStatus();
				log.info("Статус ответа: %s".formatted(status));
				String responseData = response.asString();
				log.info("Данные ответа: %s".formatted(responseData));

				try {
					personData = response.asJson(SessionDTO.Response.PersonData.class);
				} catch (Exception e) {
					log.warning("Не удалось распарсить ответ в PersonData: %s".formatted(e.getMessage()));
					continue;
				}

				if (status == 200) {
					return personData;
				} else if (status == 400) {
					if (isUserKeyBlockedOrSessionNotFound(personData)) {
						return personData;
					}
					// Возможно, ошибка клиента, но продолжаем попытки
					log.info("Получен статус 400. Повторная попытка через %s миллисекунд.".formatted(delay));
				} else {
					// Другие ошибки, продолжаем попытки
					log.info("Получен статус %s. Повторная попытка через %s миллисекунд.".formatted(status, delay));
				}
			} catch (Exception e) {
				throw new RuntimeException("Error during request user data");
			}

			// Ожидание перед следующей попыткой
			try {
				Thread.sleep(delay);
			} catch (InterruptedException ie) {
				log.info("Поток был прерван во время ожидания");
				Thread.currentThread().interrupt();
				throw ie;
			}
		}

		// После всех попыток проверяем, есть ли ошибка
		if (personData != null && personData.error() != null) {
			// Возвращаем последний ответ с ошибкой
			return personData;
		} else {
			// Если и ошибка не заполнена, выбрасываем исключение
			throw new Exception("Не удалось получить успешный ответ после " + maxAttempts + " попыток");
		}
	}


	private String getUserDataServiceUrl(String sessionId, AuthenticationFlowContext context) {
		return "%s?sessionId=%s".formatted(context.getAuthenticatorConfig().getConfig().get(AccessByQRConstants.USER_DATA_SERVICE_URL), sessionId);
	}

	private String getBasicAuthorization(AuthenticationFlowContext context) {
		boolean isEnabledAuthorization = Boolean.parseBoolean(context.getAuthenticatorConfig().getConfig().get(AccessByQRConstants.USER_DATA_SERVICE_AUTHORIZATION));

		if (isEnabledAuthorization) {
			return "Basic " + Base64.getEncoder().encodeToString(
                    String.format("%s:%s",
                            context.getAuthenticatorConfig().getConfig().get(AccessByQRConstants.USER_DATA_SERVICE_LOGIN),
                            context.getAuthenticatorConfig().getConfig().get(AccessByQRConstants.USER_DATA_SERVICE_PASSWORD)
                    ).getBytes()
            );
		} else {
			return "";
		}
	}

	private boolean isUserKeyBlockedOrSessionNotFound(SessionDTO.Response.PersonData personData) {
		if (personData == null || personData.error() == null) {
			return false;
		}
		var errorDescription = personData.error().errorCodeDescriptor();
		return (errorDescription.equals(AccessByQRConstants.USER_SESSION_NOT_FOUND) || errorDescription.equals(AccessByQRConstants.USER_KEY_IS_BLOCKED));
	}
}
