package ru.mkb.accessbyqr.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.events.EventBuilder;
import org.keycloak.events.EventType;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.http.HttpRequest;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.models.UserProvider;
import org.keycloak.services.managers.AuthenticationManager;
import ru.mkb.accessbyqr.constant.AccessByQRConstants;
import ru.mkb.accessbyqr.dto.PaycontrolDTO;
import ru.mkb.accessbyqr.dto.SessionDTO;
import ru.mkb.accessbyqr.service.PaycontrolWebApiService;
import ru.mkb.accessbyqr.service.UserDataService;
import ru.mkb.accessbyqr.util.HttpUtil;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Log
public class AccessByQRAuthenticator implements Authenticator {
    private static final String ACCESS_BY_QR_FORM_TEMPLATE = "access-by-qr-code.ftl";
    private static final String DATE_TIME_FORMAT = "dd.MM.yyyy HH:mm:ss";
    private static final String USER_AGENT = "User-Agent";
    private static final String SESSION_ID = "sessionId";
    private static final String MAIN_TWO_FACTOR_TYPE = "main_two_factor_type";
    private static final String TWO_FACTOR_TYPE = "two_factor_type";
    private static final String CLIENT_PERSON_ID = "clientPersonId";
    private static final String RESEND_ACTION = "resend";
    private static final String BACK_BUTTON_ACTION = "backButton";
    private static final String ISO_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSSZ";
    private static final String IDENTIFY_DATE_TIME = "identifyDateTime";
    private static final String CERT_NUMBER = "CertNumber";
    private static final String SYSTEM_ERROR = "SystemError";
    private static final String INVALID_LOGIN_QR_CODE = "invalid_login_qr_code";
    private static final String MOSCOW_TIME_ZONE = "Europe/Moscow";
    private static final String ROOT_SIEBEL_ID = "rootSiebelId";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        createForm(context);
    }

    private void createForm(AuthenticationFlowContext context) {
        Optional.ofNullable(AuthenticationManager.authenticateIdentityCookie(context.getSession(), context.getRealm(), true))
                .ifPresentOrElse(authResult -> {
                    context.setUser(authResult.getUser());
                    context.success();
                }, ()-> {
                    initiateSession(context);
                    LoginFormsProvider form = context.form();
                    form.setAttribute("statusUrl", context.getAuthenticatorConfig().getConfig().get(AccessByQRConstants.PAYCONTROL_QR_CODE_SERVICE_URL));
                    context.challenge(form.createForm(ACCESS_BY_QR_FORM_TEMPLATE));
                });
    }

    private void initiateSession(AuthenticationFlowContext context) {
        try {
            String sessionId = new PaycontrolWebApiService().send(new PaycontrolDTO.Request.InitSession(buildHelloText(context)), context);
            context.getAuthenticationSession().setAuthNote(SESSION_ID, sessionId);
            context.form().setAttribute("sessionId", sessionId);
        } catch (Exception e) {
            createErrorPage(context);
        }
    }

    private static String buildHelloText(AuthenticationFlowContext context) {
        ZonedDateTime moscowTime = ZonedDateTime.now(ZoneId.of(MOSCOW_TIME_ZONE));
        LocalDateTime localMoscowTime = moscowTime.toLocalDateTime();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);

        String userAgent = getUserAgent(context.getHttpRequest());
        return "**Подтвердите вход в Ваш Банк Онлайн**\n\rБраузер\n\r**%s**\n\rОперационная система\n\r**%s**\n\rДата и время\n\r%s"
                .formatted(HttpUtil.extractBrowserInfo(userAgent), HttpUtil.extractOS(userAgent), localMoscowTime.format(formatter));
    }

    private static String getUserAgent(HttpRequest request) {
        return request.getHttpHeaders().getHeaderString(USER_AGENT);
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
        Optional<String> backButtonAction = Optional.ofNullable(formData.getFirst(BACK_BUTTON_ACTION));

        if (backButtonAction.isPresent()) {
            String mainTwoFactorType = context.getAuthenticationSession().getClientNote(MAIN_TWO_FACTOR_TYPE);
            context.getAuthenticationSession().setClientNote(TWO_FACTOR_TYPE, mainTwoFactorType);
            context.resetFlow();
            return;
        }

        Optional<String> resendAction = Optional.ofNullable(formData.getFirst(RESEND_ACTION));

        if (resendAction.isPresent()) {
            createForm(context);
            return;
        }

        String sessionId = Optional.ofNullable(formData.getFirst(SESSION_ID))
                .orElseThrow(() -> new RuntimeException("Session not found"));
        try {
            SessionDTO.Response.PersonData response = new UserDataService().request(sessionId, context);
            if (response.result() != null) {
                processSuccessfulResponse(response, context);
            } else if (response.error() != null) {
                handleErrorResponse(response.error(), context);
            } else {
                createErrorPageWithClearUser(context);
            }
        } catch (Exception e) {
            createErrorPageWithClearUser(context);
        }
    }

    private void handleErrorResponse(SessionDTO.Response.PersonData.Error error, AuthenticationFlowContext context) {
        log.warning("Сервис вернул ошибку: %s - %s".formatted(error.errorCodeDescriptor(), error.description()));
        createErrorPage(context, error.errorCodeDescriptor());
    }

    private void processSuccessfulResponse(SessionDTO.Response.PersonData response, AuthenticationFlowContext context) {
        Optional<String> userKeycloakId = getUserKeycloakId(response);
        if (userKeycloakId.isPresent()) {
            UserModel userModel = getUserById(context, userKeycloakId.get());
            context.setUser(userModel);
            context.getAuthenticationSession().setClientNote(IDENTIFY_DATE_TIME, formatDateTime(LocalDateTime.now()));
            context.getUser().setAttribute(CLIENT_PERSON_ID, List.of(getClientPersonId(response)));
            userModel.removeAttribute(CERT_NUMBER);
            context.getAuthenticationSession().setAuthNote(ROOT_SIEBEL_ID, Optional.ofNullable(context.getUser())
                    .map(um -> um.getFirstAttribute(ROOT_SIEBEL_ID))
                    .orElse(""));
            context.success();
        } else {
            log.warning("Не удалось получить userKeycloakId из ответа");
            createErrorPageWithClearUser(context);
        }
    }

    private void createErrorPageWithClearUser(AuthenticationFlowContext context) {
        createEvent(context);
        context.resetFlow();
        createErrorPage(context);
        context.clearUser();
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        createErrorPage(context, SYSTEM_ERROR);
    }

    private void createErrorPage(AuthenticationFlowContext context, String errorMessage) {
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(errorMessage)
                        .createErrorPage(Response.Status.BAD_REQUEST));
    }

    private static void createEvent(AuthenticationFlowContext context) {
        EventBuilder eventBuilder = context.getEvent();
        eventBuilder.event(EventType.LOGIN_ERROR);
        eventBuilder.session(context.getAuthenticationSession().getParentSession().getId());
        eventBuilder.error(INVALID_LOGIN_QR_CODE);
    }

    private static String formatDateTime(LocalDateTime localDateTime) {
        ZonedDateTime now = localDateTime.atZone(ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_DATE_TIME_FORMAT);
        return now.format(formatter);
    }

    private static String getClientPersonId(SessionDTO.Response.PersonData response) {
        return Optional.of(response).map(SessionDTO.Response.PersonData::result)
                .map(SessionDTO.Response.PersonData.Result::clientPersonId)
                .orElseThrow(() -> new RuntimeException("clientPersonId not found"));
    }

    private UserModel getUserById(AuthenticationFlowContext context, String userId) {
        return Optional.ofNullable(findUserById(userId, context))
                .orElseThrow(() -> new RuntimeException("User with id %s not found".formatted(userId)));
    }

    private static Optional<String> getUserKeycloakId(SessionDTO.Response.PersonData response) {
        return Optional.of(response).map(SessionDTO.Response.PersonData::result)
                .map(SessionDTO.Response.PersonData.Result::personKeycloakId);
    }

    public UserModel findUserById(String userId, AuthenticationFlowContext context) {
        UserProvider userProvider = context.getSession().users();
        return userProvider.getUserById(context.getRealm(), userId);
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}