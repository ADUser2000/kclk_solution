package ru.mkb.accessbyqr.dto;

public final class PaycontrolDTO {
    private PaycontrolDTO() {
    }

    public static class Request {
        public record InitSession(String helloText) {
        }

        public record QRCode(String sessionId) {
        }
    }

    public static class Response {
        public record QRCode(Boolean isRefreshRequired, String loginQR) {
        }
    }
}


