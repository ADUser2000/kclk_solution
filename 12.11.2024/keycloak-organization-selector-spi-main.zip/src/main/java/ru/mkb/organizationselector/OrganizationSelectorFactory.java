package ru.mkb.organizationselector;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.models.credential.PasswordCredentialModel;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.organizationselector.authenticator.OrganizationSelectorAuthenticator;
import ru.mkb.organizationselector.constant.OrganizationSelectorConstants;

import java.util.List;

public class OrganizationSelectorFactory implements AuthenticatorFactory {
    public static final String PROVIDER_ID = "organization-selector";
    public static final OrganizationSelectorAuthenticator SINGLETON = new OrganizationSelectorAuthenticator();

    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return List.of(
                new ProviderConfigProperty(OrganizationSelectorConstants.USER_DATA_SERVICE_URL, "User data service url", "example: http://localhost:8080/.", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(OrganizationSelectorConstants.USER_DATA_SERVICE_AUTHORIZATION, "Enabled authorization", "", ProviderConfigProperty.BOOLEAN_TYPE, false),
                new ProviderConfigProperty(OrganizationSelectorConstants.USER_DATA_SERVICE_LOGIN, "login", "Login for user data service url", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(OrganizationSelectorConstants.USER_DATA_SERVICE_PASSWORD, "password", "password for user data service url", ProviderConfigProperty.PASSWORD, ""),
                new ProviderConfigProperty(OrganizationSelectorConstants.SIGN_SERVICE_URL, "Sign service url", "example: http://localhost:8080/.", ProviderConfigProperty.STRING_TYPE, ""),
                new ProviderConfigProperty(OrganizationSelectorConstants.SIMULATION_MODE, "Simulation mode", "In simulation mode, sign check request not will execute", ProviderConfigProperty.BOOLEAN_TYPE, false),
                new ProviderConfigProperty(OrganizationSelectorConstants.CERTIFICATE_NUMBER_ATTRIBUTE, "Attribute for setting certificate number", "Setting when user select organization", ProviderConfigProperty.STRING_TYPE, "")
        );
    }

    @Override
    public void init(Config.Scope config) {

    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getReferenceCategory() {
        return PasswordCredentialModel.TYPE;
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    public static final AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
            AuthenticationExecutionModel.Requirement.REQUIRED,
            AuthenticationExecutionModel.Requirement.ALTERNATIVE
    };

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }
    @Override
    public String getDisplayType() {
        return "SPI: organization selector";
    }

    @Override
    public String getHelpText() {
        return "SPI: organization selector";
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }
}