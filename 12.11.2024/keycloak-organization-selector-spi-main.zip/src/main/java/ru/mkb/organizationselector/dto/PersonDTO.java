package ru.mkb.organizationselector.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

public final class PersonDTO {
    private PersonDTO() {
    }

    public static class Request {
        public record Person(String personKeycloakId, String phone, String email) {
            public Person(String personKeycloakId) {
                this(personKeycloakId, null, null);
            }
        }

        public record Sign(boolean isAttached, String messageBase64, String signatureBase64) {
            @Override
            public String toString() {
                return String.format("Sign{isAttached=%s, messageBase64=%s, signatureBase64=%s}", isAttached, messageBase64, signatureBase64);
            }
        }
    }

    public static class Response {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record PersonData(Result result, Error error, String traceId) {
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Error(String description, String errorCodeDescriptor) {}
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Result(Person person) {}
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Person(String personKeycloakId, String lastName, String firstName, String middleName, String lastNameTranslit, List<Official> officials) {}
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Official(String officialSiebelId, String organizationFullName, String organizationShortName, String organizationClientCode, String phone, String email, List<CertificateInfo> certificateInfo) {}
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record CertificateInfo(String certificateNumber, String validFrom, String validTo, String cryptoProfileType) {}
        }
    }
}




