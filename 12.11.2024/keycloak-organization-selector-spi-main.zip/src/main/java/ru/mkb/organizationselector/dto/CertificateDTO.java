package ru.mkb.organizationselector.dto;

public record CertificateDTO(String thumbprint, String serialNumber) {
}
