package ru.mkb.organizationselector.authenticator;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.events.EventBuilder;
import org.keycloak.events.EventType;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.AuthenticatorConfigModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import ru.mkb.organizationselector.constant.OrganizationSelectorConstants;
import ru.mkb.organizationselector.dto.CertificateDTO;
import ru.mkb.organizationselector.dto.OrganizationDTO;
import ru.mkb.organizationselector.dto.PersonDTO;
import ru.mkb.organizationselector.service.SignService;
import ru.mkb.organizationselector.service.UserCertificatesService;

import java.security.MessageDigest;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Log
public class OrganizationSelectorAuthenticator implements Authenticator {
    private static final String ORGANIZATION_SELECTOR_PAGE = "certificate-selector.ftl";
    private static final String ORGANIZATION_ID = "organizationId";
    private static final String PHONE = "phone";
    private static final String CERTIFICATES = "certificates";
    private static final String SHA_256 = "SHA-256";
    private static final String DIGEST_DATA = "fcc22de527fe47ec99fe158aeea92de4";
    private static final String DIGEST = "digest";
    private static final String SIGN = "sign";
    private static final String CERTIFICATE_NUMBER = "certificateNumber";
    private static final String TWO_FACTOR_TYPE = "two_factor_type";
    private static final String CRYPTO_CONTAINER_NOT_AVAILABLE = "crypto_container_not_available";
    private static final String USER_ID = "userId";
    private static final String SMS_OTP = "sms_otp";
    private static final String CHANGED_TWO_FACTOR_TYPE = "changed_two_factor_type";
    private static final String ERROR_ACCESS_TO_CRYPTO_CONTAINER = "errorAccessToCryptoContainer";
    private static final String INVALID_CERTIFICATION_VALIDATION = "invalid_certification_validation";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final String SYSTEM_ERROR = "SystemError";
    private static final String CERTIFICATE_NUMBER_ATTRIBUTE = "certificate_number";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        List<CertificateDTO> certificateDTOS = getUserCertificates(context);
        PersonDTO.Request.Person personRequest = new PersonDTO.Request.Person(context.getUser().getId());
        PersonDTO.Response.PersonData personData = null;
        try {
            personData = new UserCertificatesService().requestUserData(personRequest, context);
        } catch (Exception e) {
            createErrorPage(context);
        }

        if (personData == null) {
            createErrorPage(context);
            return;
        } else if (personData.error() != null) {
            createErrorPage(context, personData.error().errorCodeDescriptor());
            return;
        }

        PersonDTO.Response.PersonData.Person person = personData.result().person();
        String userFullName = "%s %s %s".formatted(person.lastName(), person.firstName(), person.middleName());

        List<OrganizationDTO> organizations = getOrganizations(person, certificateDTOS, userFullName);
        Boolean changedTwoFactorType = Optional.ofNullable(context.getAuthenticationSession().getClientNote(CHANGED_TWO_FACTOR_TYPE))
                .map(Boolean::valueOf)
                .orElse(false);
        LoginFormsProvider form = context.form();

        if (changedTwoFactorType && organizations.isEmpty()) {
            form.setAttribute("isNotAvailableCertificate", true);
        } else if (organizations.isEmpty()) {
            context.getAuthenticationSession().setClientNote(TWO_FACTOR_TYPE, SMS_OTP);
            context.getAuthenticationSession().setClientNote(USER_ID, context.getUser().getId());
            context.resetFlow();
            return;
        } else {
            String digest = generateDigest();
            form.setAttribute("certificates", organizations);
            form.setAttribute(DIGEST, digest);

            context.getAuthenticationSession().setAuthNote(DIGEST, digest);
        }

        context.challenge(form.createForm(ORGANIZATION_SELECTOR_PAGE));
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        createErrorPage(context, SYSTEM_ERROR);
    }

    private void createErrorPage(AuthenticationFlowContext context, String error) {
        context.resetFlow();
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(error)
                        .createErrorPage(Response.Status.BAD_REQUEST));
        context.clearUser();
    }

    private static List<OrganizationDTO> getOrganizations(PersonDTO.Response.PersonData.Person person, List<CertificateDTO> certificateDTOS, String userFullName) {
        return person.officials().stream()
                .flatMap(official -> official.certificateInfo().stream()
                        .flatMap(certificateInfo -> certificateDTOS.stream()
                                .filter(certificateDTO -> certificateDTO.serialNumber().equalsIgnoreCase(certificateInfo.certificateNumber())
                                        && isCertificateDateTimeValid(certificateInfo.validTo()))
                                .map(certificateDTO -> new OrganizationDTO(
                                        official.officialSiebelId(),
                                        official.organizationShortName(),
                                        userFullName,
                                        certificateInfo.validTo(),
                                        certificateInfo.certificateNumber(),
                                        certificateDTO.thumbprint()
                                ))
                        ))
                .collect(Collectors.toList());
    }

    private static boolean isCertificateDateTimeValid(String certificateDateTime) {
        ZonedDateTime validTo = ZonedDateTime.parse(certificateDateTime, DateTimeFormatter.ISO_DATE_TIME);
        ZonedDateTime now = ZonedDateTime.now(validTo.getZone());
        return !now.isAfter(validTo);
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();

        Optional<String> backButtonAction = Optional.ofNullable(formData.getFirst("backButton"));

        if (backButtonAction.isPresent()) {
            context.getAuthenticationSession().removeClientNote(USER_ID);
            context.resetFlow();
            return;
        }

        Optional<String> twoFactorType = Optional.ofNullable(formData.get(TWO_FACTOR_TYPE)).orElse(List.of()).stream().findFirst();
        boolean cryptoContainerNotAvailable = Optional.ofNullable(formData.get(CRYPTO_CONTAINER_NOT_AVAILABLE)).orElse(List.of()).stream().findFirst().isPresent();

        if (cryptoContainerNotAvailable) {
            context.resetFlow();
            context.failureChallenge(AuthenticationFlowError.ACCESS_DENIED,
                    context.form().setError(ERROR_ACCESS_TO_CRYPTO_CONTAINER)
                            .createErrorPage(Response.Status.BAD_REQUEST));
            return;
        }

        if (twoFactorType.isPresent()) {
            context.getAuthenticationSession().setClientNote(TWO_FACTOR_TYPE, twoFactorType.get());
            context.getAuthenticationSession().setClientNote(USER_ID, context.getUser().getId());
            context.resetFlow();
            return;
        }

        String organizationId = formData.get(ORGANIZATION_ID).stream().findFirst()
                .orElseThrow(() -> new RuntimeException("Hasn't organization id"));
        String certificateNumber = formData.get(CERTIFICATE_NUMBER).stream().findFirst()
                .orElseThrow(() -> new RuntimeException("Hasn't certificate number"));
        String sign = formData.get(SIGN).stream().findFirst()
                .orElseThrow(() -> new RuntimeException("Hasn't sign"));
        String digest = context.getAuthenticationSession().getAuthNote(DIGEST);
        AuthenticatorConfigModel config = context.getAuthenticatorConfig();

        context.getAuthenticationSession().setAuthNote(CERTIFICATE_NUMBER_ATTRIBUTE, certificateNumber);

        if (!Boolean.parseBoolean(config.getConfig().get(OrganizationSelectorConstants.SIMULATION_MODE))) {
            try {
                log.info("source digest: %s".formatted(digest));
                log.info("source sign: %s".formatted(sign));
                PersonDTO.Response.PersonData personData = new SignService().checkSign(new PersonDTO.Request.Sign(true, Base64.getEncoder().encodeToString(digest.getBytes()), sign), context);
                if (personData != null && personData.error() != null) {
                    createFailureTemporarilyDisabled(context, personData.error().errorCodeDescriptor());
                }
            } catch (Exception ex) {
                createErrorPage(context);
                return;
            }
        }

        String phone = context.getAuthenticationSession().getAuthNote(organizationId);
        context.getAuthenticationSession().setAuthNote(PHONE, phone);
        context.getUser().setAttribute(getOrganizationIdAttributeName(context), List.of(certificateNumber));
        context.success();
    }

    private void createFailureTemporarilyDisabled(AuthenticationFlowContext context, String error) {
        createEvent(context);
        context.resetFlow();
        context.failureChallenge(AuthenticationFlowError.ACCESS_DENIED,
                context.form().setError(error).createErrorPage(Response.Status.BAD_REQUEST));
    }

    private static void createEvent(AuthenticationFlowContext context) {
        EventBuilder eventBuilder = context.newEvent();
        eventBuilder.event(EventType.LOGIN_ERROR);
        eventBuilder.user(Optional.ofNullable(context.getUser())
                .map(UserModel::getId)
                .orElse(null));
        eventBuilder.session(context.getAuthenticationSession().getParentSession().getId());
        eventBuilder.error(OrganizationSelectorAuthenticator.INVALID_CERTIFICATION_VALIDATION);
    }

    @SneakyThrows
    private List<CertificateDTO> getUserCertificates(AuthenticationFlowContext context) {
        String jsonString = context.getAuthenticationSession().getAuthNote(CERTIFICATES);
        log.info("User certificates: %s".formatted(jsonString));
        List<String> jsonCertificates = OBJECT_MAPPER.readValue(jsonString, new TypeReference<>() {});

        return jsonCertificates.stream()
                .map(jsonStr -> {
                    try {
                        return OBJECT_MAPPER.readValue(jsonStr, CertificateDTO.class);
                    } catch (Exception e) {
                        throw new RuntimeException("Error deserializing certificate", e);
                    }
                })
                .collect(Collectors.toList());
    }

    private static String generateDigest() {
        try {
            // Получение текущего времени в миллисекундах
            long currentTimeMillis = System.currentTimeMillis();
            // Добавление временной метки к данным
            String dataWithTime = DIGEST_DATA + currentTimeMillis;

            // Создание экземпляра MessageDigest с указанным алгоритмом
            MessageDigest digest = MessageDigest.getInstance(SHA_256);

            // Выполнение хеширования данных с временной меткой
            byte[] encodedhash = digest.digest(dataWithTime.getBytes());

            // Преобразование хеша в шестнадцатеричный формат
            StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
            for (byte b : encodedhash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String getOrganizationIdAttributeName(AuthenticationFlowContext context) {
        return context.getAuthenticatorConfig().getConfig().get(OrganizationSelectorConstants.CERTIFICATE_NUMBER_ATTRIBUTE);
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {

    }

    @Override
    public void close() {
    }
}