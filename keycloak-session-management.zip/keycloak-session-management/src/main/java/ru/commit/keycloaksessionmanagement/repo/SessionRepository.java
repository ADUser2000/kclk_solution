package ru.commit.keycloaksessionmanagement.repo;

import ru.commit.keycloaksessionmanagement.model.SessionInfo;
import ru.commit.keycloaksessionmanagement.util.ConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SessionRepository {
    private static final SessionRepository INSTANCE = new SessionRepository();

    private SessionRepository(){}

    private static final String FIND_BY_ID = """
            SELECT session_id,
                   user_id,
                   createdTime,
                   ipAddress,
                   browser
            FROM session_info
            WHERE session_id = ?
            """;

    private static final String FIND_ALL = """
            SELECT session_id,
                   user_id,
                   createdTime,
                   ipAddress,
                   browser
            FROM session_info
            """;

    public Optional<SessionInfo> findById(Integer id) {
        try (Connection connection = ConnectionPool.get();
             PreparedStatement preparedStatement = connection.prepareStatement(FIND_BY_ID)) {
            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            SessionInfo sessionInfo = null;
            if (resultSet.next()) {
                sessionInfo = new SessionInfo(
                        resultSet.getString("session_id"),
                        resultSet.getString("user_id"),
                        resultSet.getLong("createdTime"),
                        resultSet.getString("ipAddress"),
                        resultSet.getString("browser")
                );
            }
            return Optional.ofNullable(sessionInfo);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<SessionInfo> findAll() {
        try (Connection connection = ConnectionPool.get();
             PreparedStatement preparedStatement = connection.prepareStatement(FIND_ALL)) {

            ResultSet resultSet = preparedStatement.executeQuery();
            List<SessionInfo> list = new ArrayList<>();
            while (resultSet.next()) {
                list.add(new SessionInfo(
                        resultSet.getString("session_id"),
                        resultSet.getString("user_id"),
                        resultSet.getLong("createdTime"),
                        resultSet.getString("ipAddress"),
                        resultSet.getString("browser")
                ));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static SessionRepository getInstance() {
        return INSTANCE;
    }
}
