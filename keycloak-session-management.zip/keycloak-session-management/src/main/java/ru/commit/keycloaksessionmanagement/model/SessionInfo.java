package ru.commit.keycloaksessionmanagement.model;

public record SessionInfo(String sessionId,
                          String userId,
                          long createdTime,
                          String ipAddress,
                          String browser) {
}
