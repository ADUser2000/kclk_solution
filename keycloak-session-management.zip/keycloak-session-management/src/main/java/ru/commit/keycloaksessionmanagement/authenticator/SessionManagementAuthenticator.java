package ru.commit.keycloaksessionmanagement.authenticator;

import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.models.UserSessionModel;

import java.util.List;

@Log
public class SessionManagementAuthenticator implements Authenticator {

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        UserModel user = context.getUser();
        KeycloakSession session = context.getSession();
        RealmModel realm = context.getRealm();

        if (user == null) {
            context.attempted();
            return;
        }

        List<UserSessionModel> userSessions = session.sessions().getUserSessionsStream(realm, user)
                .filter(s -> !s.isOffline()).toList();

        if (userSessions.isEmpty()) {
            log.info("No active sessions found, proceeding with authentication for user: " + user.getUsername());
            context.success();
            return;
        }

        log.info("Active sessions found, revoking all existing sessions for user: " + user.getUsername());
        for (UserSessionModel userSession : userSessions) {
            closeSession(context, userSession.getId());
            log.info("SESSION REMOVED FOR USER %s".formatted(user.getUsername()));
        }

        context.success();
    }

    @Override
    public void action(AuthenticationFlowContext context) {
    }

    private void closeSession(AuthenticationFlowContext context, String sessionId) {
        KeycloakSession session = context.getSession();
        RealmModel realm = context.getRealm();
        UserSessionModel sessionToRevoke = session.sessions().getUserSession(realm, sessionId);
        if (sessionToRevoke != null) {
            session.sessions().removeUserSession(realm, sessionToRevoke);
            log.info("Session revoked: " + sessionId);
        } else {
            log.warning("Session not found, cannot revoke: " + sessionId);
        }
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}