package ru.mkb.accessbyqr.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class AccessByQRConstants {
	public String PAYCONTROL_WEB_API_URL = "paycontrolWebApiUrl";
	public String PAYCONTROL_QR_CODE_SERVICE_URL = "paycontrolQRCodeServiceUrl";
	public String USER_DATA_SERVICE_URL = "userDataServiceUrl";
	public String USER_DATA_SERVICE_AUTHORIZATION = "userDataServiceAuthorization";
	public String USER_DATA_SERVICE_LOGIN = "userDataServiceLogin";
	public String USER_DATA_SERVICE_PASSWORD = "userDataServicePassword";
}
