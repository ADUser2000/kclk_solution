package ru.mkb.accessbyqr.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public final class SessionDTO {
    private SessionDTO() {
    }

    public static class Response {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record PersonData(Result result, Error error, String traceId) {
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Result(String personKeycloakId, String clientPersonId) {}
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Error(String description, String errorCodeDescriptor) {}
        }
    }
}
