package ru.mkb.changepassword.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ChangePasswordConstants {
	public String DEV_MODE = "dev_mode";
	public String REGISTRATION_SERVICE_URL = "registration_service_url";
}
