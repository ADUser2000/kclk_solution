package ru.mkb.changepassword.authenticator;

import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.credential.CredentialProvider;
import org.keycloak.credential.PasswordCredentialProvider;
import org.keycloak.credential.PasswordCredentialProviderFactory;
import org.keycloak.events.EventBuilder;
import org.keycloak.events.EventType;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserCredentialModel;
import org.keycloak.models.UserModel;
import ru.mkb.changepassword.constant.ChangePasswordConstants;
import ru.mkb.changepassword.dto.RegistrationDTO;
import ru.mkb.changepassword.service.RegistrationService;

import java.util.List;
import java.util.Optional;

@Log
public class ChangePasswordAuthenticator implements Authenticator {
    private static final String PASSWORD = "password";
    private static final String MAGIC_LINK_TOKEN_ATTRIBUTE = "magic_link_token";
    private static final String RESET_PASSWORD = "reset-password";
    private static final String TWO_FACTOR_TYPE = "two_factor_type";
    private static final String NEW_USER = "new_user";
    private static final String DEMAND_ID = "demandId";
    private static final String LOGIN = "login";
    private static final String SYSTEM_ERROR = "SystemError";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        String password = context.getAuthenticationSession().getAuthNote(PASSWORD);
        PasswordCredentialProvider passwordProvider = (PasswordCredentialProvider) context.getSession().getProvider(CredentialProvider.class, PasswordCredentialProviderFactory.PROVIDER_ID);
        passwordProvider.updateCredential(context.getRealm(), context.getUser(), UserCredentialModel.password(password));
        createEvent(context, EventType.RESET_PASSWORD, RESET_PASSWORD);
        if (isNewUserTwoFactorEnabled(context)) {
            String login = Optional.ofNullable(context.getAuthenticationSession().getAuthNote(LOGIN))
                    .orElseThrow(() -> new RuntimeException("New user login wasn't set"));
            context.getUser().setUsername(login);
            if (isDevModeDisabled(context)) {
                try {
                    new RegistrationService().sendLogin(new RegistrationDTO(login, context.getUser().getId(), getDemandId(context.getUser())), context);
                } catch (Exception e) {
                    createErrorPage(context);
                    return;
                }
            }
            context.getUser().removeAttribute(MAGIC_LINK_TOKEN_ATTRIBUTE);
            context.success();
        } else {
            context.fork();
        }
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(SYSTEM_ERROR)
                        .createErrorPage(Response.Status.BAD_REQUEST));
    }

    private static Boolean isNewUserTwoFactorEnabled(AuthenticationFlowContext context) {
        return Optional.ofNullable(context.getAuthenticationSession())
                .map(authenticationSessionModel -> authenticationSessionModel.getClientNote(TWO_FACTOR_TYPE))
                .map(twoFactorType -> twoFactorType.equals(NEW_USER))
                .orElse(false);
    }

    private static void createEvent(AuthenticationFlowContext context, EventType eventType, String details) {
        EventBuilder eventBuilder = context.newEvent();
        eventBuilder.event(eventType);
        eventBuilder.user(Optional.ofNullable(context.getUser())
                .map(UserModel::getId)
                .orElse(null));
        eventBuilder.session(context.getAuthenticationSession().getParentSession().getId());
        eventBuilder.detail(details, "success");
        eventBuilder.success();
    }

    private static String getDemandId(UserModel user) {
        return Optional.ofNullable(user.getAttributes().get(DEMAND_ID))
                .orElse(List.of()).stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Not fount DemandId for user: %s".concat(user.getId())));
    }

    private boolean isDevModeDisabled(AuthenticationFlowContext context) {
        return !Boolean.parseBoolean(context.getAuthenticatorConfig().getConfig().get(ChangePasswordConstants.DEV_MODE));
    }

    @Override
    public void action(AuthenticationFlowContext context) {
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}