package ru.mkb.changepassword.dto;

public record RegistrationDTO(String Login, String PersonSsoId, String DemandId) {
}
