package ru.mkb.organizationselector.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationDTO {
    private String id;
    private String name;
    private String agentName;
    private String certificateExpireDate;
    private String certificateNumber;
    private String thumbprint;
}
