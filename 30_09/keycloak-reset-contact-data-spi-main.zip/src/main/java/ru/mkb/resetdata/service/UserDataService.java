package ru.mkb.resetdata.service;

import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.resetdata.constant.ResetDataConstants;
import ru.mkb.resetdata.dto.PersonDTO;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import java.util.Base64;
import java.util.Optional;

@Log
public class UserDataService {

	@SneakyThrows
	public PersonDTO.Response.UserDataResponse requestUserData(PersonDTO.Request.Person person, AuthenticationFlowContext context) {
		String userDataServiceUrl = getUserDataServiceUrl(context);
		SimpleHttp simpleHttp = SimpleHttp.doPost(userDataServiceUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, getBasicAuthorization(context))
				.json(person);

		log.info("make request to: %s".formatted(userDataServiceUrl));
		try (SimpleHttp.Response response = simpleHttp.asResponse()) {
			log.info("Response with status code: %s".formatted(response.getStatus()));
			log.info("Response data: %s".formatted(response.asString()));

			if (response.getStatus() == 200 || response.getStatus() == 400) {
				return response.asJson(PersonDTO.Response.UserDataResponse.class);
			} else {
				throw new RuntimeException("userId: %s | Error during request user data: %s".formatted(context.getUser().getId(), response.getStatus()));
			}
		}
	}

	private String getUserDataServiceUrl(AuthenticationFlowContext context) {
		return context.getAuthenticatorConfig().getConfig().get(ResetDataConstants.USER_DATA_SERVICE_URL);
	}

	private String getBasicAuthorization(AuthenticationFlowContext context) {
		boolean isEnabledAuthorization = Boolean.parseBoolean(context.getAuthenticatorConfig().getConfig().get(ResetDataConstants.USER_DATA_SERVICE_AUTHORIZATION));

		if (isEnabledAuthorization) {
			return "Basic " + Base64.getEncoder().encodeToString(
                    String.format("%s:%s",
                            context.getAuthenticatorConfig().getConfig().get(ResetDataConstants.USER_DATA_SERVICE_LOGIN),
                            context.getAuthenticatorConfig().getConfig().get(ResetDataConstants.USER_DATA_SERVICE_PASSWORD)
                    ).getBytes()
            );
		} else {
			return "";
		}
	}
}
