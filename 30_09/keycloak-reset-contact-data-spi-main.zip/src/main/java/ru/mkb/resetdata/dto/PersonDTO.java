package ru.mkb.resetdata.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

public final class PersonDTO {
    private PersonDTO() {
    }

    public static class Request {
        public record Person(String personKeycloakId, String phone, String email) {
            public Person(String phone, String email) {
                this(null, phone, email);
            }
        }
    }

    public static class Response {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record UserDataResponse(String traceId, Result result, Error error) {
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Result(String phone, String email, List<String> personKeycloakId) {}
            @JsonIgnoreProperties(ignoreUnknown = true)
            public record Error(String description, String errorCodeDescriptor) {}
        }
    }
}
