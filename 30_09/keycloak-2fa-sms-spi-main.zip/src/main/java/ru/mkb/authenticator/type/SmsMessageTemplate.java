package ru.mkb.authenticator.type;

public enum SmsMessageTemplate {
    TWO_FA,
    RESET_LOGIN_OTP,
}
