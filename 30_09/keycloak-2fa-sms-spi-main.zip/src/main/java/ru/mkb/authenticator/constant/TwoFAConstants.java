package ru.mkb.authenticator.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class TwoFAConstants {
	public String CODE = "codeOTP";
	public String RESEND_SMS = "resend_sms";
	public String CODE_LENGTH = "length";
	public String CODE_TTL = "ttl";
	public String ATTEMPT_VALIDATE_COUNT = "attempt_validate_count";
	public String NOTIFICATION_URL = "notificationUrl";
	public String MNEMONIC_TYPE = "mnemonicType";
	public String SIMULATION_MODE = "simulation";
	public String TEST_OTP_CODE = "testOtpCode";
	public String PHONE = "phone";
	public String RESET_CREDENTIALS_USER_ID = "userId";
	public String BLOCKED = "blocked";
	public String DEFAULT_COUNT_ATTEMPT_VALIDATION = "default_count_attempt_validation";
	public String PAGE_TITLE = "otp_page_title";
}
