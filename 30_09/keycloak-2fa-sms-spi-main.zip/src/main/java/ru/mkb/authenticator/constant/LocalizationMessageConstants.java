package ru.mkb.authenticator.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class LocalizationMessageConstants {
    public String SMS_AUTH_SYSTEM_ERROR = "SystemError";
    public String SMS_AUTH_CODE_INVALID = "smsAuthCodeInvalid";
    public String TEMPORARILY_DISABLED = "temporarilyDisabled";
}
