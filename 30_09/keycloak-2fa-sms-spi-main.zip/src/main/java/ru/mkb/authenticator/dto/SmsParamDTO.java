package ru.mkb.authenticator.dto;

public record SmsParamDTO(String name, String value) {
}
