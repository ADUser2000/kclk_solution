package ru.mkb.authenticator.dto;

import java.util.List;

public record NotificationDTO(String phone, String clientCode, String mnemonicType, List<SmsParamDTO> smsParams) {
}