package ru.mkb.service;

import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.broker.provider.util.SimpleHttp;
import ru.mkb.constant.PhoneNumberSelectorConstants;
import ru.mkb.dto.PersonDTO;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Base64;
import java.util.Optional;

@Log
public class UserDataService {

	@SneakyThrows
	public PersonDTO.Response.PersonData requestUserData(PersonDTO.Request.Person person, AuthenticationFlowContext context) {
		String userDataServiceUrl = getUserDataServiceUrl(context);
		SimpleHttp simpleHttp = SimpleHttp.doPost(userDataServiceUrl, context.getSession())
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
				.header(HttpHeaders.AUTHORIZATION, getBasicAuthorization(context))
				.json(person);

		log.info("userId: %s | make request to: %s".formatted(context.getUser().getId(), userDataServiceUrl));
		try (SimpleHttp.Response response = simpleHttp.asResponse()) {
			log.info("userId: %s | Response with status code: %s".formatted(context.getUser(), response.getStatus()));
			log.info("userId: %s | Response data: %s".formatted(context.getUser().getId(), response.asString()));

			if (response.getStatus() == 200 || response.getStatus() == 400) {
				return response.asJson(PersonDTO.Response.PersonData.class);
			} else {
				throw new RuntimeException("userId: %s | Error during request user data: %s".formatted(context.getUser().getId(), response.getStatus()));
			}
        }
    }

	private String getUserDataServiceUrl(AuthenticationFlowContext context) {
		return context.getAuthenticatorConfig().getConfig().get(PhoneNumberSelectorConstants.USER_DATA_SERVICE_URL);
	}

	private String getBasicAuthorization(AuthenticationFlowContext context) {
		boolean isEnabledAuthorization = Boolean.parseBoolean(context.getAuthenticatorConfig().getConfig().get(PhoneNumberSelectorConstants.USER_DATA_SERVICE_AUTHORIZATION));

		if (isEnabledAuthorization) {
			return "Basic " + Base64.getEncoder().encodeToString(
                    String.format("%s:%s",
                            context.getAuthenticatorConfig().getConfig().get(PhoneNumberSelectorConstants.USER_DATA_SERVICE_LOGIN),
                            context.getAuthenticatorConfig().getConfig().get(PhoneNumberSelectorConstants.USER_DATA_SERVICE_PASSWORD)
                    ).getBytes()
            );
		} else {
			return "";
		}
	}
}
