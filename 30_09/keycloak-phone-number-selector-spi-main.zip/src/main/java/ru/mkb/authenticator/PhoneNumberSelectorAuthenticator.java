package ru.mkb.authenticator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.common.util.Time;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserLoginFailureModel;
import org.keycloak.models.UserModel;
import org.keycloak.services.managers.BruteForceProtector;
import ru.mkb.constant.PhoneNumberSelectorConstants;
import ru.mkb.dto.PersonDTO;
import ru.mkb.dto.PhoneDTO;
import ru.mkb.service.UserDataService;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Log
public class PhoneNumberSelectorAuthenticator implements Authenticator {
    private static final String PHONE_NUMBER_SELECTOR_PAGE = "phone-number-selector.ftl";
    private static final String PHONE = "phone";
    private static final String CLIENT_CODE = "clientCode";
    private static final String ORGANIZATION_SHORT_NAME = "organizationShortName";
    private static final String TWO_FACTOR_TYPE = "two_factor_type";
    private static final String USER_ID = "userId";
    private static final String CHANGED_TWO_FACTOR_TYPE = "changed_two_factor_type";
    private static final String FIO = "FIO";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final String PHONES = "phones";
    private static final String TEMPORARILY_DISABLED = "temporarilyDisabled";
    private static final String SYSTEM_ERROR = "SystemError";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        if (isTemporarilyDisabled(context)) {
            createFailureTemporarilyDisabled(context);
            return;
        }

        PersonDTO.Response.PersonData personData = null;

        try {

            PersonDTO.Request.Person person = new PersonDTO.Request.Person(context.getUser().getId());
            personData = new UserDataService().requestUserData(person, context);

            if (personData != null && personData.error() != null) {
                createErrorPage(context, personData.error().errorCodeDescriptor());
                return;
            }
        } catch (Exception e) {
            createErrorPage(context);
        }

        if (personData != null) {
            Set<String> phones = personData.result().person().officials().stream()
                    .map(official -> {
                        context.getAuthenticationSession().setAuthNote(official.phone() + CLIENT_CODE, official.organizationClientCode());
                        context.getAuthenticationSession().setAuthNote(official.phone() + ORGANIZATION_SHORT_NAME, official.organizationShortName());
                        return official.phone();
                    })
                    .collect(Collectors.toSet());

            if (phones.isEmpty()) {
                createErrorPage(context);
                return;
            }

            AtomicInteger idCounter = new AtomicInteger(1);
            List<PhoneDTO> phoneDTOList = phones.stream()
                    .map(phone -> new PhoneDTO(String.valueOf(idCounter.getAndIncrement()), phone))
                    .toList();
            List<PhoneDTO> maskedPhoneNumbers = phoneDTOList.stream().map(PhoneNumberSelectorAuthenticator::maskPhoneNumber).toList();

            context.getAuthenticationSession().setAuthNote(FIO, getFIO(personData));
            LoginFormsProvider form = context.form();
            form.setAttribute("phones", maskedPhoneNumbers);
            form.setAttribute("authByCertificateButton", Boolean.valueOf(context.getAuthenticatorConfig().getConfig().get(PhoneNumberSelectorConstants.ENABLED_AUTH_BY_CERTIFICATE_BUTTON)));

            context.getAuthenticationSession().setAuthNote(PHONES, convertObjectToJson(phoneDTOList));

            context.challenge(form.createForm(PHONE_NUMBER_SELECTOR_PAGE));
        } else {
            createErrorPage(context);
        }
    }

    private void createFailureTemporarilyDisabled(AuthenticationFlowContext context) {
        context.resetFlow();
        String userId = context.getUser().getId();
        context.failureChallenge(AuthenticationFlowError.USER_TEMPORARILY_DISABLED,
                context.form().setError(TEMPORARILY_DISABLED)
                        .setAttribute("temporarilyBlockSecond", temporarilyBlockSecond(context, userId))
                        .createErrorPage(Response.Status.BAD_REQUEST));
        context.clearUser();
    }

    private long temporarilyBlockSecond(AuthenticationFlowContext context, String userId) {
        UserLoginFailureModel failure = context.getSession().loginFailures().getUserLoginFailure(context.getRealm(), userId);
        if (failure != null) {
            return Math.max(failure.getFailedLoginNotBefore() - Time.currentTimeMillis() / 1000, 0L);
        }
        return 0L;
    }

    private static boolean isTemporarilyDisabled(AuthenticationFlowContext context) {
        return getUser(context).isPresent() && context.getSession().getProvider(BruteForceProtector.class).isTemporarilyDisabled(context.getSession(), context.getRealm(), context.getUser());
    }

    private static Optional<UserModel> getUser(AuthenticationFlowContext context) {
        return Optional.ofNullable(context.getUser());
    }

    private String convertObjectToJson(List<PhoneDTO> phoneDTOList) {
        try {
            return OBJECT_MAPPER.writeValueAsString(phoneDTOList);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private static PhoneDTO maskPhoneNumber(PhoneDTO phoneDTO) {
        String title = phoneDTO.getTitle();
        String maskedPhoneNumber = title.substring(0, 4) + "*****" + title.substring(title.length() - 2);

        return new PhoneDTO(phoneDTO.getValue(), maskedPhoneNumber);
    }

    private static String getFIO(PersonDTO.Response.PersonData personData) {
        return Optional.ofNullable(personData)
                .map(PersonDTO.Response.PersonData::result)
                .map(PersonDTO.Response.PersonData.Result::person)
                .map(personInfo -> "%s %s %s".formatted(personInfo.lastName(), personInfo.firstName(), personInfo.middleName()))
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();

        Optional<String> backButtonAction = Optional.ofNullable(formData.getFirst("backButton"));

        if (backButtonAction.isPresent()) {
            context.resetFlow();
            return;
        }

        Optional<String> twoFactorType = Optional.ofNullable(formData.get(TWO_FACTOR_TYPE)).orElse(List.of()).stream().findFirst();

        if (twoFactorType.isPresent()) {
            context.getAuthenticationSession().setClientNote(TWO_FACTOR_TYPE, twoFactorType.get());
            context.getAuthenticationSession().setClientNote(CHANGED_TWO_FACTOR_TYPE, String.valueOf(true));
            context.getAuthenticationSession().setClientNote(USER_ID, context.getUser().getId());
            context.resetFlow();
        } else {
            formData.get(PHONE).stream().findFirst().ifPresent(phone -> {
                PhoneDTO selectedPhone = getPhones(context).stream().filter(phoneDTO -> phoneDTO.getValue().equals(phone)).findFirst()
                        .orElseThrow(() -> new RuntimeException("phone not selected"));
                context.getAuthenticationSession().setAuthNote(PHONE, selectedPhone.getTitle());
            });
            context.getAuthenticationSession().setAuthNote("prev_step", context.getExecution().getId());
            context.success();
        }
    }

    @SneakyThrows
    private List<PhoneDTO> getPhones(AuthenticationFlowContext context) {
        String jsonString = context.getAuthenticationSession().getAuthNote(PHONES);
        return OBJECT_MAPPER.readValue(jsonString, new TypeReference<>() {});
    }

    private void createErrorPage(AuthenticationFlowContext context) {
        createErrorPage(context, SYSTEM_ERROR);
    }

    private void createErrorPage(AuthenticationFlowContext context, String error) {
        context.resetFlow();
        context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                context.form().setError(error)
                        .createErrorPage(Response.Status.BAD_REQUEST));
        context.clearUser();
    }

    @Override
    public boolean requiresUser() {
        return false;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return false;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {

    }

    @Override
    public void close() {
    }
}