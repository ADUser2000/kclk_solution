package ru.mkb.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class PhoneNumberSelectorConstants {
    public String USER_DATA_SERVICE_URL = "userDataServiceUrl";
    public String USER_DATA_SERVICE_AUTHORIZATION = "userDataServiceAuthorization";
    public String USER_DATA_SERVICE_LOGIN = "userDataServiceLogin";
    public String USER_DATA_SERVICE_PASSWORD = "userDataServicePassword";
    public String ENABLED_AUTH_BY_CERTIFICATE_BUTTON = "enabledAuthByCertificateButton";
}
