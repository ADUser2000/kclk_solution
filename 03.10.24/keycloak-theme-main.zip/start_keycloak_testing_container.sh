#!/usr/bin/env bash
# If you want to test with Keycloak version prior to 23 use the retrocompat-keycloakify-starter-keycloak-theme-5.1.5.jar

docker rm keycloak-testing-container1 || true

cd "/Users/aleksey/IdeaProjects/mkb/keycloak-theme/build_keycloak"

docker run \
   -p 8080:8080 \
   -p 8787:8787 \
   --name keycloak-testing-container1 \
   -e KEYCLOAK_ADMIN=admin \
   -e KEYCLOAK_ADMIN_PASSWORD=admin \
   -e DEBUG=true \
   -e DEBUG_PORT=*:8787 \
   -v "$(pwd)/target/keycloakify-starter-keycloak-theme-5.1.5.jar":"/opt/keycloak/providers/keycloakify-starter-keycloak-theme-5.1.5.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-2fa-sms-spi/build/libs/keycloak-2fa-sms-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-2fa-sms-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-access-by-qr-code-spi/build/libs/keycloak-access-by-qr-code-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-access-by-qr-code-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-certificate-store-spi/build/libs/keycloak-certificate-store-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-certificate-store-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-change-password-spi/build/libs/keycloak-change-password-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-change-password-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-event-listener-spi/build/libs/keycloak-event-listener-spi-1.0-SNAPSHOT-all.jar":"/opt/keycloak/providers/keycloak-event-listener-spi-1.0-SNAPSHOT-all.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-login-form-spi/build/libs/keycloak-login-form-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-login-form-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-login-restored-spi/build/libs/keycloak-login-restored-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-login-restored-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-login-restored-spi/build/libs/keycloak-login-restored-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-login-restored-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-new-login-spi/build/libs/keycloak-new-login-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-new-login-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-new-password-spi/build/libs/keycloak-new-password-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-new-password-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-organization-selector-spi/build/libs/keycloak-organization-selector-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-organization-selector-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-phone-number-selector-spi/build/libs/keycloak-phone-number-selector-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-phone-number-selector-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-recovery-credentials-spi/build/libs/keycloak-recovery-credentials-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-recovery-credentials-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-recovery-type-conditional/build/libs/keycloak-recovery-type-conditional-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-recovery-type-conditional-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-reset-contact-data-spi/build/libs/keycloak-reset-contact-data-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-reset-contact-data-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-reset-login-spi/build/libs/keycloak-reset-login-spi-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-reset-login-spi-1.0-SNAPSHOT.jar" \
   -v "/Users/aleksey/IdeaProjects/mkb/keycloak-two-factor-conditional/build/libs/keycloak-two-factor-conditional-1.0-SNAPSHOT.jar":"/opt/keycloak/providers/keycloak-two-factor-conditional-1.0-SNAPSHOT.jar" \
   -v "$(pwd)/src/main/resources/theme/keycloakify-starter":"/opt/keycloak/themes/keycloakify-starter":rw \
   -it quay.io/keycloak/keycloak:21.0.2 \
   start-dev --features=declarative-user-profile
