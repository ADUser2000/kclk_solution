import "./KcApp.css";
import { lazy, Suspense } from "react";
import Fallback, { type PageProps } from "keycloakify/login";
import type { KcContext } from "./kcContext";
import { useI18n } from "./i18n";
import Template from "./Template";

const Login = lazy(() => import("./pages/Login"));
// If you can, favor register-user-profile.ftl over register.ftl, see: https://docs.keycloakify.dev/realtime-input-validation
const NewLogin = lazy(() => import("./pages/NewLogin"));
const RegisterUserProfile = lazy(() => import("./pages/RegisterUserProfile"));
const Terms = lazy(() => import("./pages/Terms"));
const PhoneNumberSelector = lazy(() => import("./pages/phone-number-selector"));
const TwoFaSms = lazy(() => import("./pages/2fa-sms"));
const AccessRecovery = lazy(() => import("./pages/Access-recovery"));
const NewPassword = lazy(() => import("./pages/NewPassword"));
const CertificateNotFound = lazy(() => import("./pages/certificate-store"));
const CertificateSelector = lazy(() => import("./pages/certificate-selector"));
const AccessRecoveryEmail = lazy(() => import("./pages/Access-recovery-email"));
const AccessByQRCode = lazy(() => import("./pages/Access-by-qr-code"));
const LoginRestored = lazy(() => import("./pages/Login-restored"));
const Letter = lazy(() => import("./pages/Letter"));
const Error = lazy(() => import("./pages/Error"));
const Info = lazy(() => import("./pages/Info"));

// This is like adding classes to theme.properties 
// https://github.com/keycloak/keycloak/blob/11.0.3/themes/src/main/resources/theme/keycloak/login/theme.properties
const classes: PageProps<any, any>["classes"] = {
    // NOTE: The classes are defined in ./KcApp.css
    "kcHtmlClass": "my-root-class",
    "kcHeaderWrapperClass": "my-color my-font"
};

export default function KcApp(props: { kcContext: KcContext; }) {

    const { kcContext } = props;

    const i18n = useI18n({ kcContext });

    if (i18n === null) {
        //NOTE: Text resources for the current language are still being downloaded, we can't display anything yet.
        //We could display a loading progress but it's usually a matter of milliseconds.
        return null;
    }

    /* 
    * Examples assuming i18n.currentLanguageTag === "en":
    * i18n.msg("access-denied") === <span>Access denied</span>
    * i18n.msg("foo") === <span>foo in English</span>
    */

    return (
        <Suspense>
            {(() => {
                switch (kcContext.pageId) {
                    case "login.ftl": return <Login {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "new-login.ftl": return <NewLogin {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "register-user-profile.ftl": return <RegisterUserProfile {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />
                    case "terms.ftl": return <Terms {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "phone-number-selector.ftl": return <PhoneNumberSelector {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "2fa-sms.ftl": return <TwoFaSms {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "access-recovery.ftl": return <AccessRecovery {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "new-password.ftl": return <NewPassword {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "certificate-store.ftl": return <CertificateNotFound {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "certificate-selector.ftl": return <CertificateSelector {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "access-recovery-email.ftl": return <AccessRecoveryEmail {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "access-by-qr-code.ftl": return <AccessByQRCode {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "error.ftl": return <Error {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "login-restored.ftl": return <LoginRestored {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    case "letter.ftl": return <Letter {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true} />;
                    // We choose to use the default Template for the Info page and to download the theme resources.
                    // This is just an example to show you what is possible. You likely don't want to keep this as is.
                    case "info.ftl": return <Info {...{ kcContext, i18n, Template, classes }} doUseDefaultCss={true}/>;
                    default: return <Fallback {...{ kcContext, i18n, classes }} Template={Template} doUseDefaultCss={true} />;
                }
            })()}
        </Suspense>
    );

}
