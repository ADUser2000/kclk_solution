import { createGetKcContext } from "keycloakify/login";

export interface ICertificate {
	id: string;
	name: string;
	agentName: string;
	certificateExpireDate: string;
	certificateNumber: string;
	thumbprint: string;
}

export interface PasswordRequirement {
	id: number;
    condition: (value: string) => boolean;
    message: string;
}

export type KcContextExtension =
	| { pageId: "login.ftl"; extraThemeProperties: { foo: string; }; }
	| { pageId: "phone-number-selector.ftl"; phones: string[]; authByCertificateButton: boolean }
	| { pageId: "2fa-sms.ftl"; mobileNumber: string; pageTitle: string; resendTime: number; attemptValidateCount: number }
	| { pageId: "access-recovery.ftl"; oldLogin: string }
	| { pageId: "new-password.ftl"; conditions: PasswordRequirement[]; pageTitle: string; oldLogin: string}
	| { pageId: "certificate-store.ftl"; isShowError: boolean}
	| { pageId: "certificate-selector.ftl"; certificates: ICertificate[]; digest: string; isNotAvailableCertificate: boolean }
	| { pageId: "access-recovery-email.ftl"; }
	| { pageId: "access-by-qr-code.ftl"; QRCode: string; statusUrl: string; sessionId: string }
	| { pageId: "error.ftl"; temporarilyBlockSecond: number }
	| { pageId: "new-login.ftl"; loginOptions: string[]; oldLogin: string}
	| { pageId: "login-restored.ftl"; }
	| { pageId: "letter.ftl"; }
	| { pageId: "info.ftl"; }

export const { getKcContext } = createGetKcContext<KcContextExtension>({
	mockData: [
		{
			pageId: "login.ftl",
			locale: {
				currentLanguageTag: "en",
			},
			// message: { type: "error", summary: "Account is disabled, contact your administrator." }
			// message: { type: "error", summary: "Неверный логин или пароль, попробуйте еще раз" },
		},
		{
			pageId: "new-login.ftl",
			// message: { type: "error", summary: "Такой логин уже занят" },
			oldLogin: "tesytr1",
			loginOptions: ["login1", "login12", "login13"]
		},
		{
			pageId: "login-restored.ftl",
		},
		{
			pageId: "phone-number-selector.ftl",
			phones: ["79991112666", "79991112777", "79991112888", "79991112999", "79991112999", "79991112999", "79991112999", "79991112999", "79991112999", "79991112999"],
			authByCertificateButton: false
		},
		{
			pageId: "2fa-sms.ftl",
			mobileNumber: "+79991112666",
			pageTitle: "Подтвердите вход",
			resendTime: 6,
			attemptValidateCount: 1,
			message: { type: "error", summary: "smsAuthCodeInvalid" }
		},
		{
			pageId: "certificate-store.ftl",
			isShowError: false
		},
		{
			pageId: "new-password.ftl",
			conditions: [
				{
					id: 1,
					condition: (password: string) => password?.length >= 8,
					message: 'От 8 символов',
				},
				{
					id: 2,
					condition: (password: string) => /\d/.test(password),
					message: 'Цифры',
				},
				{
					id: 3,
					condition: (password: string) => /[a-z]/.test(password),
					message: 'Строчные латинские буквы',
				},
				{
					id: 4,
					condition: (password: string) => /[A-Z]/.test(password),
					message: 'Заглавные латинские буквы',
				},
				{
					id: 5,
					condition: (password: string) => {
						const specialChars = '!«»#$%&()*+,-./:;<=>?@[\]^_`{|}~';
						return password?.split('').some((char) => specialChars.includes(char));
					},
					message: 'Спецсимволы !«»#$%&()*+,-./:;<=>?@[\]^_`{|}~',
				},
				{
					id: 6,
					condition: (password: string) => password,
					message: 'Не совпадает с логином',
				},
			],
			pageTitle: 'Регистрация<br/> в «Ваш банк онлайн»',
			oldLogin: 'login1',
		},
		{
			pageId: "access-recovery.ftl",
			oldLogin: "recoveryLogin",
			message: { type: "error" }
		},
		{
			pageId: "access-recovery-email.ftl",
			// message: { type: "error" }
		},
		{
			pageId: "error.ftl",
			temporarilyBlockSecond: 834
		},
		{
			pageId: "certificate-selector.ftl",
			certificates: [
				{
					id: "A-11111",
					name: "ООО «КОМПАНИЯ»",
					agentName: "Иванов Иван Иванович",
					certificateExpireDate: "2025-02-09T11:24:46.4714221+03:00",
					certificateNumber: "7C000095E3A5BB0D581CEF831E0000000095E0",
					thumbprint: "7C000095E3A5BB0D581CEF831E0000000095E0",
				},
				{
					id: "A-222223",
					name: "ООО «Рога и копыта»",
					agentName: "Иванов Иван Иванович",
					certificateExpireDate: "2024-03-28T11:24:46.4714221+03:00",
					certificateNumber: "7C000095E3A5BB0D581CEF831E0000000095E0",
					thumbprint: "7C000095E3A5BB0D581CEF831E0000000095E0",
				},
				{
					id: "A-222224",
					name: "ООО «Зеленоглазое такси»",
					agentName: "Иванов Иван Иванович",
					certificateExpireDate: "2024-02-09T11:24:46.4714221+03:00",
					certificateNumber: "7C000095E3A5BB0D581CEF831E0000000095E0",
					thumbprint: "7C000095E3A5BB0D581CEF831E0000000095E0",
				},
				{
					id: "A-222225",
					name: "ООО «Хомячки»",
					agentName: "Иванов Иван Иванович",
					certificateExpireDate: "2024-02-09T11:24:46.4714221+03:00",
					certificateNumber: "7C000095E3A5BB0D581CEF831E0000000095E0",
					thumbprint: "7C000095E3A5BB0D581CEF831E0000000095E0",
				},
				{
					id: "A-222226",
					name: "ООО «Восьмиклассница»",
					agentName: "Иванов Иван Иванович",
					certificateExpireDate: "2024-02-09T11:24:46.4714221+03:00",
					certificateNumber: "7C000095E3A5BB0D581CEF831E0000000095E0",
					thumbprint: "7C000095E3A5BB0D581CEF831E0000000095E0",
				},
				{
					id: "A-222227",
					name: "ООО «Моя оборона»",
					agentName: "Иванов Иван Иванович",
					certificateExpireDate: "2024-02-09T11:24:46.4714221+03:00",
					certificateNumber: "7C000095E3A5BB0D581CEF831E0000000095E0",
					thumbprint: "7C000095E3A5BB0D581CEF831E0000000095E0",
				},
			],
			digest: "0ead0dde-4988-4776-96e9-58bb9866a5e8",
			isNotAvailableCertificate: false
		},
		{
			pageId: "new-login.ftl",
			message: { type: "error", summary: "" }
		},
		{
			pageId: "access-by-qr-code.ftl",
			statusUrl: "https://z7v7q.wiremockapi.cloud/status",
			sessionId: "f73cf8b5-1548-48d2-bdab-002d82f6b1f1",
			QRCode: "data:image/gif;base64,R0lGODlhLAEsAfYAAAdYlAdalgZbmQdbmQddnAdengdenwdfnwdgoQdipQdjpgdkqAdlqgdlqwdnrAhipQhjpQhkpwhjqAhkqAhlqghlqwhmqwhnrAhnrghorQlorAlprAhorwdpsgdqsghosAhpsAhpsQhqsQhrsQlrsQhqsghqswhrsghrswlrsgprsQtrsQprswhssgpssgtsswxssxJwtRNwtRVythdztxt2uBx3uB13uCB5uiJ6uil+vDGAuzmFvTqGvTqIwjuJwjyKwkiQxUiRxUmQxUuTxk6Tx1CTxVudy2KgzmKhz3Cp04KnwoOtzIm425Kyype50pq81aTG3KXG3a3F17nN3LfU57zS47zS5MrS2cvT2dXa3tfc38ja6Mvd6dfe4t3h5N3k6t7l6+Lm6Ovt7+fs8Ovu8erv9PT09ff39/T3+fv7+/v7/Pz8/P39/f7+/v///wdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlAdYlCwAAAAALAEsAUYI/wDfCBxIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqoxYomUJiy5fUoxJk2BMmzRzyjx4E2HPhT/f6BzaEqdLlkcH1lRKVKfPoUZ3TgxKkmrTolGzajVIFOnVoEsFQo0KdixXqkydppUqNOnDr2HbYl1rVqzbklavFiyrl2HdvXADzwUsGG7Frjzrok2s9uxguYjXoiwceKvdwXkx34VM1nJcvppDi+4sma5lzqVTo1ZN2fDJzK2fNob8eTbhpqcVt+57eTTE2rxvxyVbeKXCyML/Es+ZcLFj5oxxq5a4+7HfzcvZgr59+OvkzdXDS//vTfq51L/Ok0OPnp5y8+C0bZ+e33v4SNjZkdsn71l5fef6+ReffPXJph120eXX3mzA7Wfcfwg+l1GAj7n21l3I0QchW/1F6CCFDq52XHGvgUfihesNOB5/G2ZooHocTjcTaC4ChaFuFd6Yo3UipeeRdwZaSNuLRCbI3nUMhofkih+ayKOEK7n3m4Ah0oXeidwVOeKTIpanopAigthdhN8RuGWIC64YJo1ONngekC3CeWaWNqboJo4xPghjlextp6WQUqJYWZBtKqkglz5aCZ+WVbWZH6EeyokfUwRU90MWKjaHQAjiBUZABXbi+V6KDcHGJpnGCbgnnm8iqmMJBOz/sNsPBdxYgAi7YRAAn3Ga2aVpU3KZnZ5GsoaqjMU61GRTBwjR6Vc1VAFCCRyQ8GxMMVyhxrDctgipsIqqWeK1i/b5qpeJQogArq2lsMEHJUywArkt6UDFtOBOReaVnT46Lr25HXtmgzD6W4YRMWkQgggTVDcDFEFqOOqTk5rHqJy/9kivb8h+WeqrrYZ8J8iFgtztRaZiCSjG9+1L8suigVjjl6oeGmpwy+bpcbAjx8xqzT+W7LOv6dKc75Dh5jyxzSJfzDKLUPZKKqOpOrrkqRxvOLHMQCMNNcFJj3k00+muLDBIKQ9NMdZgFzidn3Xe3HTcvK4Js5g20znnvwWH/520qhh33SXbcA8suL9an9zz1labxLWZj8st3rcin73035b7/XXhPbftNbHJ5uy55x8nWa7hR1dstGCIZww142rr/JHZsmvuut27MS0x5WxT3rpXOhdNNegdBYr61FLXnvzVTrO+5ISCH8632K0LH5LxvM6s9Mm3U/98xymlPVzvPEds++6YSy69eWm6yXy4l3s7/YxrnwusoNa7nbi5yu8c9f6vg56aWEW8AhrwgAhMoAIXyMAGOvCBEIygBCdIwQpa8IIYzKAGN8hBfW0MeGA63/eM5aoS9g+EG+sc2bDUqLENT1miSl/wXJa6uxGwfPdbnegKR53MCfBAA7Qf//9WdToiys2I28Nf+/iVIR4GzocYyd//sCcpAJXtigLbIRSDJq5k9dCFDjQURyJXOV/l8HdXgyLtTjhB1ZHxaf/TW9/0B0P1nS2FM5Mjz7QIxjFSiXBC1GH8Pge4KjpveeCTovasaLq6tXCGfUSXycAHPN19C41ezGEIPag2PcrPgDTyHQnztckAps+TX4ykCFEGSCZJcSPiy+MlZehGFjYPTVs8kgwrabta7oiNP4QdEDt3LZjYUI2Nu50ieci9DtlxmGVC3vEGKUmcxXCImrTNE7OmTFuyD5kmrBrM9NY+TH6zf4v8ZTl1aUpEbg5yYtyTOKVpSboZEmC99GbyWln/t1LKUlCoRFsyhRnL6lCzBLfazQ4wlccvDAGPNIkBEzLpxaIxs6K5FBsfY4PDdkKmVgrFAv9aQgAMQJQmCQCVRa/5zmFSsYizu2MyfTkoOpYnCz/YjQ8qVandnGBXbyDDEWBALxxMQQ2FNCETA8bNVxrzpCttZDXR2RIEmJReCiuBBay1MQdwEZLje5Y5w9dIYKZyrM1kyrquEi02vMEMQHjBbqBwgZmyNFPZDGcUnaoSvNExlKOEau7edjfeaTNS8DRj6Pjqx7IyEqxeKh1HbUrLw8YunpOjpGYBGqWfZfGP43RmGbsYx2Cm8ZCCzKsr6QnB7EWPaBn13+DACdnT/5qVdNdjLCuV6tlnzvGco7vo3jrm2sLS77a9beBj87ROJcpUcmmNo3CRKL6paiSpZt3tMzdaTx36M7nec2cdj6jaqfr1cwx8KSmnaz4A4g6VuF1sWVfY1EB6V7GOM2gi4UhQ0EqzlOS8K/ri1l7q4hcv+nTded8b3a0ZFrVRra09rfnBXf6LXKK0mIXFS9PgUpi1G77vYF+3zew+1aWWDdlv17g+9Fb2w80dLzEF+1wTh1dqAYYpgbmH3WWO+JwBFW2LzTvQllXYo7qVWG9x2UcmLjG2IlbejEHcwSpb+cpYzrKWt8zlLnv5y2AOs5jHTOYym/nMaE6zmtd8ZTyi8P90/5SufZUM5QdjOJ9HRrAqN0tQIcNWrzve5yQ5+1d9LpiX+VVnipnK3Bard7Qr9m+jpTpgA9c3iHs+rhFzDNaC6ljQl65pkEfaX0WTyonwSTKicexnKuN1pPGkr6jfXD/yTrjWm640LKHMT35G9ozsdDDdMjzP12a6e1+9M4nti+qYifbZgYV2S1XsTE5zWtkajPUPVRjiAqMVm86FbpuFNms8+9bOjO61ytgb7O8mdrJ66rC6XR3jSNOWfLd28whTyd35TXve/aRhpwctY+PmO4WS1ehyVX3cjT6ZnhF2+Jz3mOAXvrqloz6eI5O93O76+k9YK/VlHUtpimrc2+b/ZvheTU3j84qOxzXuscABXGLsUnOVuQU0v6WNbEKnFtyyvXmhPy1ZSGsozo2F5ovnJufYEbt6kpb0LRPebcWFvLUEh7qzDy5wkWe86Aqvs4ZB7T5iIZ3hCwYwyN8tzEG+nNTws7iso2lp5G53qUunetxNDsLu6l22NP36rnnLclkb76xVDzTG5d7umXc95UXW2LFp/fDV4triHc+34bFo+UkrXfGP3Lh7j/7xT3ZT3O4tMaNFXlxX03nyYSdtn4ON7rnzPcJCJ6R+A8vugYFucdVeO70PnE4U69y6tf83Yn/8bT27fu+lPSXPnUxwFqP2oDGv/j0RGGe1533p1h85/8TXff3ky3Pln3d+689Ofnya/vC2J3vRoy722cK+4Y4WMO9JXoIBnGBWmAJqCBAELfcp1Dd+NVR+fBdTvzR/p5ZnepMFV0UZP6AFq+QFPdByTHAGjLdsCUhtoKdy43VtC7d8aXcXCdUaCwV9BLEFHUBjEkVGryd69sdtifZfxdRRp+cSPdUaPhCA4dKDgmUAdTV8Jbd44HdM95d0EXdPIDhFN6EFQJArlUIQJVUdAuASDrCFDtAFXviFYPiFXDiGZOgA9QZsoDdLoFRj1tZqMuNtWSArLecSANASFkAEG4MDVsCCM4h3HviEPZd0bZiGC0h7u+QFzoJHNhAFa/AGFv/gAnl4VEBmde8WcAqoflDlgFkTX+axVp2iAtNSLRsjAg4wLV/Vdpu3XcRzQwLldLaVEFYlGDUgBW3gBmEwhbvRAA1obvbGTbo2bJ2VZ6pDeel2N2WABERFE+4CL2BQBHJFGTPgBGggHL9IWX+Icn/ohwnkcpzTjXMYEwvQAaDoEihgAuZojk2Qjk1wjiagjuloAgxQV+Z0eCVYazQIWH2FcIRlj7hXXpAXWtAHfOhXd6X3c2TFf57ndj4GbxKHaaOVWWTHiYK3b4+kkAjpcXAEf7CGkPgYUEhHiXenhDaGfjY4e2N3cbjzkMY2krlHkCJJZPy3iuTmd5XGXzCJgzr/t0a3VHwWWW6FeIO9mEdNaITil5DC94YYBWePJ38USUHrN5QSxm/NZndRiYr4U40nxpIn9nVLVoyEF5LrFUge9nwnqYnd54TzxHoY+YAIaHnI53MKxnkPeWNm2WB0B5Jvx2Hat4sepXVMZ5LDpXsQRm7D2IHOh407SIyvqFr9OEpmeYB/qXI2528X90Z/1kTEZ1cf9pj3dnUB6ZmTyGeDB5aeN2UqaWjgpWmJd3LR1pp6uXVh1H5S1nvUyIJTWWCNCXgAt3r7CG8yCZvnN21YaZlNlpl8GWUyuF8fiG/xtns7+JHfB1zm15MSqVuZB1w2eWH6J53KeZowtp1qiXPJ/8lJLdmUweiT7XSCobaQpYlZbGiYj5aD4pVBGomdJriSZ7l8dfd3sUdVZImJYgV3Jxl+pMOcBcl+3ymMhBl5OceSBlp/WYmWmmeI2cigW7lvInihqvl+ENqfrAiYv1ahx3ld79mXlKl6vXmg2VmWSRiThumX32iJWrlqq0OCtIWb/sWZpNmfVuliA3qZzSeIeeOGjFVdDZZ/zAdzH0iTV2mbHcqfNOqP1jhNe3SkxomTxpd+JOqQHRlN2HaGGxqaBjmRqXeZ1llxQ4eebLambNqmbvqmcBqncjqndFqndnqneJqnerqnfNqnfvqngBqogjqohFqohnqoiJqoirqojP/aqI76qHGqb+FWfPeomVWJlTr6pUumbZLnfgWnlAfGm0i2lKMpWDAqn4dJlxQnlvwFplA4mDfKmBkJnlDaqRoqlaxaRK5qo523aqZZj4AYpbY6pI5JeqEanYIZVqpIobo5oralnpi5hCNIrEiYnkgqagIJQJRKbIXJdbbGaqK5pVkaeGoYkdm3mfFHpkFHrTUafNIXrqb1rtX6W8h5rm6ZrsMpc2wZrYCIokDJrgXZoy4Jqp6qmNxpoqbnlco6ozrYrvtHlJUHkQMre8/KrfZqlPIaiKN5q/E5X8waorXpewJabFd6qxV5Yx2LeiErbCLbssFJskRpskbmoCKpoib/+D4ui5jQ2YoISrPSmqnqNYjz2pFEu5eRabRvObTMVrNoWjz6eI29KarJmrRj+YRVK7Xk+rASS5/OKa4l6X0+uq63RnldOqecql1fu6L9Fm5km3Uc5GmkNZ4ouZZZmoq9Cq/JSqnAuqKp2qLtaXBzG2JGaq4wlq8vObJ2+5vpR5w925IfqolB+o21+qn8+KQU+aBJenuOB5yQi3MTW5/qOo9D5rV7u7lM5p9YemirqqaYt2hRi3/H6rSVqK+nW5cb6YurC7Ye6bpQy0k7y4TXaZABO31muqkcOXEI+7IgGzncJ3WCe7jy1Unml7LV2Zk3O7Kje4p2K6kpiaP7qqMC/4uvAKurpBqkG7u9T9u9jfe9z2q6rBexC3p8xvqf2lWewCiceEudtBu51zufDaekf/uz5pm83nu0Szi8n1my60uxTVqmlSvAhEjAC5y0HNuqFznAprltAPx0M8urSNl0c4m4//jAeSlHuUlzHjt65+nBj/u6CSueXXm7pTl1GGrBKpu9+ci5vIiGSOS4qVZ/NGi+DVyvOryGRdysfzmdfci7WcmjTJi4POyluenEIvqfzLnEORm8pyq/MpyhuTu5BluDv3vF3RljJbzFl9rFlhuCTRuU/hpl/DmZaMukgQmtUnuyyNq5TKm1K0mvmLrAYwy4WSvB8SqmlZmJKMu3WP9bvjj7nKTKvH+sqk5Kmmc7rf7LxrhLyFNbrh68wZTZqbT7wbvLxWGLxqz7mpfHZ14cwQwolLLZuqT8lEyLXzqZlKgrxdabxnkbw6N6wymmjd26xyA6wBpLurmcexm8w0CXrQ6rtF+Zn1bMyKDMntK8yxfcy2XnwPx6x+J7sJYcfQDKwN4Msn5Xn7s6gwVMj4IcW0HMcUQnup/1w5d4zt2ZziyEuSPZzrIrvcUavTIKlRirwtaKvMILuNvLwTnMz/PqhnrMmiDsqtWLri9MuCT8e9e6q2/MzB9KoHwbzEFJt+l10dXczOqrzUWboKfcu1SapqrbnLTc0bKJqowLv8f/C7H0d38e3cqybNMoLbEzbbo/vZw3zbA5Pc2xi8T6W9OVeokoiaokXZNtvMqUu9TfysJ3IwAjoFABSBlikAQ58NVgnQNDEdZiLRgN88tA2r4K/K+qLM/YZsKwMoGFUYGyhIEayIFQ7azRG8drHJiBWHMB6kVCONdbLSBeQICCJQNLgNdcaaHu6tdSjX2uOM7Pe5wukYKUsVCFtCktlwDLis0L6cZ9LdkhTNmoTE5X2BoVKNBvgAAZ0NkqlbZfSaO8HM4B7Js1bELs0hpPYFiDfVIGeLGLzHIcPdoITcTRnMm0kdoUaIF7gtlQpQBXWqBL+2O6W6qly9TCBzsgpYIi/6UozF0YM1DWLRHWOhEBRcjToaawxQ3BaHuxG/3IMYFT1dFTNvHbgfFT6u3K9iishox1+x3fWZwUcVgdBTAQWrDbhaErdtgCKUQBEB3ai2nEt/zYKSmhJymFuQIBcl0YWVgCaUAEyXgt2bItcmyfi2upoSuztjzc2KrFb0DfLWcD76JVLjDiz2JU28LaNJ3ilu3Y2tvPfv2iPAwXXsADUDWLbaBVXEUuemjItc2/2j2sQm6/mtyQMvEFiUgvbfUGadDk13IDXLDj9BrlntvNtp2+gHnSqOuJnbKMNp5CDwACQQ7lgS22DWqqFeuaf00TsRgeWbVV9JICOmCGEFx5n/9r0DCbxPss5Q7yBQoOF10OV89YGB5gjkqQ6ZlujqXolx9dzyTZvCpb5z3bHm7eFIvYiM1Y6YJBAwjAAT9+hIdM0GgX2Wpt3UDu0GIMMwxgBKxOEwpji7gIjRBDwY3MzVMKtyvuoc5Z1Lo+uB4zBkjAAjQxjhgQV3M1jSvLnjTMolXs7A/Cjbm6iTHaEgzwgnAuAZyyG0QIz7MGrMdNnQD+rVfLx+Ve1WQszHE5u7E6paEn0wzauFKKxBqdwoFLnlCMyr/73ncezAKfpqYMwGwumfHbecbr3u/bfvDVxwMvt5B5k+I6sXS78MY82aPM6N4qygmvfP3it8H6k9+Myyb/j85RbGctTNFWjevNXqL1+8laa8oIDMe3nszJDtS0BvTQ27ev+tkFTbC6S71lC9rUbPLtzbC+m+/KK6uxXpRTXMgZv6Naf24UXpLHXfDACbqRPORqDPYsnZouXber2efibM1YmtSjnqI5epQwjfG0rdRW/tSAnPf+fPO7znZ6T3S2rn57PrZE7s3gTvOMP8SJT84LtNOoS8/Pnusn39Bgl7//u8J5LdtwL8N0TLXeSL81v/azWbig39ZMD+09HPcdf/r6XMo2H893m9DhqfAzOb1I27Aw/qNHbbhi//a73/QL2+NWS5vIbvttz865bHRmB9Q2m/zUP+4vD9n9y7J4/w7GFov6dT7rqQvSA89gE4q/ui7vyKrsoX+XCTz+lW3APn75tL/4dbybeM++rOz+Kwv5U93QAFFCoMA3Bd8MRFjC4EKGBwcyRLgwYsOGCS1ahHhR4sSCHCl+/HhRYciHIE2eRFmxpMqVGQmSfJmyo8iUNA0m3IgRpUeHMXuOPClSqEucNz3ylEnRptKWSZ0SJXp06U+hSI1WjdoUJtCZPqu2tMoSq9OhV4ualQpW41aeYZ8mbbu2q865X31mpVtXK9O7acfOrWn3aVm9feVSzXlWbNy7bwdPtcs1seLIkyNPtaw271u/hGV67px4cua8oR2fJs21Mt/SgtFePpyaNP/qn6ndsvU72qzuwq293qYdfLHrujtzk+3c9Phu1qr3ipWN1vZhxs4NwwYunDZ2640Xi0auWXFt5uWjgg8qnnLyr+gBm6eKXfv898WbL0cM3zh14p9jb4XqNe7Uwy/A9HzbjD7UTBtOPN7Igwuy/gJLkDUD4xvwN/68q88kCf9TMMIM3cOrQg/lu++51Q7sbj0OIXQsrPEEvCzEEDPUULLpXsStvRQ5XPHEHF3UUb/wisyvwRpt5Ky/7DDMEST2YNuxu8d87A1J0DA7UsrnKESSSSH/gtHLDcOccsksC9yPTM+iy3LBL58EUMwjt+SRRivrXNNJP/NUksgZ49RTzhf/6bTQThHVhO7HPc2rDlH7AuWORD4bZTFIHN2cUFEo37SU0A5hjPRLtnoc0UhMVzWT0U3xJNNTTyttE9Q+Af00u0HLpJVF7WxVUlZh/aOyVi5vDbPKWi/NFURWTwO2xGEXfVXGY5NsdsgPJUvTPU2vLVHQahEMVzlTbRzXRGDFPRPWC93Vs1tj2023wAklFQ7fd7edFlVYkxX1vERpvHC+J9nsV1ViW0S4316x9ffUgXsr+NdzO9SXyVI3s5dej01sVct0Z2N2Xm3rLdbXaTcer2ME/wVXYkpRpLjkTNNEGcsxHTY3VnkXlflTm2d+Oeab52x3WYIvjVbjnt/8eeGg4de9OFt2QTYZzaQzJXniptF9GjOcq2ZWbGehvHLAkJ8GU1lop6xYUZarczvGsO8+9Gx/O11aYW/5Xpjh6wC+keyhiXwQTHyvXhtXqgenu3Cft064zLSnVi/txeFGVXFrIWdbcqgpTzhjVRGX7k7DJ0W786zLjs30Mc1+uXJkH3ZL9rhrRrZVzfHWGuusjcb2YVlzjnLoJvMu+uzNOXZe7+GlL55m26/HPnvtt+e+e++/Bz988ccnv3zzz0c/ffXXZ79999+HP37556e/fvvvxz9//ffnv3///wdgAAU4wIUEBAA7"
		},
		{
			//NOTE: You will either use register.ftl (legacy) or register-user-profile.ftl, not both
			pageId: "register-user-profile.ftl",
			locale: {
				currentLanguageTag: "fr"
			},
			profile: {
				attributes: [
					{
						validators: {
							pattern: {
								pattern: "^[a-zA-Z0-9]+$",
								"ignore.empty.value": true,
								// eslint-disable-next-line no-template-curly-in-string
								"error-message": "${alphanumericalCharsOnly}",
							},
						},
						//NOTE: To override the default mock value
						value: undefined,
						name: "username"
					},
					{
						validators: {
							options: {
								options: ["male", "female", "non-binary", "transgender", "intersex", "non_communicated"]
							}
						},
						// eslint-disable-next-line no-template-curly-in-string
						displayName: "${gender}",
						annotations: {},
						required: true,
						groupAnnotations: {},
						readOnly: false,
						name: "gender"
					}
				]
			}
		}
	]
});

export const { kcContext } = getKcContext({
	// Uncomment to test the login page for development.
	// mockPageId: "login.ftl",
	// mockPageId: "phone-number-selector.ftl",
	// mockPageId: "2fa-sms.ftl",
	// mockPageId: "access-recovery.ftl",
	// mockPageId: "new-password.ftl",
	// mockPageId: "certificate-store.ftl",
	// mockPageId: "certificate-selector.ftl",
	// mockPageId: "access-recovery-email.ftl",
	// mockPageId: "access-by-qr-code.ftl",
	// mockPageId: "error.ftl",
	// mockPageId: "new-login.ftl",
	// mockPageId: "login-restored.ftl",
	// mockPageId: "letter.ftl",
	mockPageId: "info.ftl",
});


export type KcContext = NonNullable<ReturnType<typeof getKcContext>["kcContext"]>;