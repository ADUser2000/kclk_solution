import React, { useEffect, useState } from "react";
import { clsx } from "keycloakify/tools/clsx";
import type { PageProps } from "keycloakify/login/pages/PageProps";
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import { useForm, Controller } from 'react-hook-form';
import { IMaskInput } from 'react-imask';
import backArrow from "../assets/back_arrow.svg";
import ClearInput from "../assets/clear.svg";

interface IAccessRecoveryEmailForm {
    email: string;
    phone: string;
}

const phoneMasks = [
    { mask: "+{86} 000 0000 0000", startsWith: "+86", country: "CN" }, // China
    { mask: "+{7} (000) 000-00-00", startsWith: "+7", country: "RU" }, // Russia
    { mask: "+{374} 00 000000", startsWith: "+374", country: "AM" }, // Armenia
    { mask: "+{375} (00) 000-00-00", startsWith: "+375", country: "BY" }, // Belarus
    { mask: "+{995} (000) 000-000", startsWith: "+995", country: "GE" }, // Georgia
    { mask: "+{77} 000 000 0000", startsWith: "+77", country: "KZ" }, // Kazakhstan
    { mask: "+{996} (000) 000-000", startsWith: "+996", country: "KG" }, // Kyrgyzstan
    { mask: "+{992} 000 00 0000", startsWith: "+992", country: "TJ" }, // Tajikistan
    { mask: "+{993} 00 000000", startsWith: "+993", country: "TM" }, // Turkmenistan
    { mask: "+{380} (00) 000-00-00", startsWith: "+380", country: "UA" }, // Ukraine
    { mask: "+{998} 00 000 0000", startsWith: "+998", country: "UZ" }, // Uzbekistan
    { mask: "+{0} (000) 000-00-00", startsWith: "+0", country: "DEFAULT" },
];

const isValidEmail = (email: string): boolean => {
    // Regex to disallow non-ASCII characters and restrict special characters
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(email);
};

const isValidPhone = (phone: string): boolean => {
    const phonePattern1 = /^\+\d{1,3} \(\d{3}\) \d{3}-\d{2}-\d{2}$/;
    const phonePattern2 = /^\+\d{11}$/; // New pattern for +79991112666
    return phonePattern1.test(phone) || phonePattern2.test(phone);
};

const formatPhoneNumber = (phoneNumber: string): string => {
    // Use a regular expression to match only the + symbol and digits
    return phoneNumber.replace(/[^\d+]/g, '');
};

const determineMask = (value: string) => {
    const mask = phoneMasks.find(m => formatPhoneNumber(value).startsWith(m.startsWith)) || phoneMasks.find(m => m.country === "DEFAULT");
    return mask ? mask.mask : "+{0} (000) 000-00-00";
};

const replaceLeading8With7 = (value: string): string => {
    if (value.length < 3) {
        return value;
    }
    const formattedValue = formatPhoneNumber(value);
    if (formattedValue.startsWith('+8') && !formattedValue.startsWith('+86')) {
        return '+7' + formattedValue.slice(2);
    }
    return formattedValue;
};

export default function AccessRecoveryEmail(props: PageProps<Extract<KcContext, { pageId: "access-recovery-email.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;

    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    const [isErrorMessage, setIsErrorMessage] = useState(false);
    const [isFormValid, setIsFormValid] = useState(false);

    const {
        control,
        watch,
        setValue,
        trigger
    } = useForm<IAccessRecoveryEmailForm>({
        mode: "onChange",
        defaultValues: { email: "", phone: "" }
    });

    const { message, url } = kcContext;

    const email: string = watch('email');
    const phone: string = watch('phone');

    useEffect(() => {
        if (message !== undefined) {
            setIsErrorMessage(true);
        }
    }, [message]);

    useEffect(() => {
        setIsFormValid(isValidEmail(email) && isValidPhone(phone));
    }, [email, phone]);

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    const handlePhoneFocus = (event: React.FocusEvent<HTMLInputElement>) => {
        const value = event.target.value;
        if (!value.startsWith('+')) {
            setValue('phone', '+' + value);
        }
    };

    const handlePhoneAccept = (value: string) => {
        const formattedValue = replaceLeading8With7(value);
        setValue('phone', formattedValue);
    };

    const handlePhoneBlur = (event: React.FocusEvent<HTMLInputElement>) => {
        if (event.target.value === '+') {
            setValue('phone', '');
        }
    };

    const handleEmailInput = (event: React.FormEvent<HTMLInputElement>) => {
        const value = event.currentTarget.value;
        console.log("sadsa")
        // Regex to allow only valid email characters
        const sanitizedValue = value.replace(/[^a-zA-Z0-9._%+-@]/g, '');
        setValue('email', sanitizedValue);
    };

    return (
        <Template
            {...{ kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow} />
                        <span>Назад</span>
                    </button>
                    Восстановление доступа
                </>
            }
            infoNode={<span>footer</span>}
        >
            <div id="kc-form">
                <div id="kc-form-wrapper">
                    <form id="kc-form-login" action={url.loginAction} method="post">
                        <div className={clsx(getClassName("kcFormGroupClass"))}>
                            <div className={getClassName("kcLabelWrapperClass")}>
                                <label htmlFor="email" className={clsx(getClassName("kcLabelClass"), isErrorMessage && "labelErrorClass")}>
                                    Email
                                </label>
                            </div>
                            <div className={getClassName("kcInputWrapperClass")}>
                                <Controller
                                    control={control}
                                    name="email"
                                    render={({ field }) => (
                                        <input
                                            {...field}
                                            type="email"
                                            id="email"
                                            className={clsx(getClassName("kcInputClass"), isErrorMessage && "inputErrorClass")}
                                            placeholder="Введите email"
                                            required
                                            tabIndex={1}
                                            onInput={handleEmailInput}
                                            onClickCapture={() => {
                                                setIsErrorMessage(false);
                                            }}
                                        />
                                    )}
                                />
                                {email !== '' && (
                                    <img src={ClearInput} className="clear" alt="Очистить поле" onClick={() => setValue('email', '')} />
                                )}
                            </div>
                        </div>
                        <div className={clsx(getClassName("kcFormGroupClass"))}>
                            <div className={getClassName("kcLabelWrapperClass")}>
                                <label htmlFor="phone" className={clsx(getClassName("kcLabelClass"), isErrorMessage && "labelErrorClass")}>
                                    Телефон
                                </label>
                            </div>
                            <div className={getClassName("kcInputWrapperClass")}>
                                <Controller
                                    control={control}
                                    name="phone"
                                    render={({ field }) => (
                                        <IMaskInput
                                            {...field}
                                            type="tel"
                                            id="phone"
                                            className={clsx(getClassName("kcInputClass"), isErrorMessage && "inputErrorClass")}
                                            mask={determineMask(field.value)}
                                            placeholder="+7"
                                            tabIndex={2}
                                            inputRef={field.ref}
                                            definitions={{
                                                '#': /[1-9]/,
                                            }}
                                            onFocus={handlePhoneFocus}
                                            onAccept={handlePhoneAccept}
                                            onBlur={handlePhoneBlur}
                                        />
                                    )}
                                />
                                {phone !== '' && phone !== '+7' && (
                                    <img src={ClearInput} className="clear" alt="Очистить поле" onClick={() => setValue('phone', '+7')} />
                                )}
                                {isErrorMessage && (
                                    <div className={clsx("alert", `alert-error`)}>
                                        <span
                                            className="kc-feedback-text"
                                            dangerouslySetInnerHTML={{
                                                "__html": "Указанные данные не найдены или введены некорректно. Убедитесь в правильности введенных данных или обратитесь в отделение банка"
                                            }}
                                        />
                                    </div>
                                )}
                            </div>
                        </div>
                        <div id="kc-form-buttons" className={clsx(getClassName("kcFormGroupClass"), "buttons", "left-buttons")}>
                            <input
                                tabIndex={3}
                                className={clsx(
                                    getClassName("kcButtonClass"),
                                    getClassName("kcButtonPrimaryClass"),
                                    getClassName("kcButtonBlockClass"),
                                    getClassName("kcButtonLargeClass"),
                                    !isFormValid && "disabled"
                                )}
                                name="login"
                                id="kc-login"
                                type="submit"
                                value="Продолжить"
                                disabled={!isFormValid}
                            />
                        </div>
                    </form>
                </div>
            </div>
        </Template>
    );
}
