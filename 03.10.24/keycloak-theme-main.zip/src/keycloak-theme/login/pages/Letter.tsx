import React from "react";
import { clsx } from "keycloakify/tools/clsx";
import type { PageProps } from "keycloakify/login/pages/PageProps";
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import LetterContent from "./components/LetterContent/LetterContent";
import logo from "../assets/logo.png";
import QRTg from "../assets/qr-tg.svg";
import TGLogo from "../assets/Tg-logo.png";

const PasswordRecoverLetterContent = {
    title: 'Восстановление пароля',
    text: 'Здравствуйте! Вы запросили новый пароль в личный кабинет. Перейдите по ссылке в кнопке и установите новый пароль. Ссылка действует 24 часа. Если вы не отправляли запрос, то просто проигнорируйте это письмо.',
    tableData: [
        {
            title: 'Клиент',
            data: 'Request.Name'
        },
        {
            title: 'ИНН',
            data: 'Request.Inn'
        },
        {
            title: 'Логин',
            data: 'логин'
        }
    ],
    buttonText: 'Установить пароль'
}

export default function Letter(props: PageProps<Extract<KcContext, { pageId: "letter.ftl" }>, I18n>) {
    const { kcContext, doUseDefaultCss, classes } = props;

    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    return (
        <div className="letter">
            <div className="wrapper">
                <img src={logo} alt="логотип" />
                <div className="content-wrapper"><LetterContent letterContentData={PasswordRecoverLetterContent}/></div>
                <div className="social-wrapper">
                    <h2 className="social-title">Присоединяйтесь к нашему каналу в Телеграм</h2>
                    <img src={QRTg} alt="QR-код" />
                    <img src={TGLogo} alt="Логотип Телеграмма" />
                </div>
                <div className="footer">
                    <p>ПАО «МОСКОВСКИЙ КРЕДИТНЫЙ БАНК»</p>
                    <p>
                        Контакты службы поддержки систем дистанционного банковского обслуживания: <br/>
                        +7 495 797-42-348 <br/>
                        800 200-34-74 звонок по России бесплатный<br/>
                        03@mkb.ru
                    </p>
                </div>
            </div>
        </div>
    );
}
