import type { PageProps } from "keycloakify/login/pages/PageProps";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import React, {useEffect, useState} from "react";
import {OtpCodeInput} from "./components/CodeInput/CodeInput";
import {clsx} from "keycloakify/tools/clsx";
import backArrow from "../assets/back_arrow.svg";

const CODE_LENGTH = 6;

export default function TwoFaSms(props: PageProps<Extract<KcContext, { pageId: "2fa-sms.ftl"; }>, I18n>) {

    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;
    const [code, setCode] = useState('');
    const { mobileNumber, pageTitle, resendTime, attemptValidateCount, url, message } = kcContext;
    const [formattedTime, setFormattedTime] = useState('');
    const [isCountdownEnded, setIsCountdownEnded] = useState(false);

    // Функция для форматирования времени
    const getFormattedTime = (time: number) => {
        const minutes = Math.floor(time / 60).toString().padStart(2, '0');
        const seconds = (time % 60).toString().padStart(2, '0');
        return `${minutes}:${seconds}`;
    };

    useEffect(() => {
        let timeLeft = resendTime;
        setFormattedTime(getFormattedTime(timeLeft));
        setIsCountdownEnded(false);

        setInterval(() => {
            timeLeft = Math.max(0, timeLeft - 1);
            setFormattedTime(getFormattedTime(timeLeft));

            if (timeLeft <= 0) {
                setIsCountdownEnded(true);
            }
        }, 1000);

    }, [resendTime]);

    useEffect(() => {
        if (code.length === CODE_LENGTH) {
            const formElement = document.createElement('form');
            formElement.action = url.loginAction;
            formElement.method = 'POST';

            const hiddenField = document.createElement('input');
            hiddenField.type = 'hidden';
            hiddenField.name = 'codeOTP';
            hiddenField.value = code;

            formElement.appendChild(hiddenField);
            document.body.appendChild(formElement);
            formElement.submit();
        }
    }, [code]);

    const handleAttemptValidateOtp = () => {
        if (attemptValidateCount.toString() === "2") return "Неправильный код, попробуйте еще раз. Осталось 2 попытки"
        if (attemptValidateCount.toString() === "1") return "Неправильный код. Осталось 1 попытка. Далее доступ будет заблокирован на 15 минут"
        return ''
    };

    const resendSMS = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'resend_sms';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    return (
        <Template
            {...{kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                    <h1>{pageTitle}</h1>
                </>
            }
            infoNode={<span>footer</span>}
        >
                <div className="two-fa-text">Введите код подтверждения, который отправлен<br/>на номер
                    телефона {mobileNumber}</div>
                <OtpCodeInput value={code} setValue={(value) => setCode(value)} message={message}/>
                {message !== undefined && message.summary && (
                    <div className={clsx("alert", `alert-${message.type}`)}>
                        {message.summary === 'smsAuthCodeInvalid' && (
                            <span className={clsx("kc-feedback-text", "two-fa-error")}>{handleAttemptValidateOtp()}</span>
                        )}
                        {message.summary === 'smsAuthSmsNotSent' && (
                            <span className={clsx("kc-feedback-text", "two-fa-error")}>Ошибка. Код не был отправлен</span>
                        )}
                    </div>
                )}
                {isCountdownEnded ? (
                    <button type="button" className="two-fa-button" onClick={resendSMS}>Отправить код еще раз</button>
                ) : (
                    <div className="two-fa-caption">Отправить еще раз можно через {formattedTime}</div>
                )}
        </Template>
    );
}
