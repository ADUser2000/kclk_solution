import type { PageProps } from "keycloakify/login/pages/PageProps";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import React, {useEffect, useRef, useState} from "react";
import WarningImg from "../assets/warning.svg";
import DownArrow from "../assets/down_arrow.svg";
import DownloadIcon from "../assets/Download.svg";
import backArrow from "../assets/back_arrow.svg";

// @ts-ignore
import ccpa from 'crypto-pro-cadesplugin';

export default function CertificateStore(props: PageProps<Extract<KcContext, { pageId: "certificate-store.ftl"; }>, I18n>) {

    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;
    const [notAvailable, setNotAvailable] = useState(false);
    const { url, isShowError} = kcContext;
    const [certificatesNotFound, setCertificatesNotFound] = useState(false);
    const formRef = useRef<HTMLFormElement>(null);
    const [listCerts, setListCerts] = useState([{value: "подпись", label: "подпись"}]);

    const createAndSubmitForm = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'two_factor_type';
        hiddenField.value = 'sms_otp';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    }

    useEffect(() => {
        const doCertsList = async () => {
            try {
                const certsApi = await ccpa();
                var certsList;

                try {
                    certsList = await certsApi.getCertsList();
                } catch (error) {
                    if (isShowError) {
                        setCertificatesNotFound(true);
                    } else {
                        createAndSubmitForm();
                    }
                    return;
                }

                if (certsList.length === 0) {
                    if (isShowError) {
                        setCertificatesNotFound(true);
                    } else {
                        createAndSubmitForm();
                    }
                    return;
                }

                // @ts-ignore
                const list = certsList.map(({ thumbprint, serialNumber }) => ({
                    value: JSON.stringify({ thumbprint, serialNumber })
                }));
                setListCerts(list);
            } catch (error) {
                if (isShowError) {
                    setNotAvailable(true);
                } else {
                    createAndSubmitForm();
                }
            }
        };

        doCertsList();
    }, []);

    useEffect(() => {
        if (listCerts.length > 0 && formRef.current) {
            formRef.current.submit();
        }
    }, [listCerts]);

    const handleDownloadClick = () => {
        window.open('https://www.cryptopro.ru/products/cades/plugin', '_blank');
    };

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    return (
        <Template
            {...{kcContext, i18n, doUseDefaultCss, classes}}
            headerNode={(notAvailable || certificatesNotFound) && (
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow} alt="Назад"/>
                        <span>Назад</span>
                    </button>
                    {notAvailable || certificatesNotFound ? null : ('Способ подтверждения')}
                </>
            )}
            infoNode={<span>footer</span>}
        >
            <form ref={formRef} id="kc-form" className="company-choosing" action={url.loginAction} method="post">
                {listCerts.map((item, index) => (
                    <input key={index} name="certificates" value={item.value} type="hidden"/>
                ))}
            </form>
            {notAvailable && <div className="certificate-wrapper">
                <div className="title-wrapper">
                    <div className="img-wrapper">
                        <img src={WarningImg} alt="Не найден сертификат" className="warning"/>
                    </div>
                    <h2 className="title">КриптоПро ЭЦП Browser<br/> plug-in недоступен</h2>
                </div>
                <p className="text">Проверьте его настройки или попробуйте скачать<br/>
                    и установить его более новую версию<br/>
                    с сайта производителя
                </p>
                <button className="download" onClick={handleDownloadClick}>
                    <img src={DownloadIcon} alt="Скачать" className="download-icon"/>
                    Скачать плагин
                </button>
            </div>}

            {certificatesNotFound && <div className="certificate-wrapper">
                <div className="title-wrapper">
                    <div className="img-wrapper">
                        <img src={WarningImg} alt="Не найден сертификат" className="warning"/>
                    </div>
                    <h2 className="title">Не найден сертификат ключа<br/> электронной подписи</h2>
                </div>
                <p className="text">Сертификат ключа электронной подписи (КЭП)<br/>
                    можно скачать в личном кабинете сертификации<br/>
                    или установить с токена, на котором записана КЭП
                </p>
                <details>
                    <summary className="details-summary">
                        Как получить новый сертификат?
                        <img src={DownArrow} alt="Открыть" className="down-arrow"/>
                    </summary>
                    <p className="details-text">
                        Для получения сертификата предоставьте в банк заявку
                        на уполномоченное лицо. В системе «Ваш банк онлайн»,
                        раздел «Услуги и сервисы», «Управление электронной
                        подписью»
                    </p>
                </details>
            </div>}
        </Template>
    );
}