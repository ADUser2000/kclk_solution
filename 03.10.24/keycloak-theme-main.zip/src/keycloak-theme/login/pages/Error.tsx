import type { PageProps } from "keycloakify/login/pages/PageProps";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import Modal from "./components/Modal/Modal";

import BlockContent from "./components/BlockContent/BlockContent";
import ServerError from "./components/ServerError/ServerError";
import SignError from "./components/SignError/SignError";
import AccessToContainerError from "./components/AccessToContainerError/AccessToContainerError";

export default function Error(props: PageProps<Extract<KcContext, { pageId: "error.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;

    const { message, temporarilyBlockSecond, url, client } = kcContext;

    const { msg } = i18n;

    const navigateToUrl = () => {
        console.log(url.loginUrl)
        window.location.href = url.loginUrl;
    };

    const navigateToBaseUrl = () => {
        // @ts-ignore
        window.location.href = client.baseUrl;
    };

    let modalContent;

    console.log(message.summary)
    if (message.summary === 'temporarilyDisabled') {
        modalContent = <BlockContent onClose={navigateToBaseUrl} temporarilyBlockSecond={temporarilyBlockSecond} />;
    } else if (message.summary === 'errorVerifySigning') {
        modalContent = <SignError onClose={navigateToUrl} />;
    } else if (message.summary === 'errorAccessToCryptoContainer') {
        modalContent = <AccessToContainerError onClose={navigateToUrl} />;
    } else {
        modalContent = <ServerError onClose={navigateToBaseUrl} message={message.summary} />;
    }

    return (
        <Template {...{ kcContext, i18n, doUseDefaultCss, classes }} displayMessage={false} headerNode={msg("errorTitle")}>
            <Modal isModalOpen={true} onClose={navigateToUrl}>
                {modalContent}
            </Modal>
        </Template>
    );
}
