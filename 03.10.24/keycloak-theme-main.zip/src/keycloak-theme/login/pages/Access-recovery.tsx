import React, {useState, type FormEventHandler, useEffect} from "react";
import { clsx } from "keycloakify/tools/clsx";
import { useConstCallback } from "keycloakify/tools/useConstCallback";
import type { PageProps } from "keycloakify/login/pages/PageProps";
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import { useForm } from "react-hook-form";
import backArrow from "../assets/back_arrow.svg";
import ClearInput from "../assets/clear.svg";

interface IAccessRecoveryForm {
    login: string;
}

export default function AccessRecovery(props: PageProps<Extract<KcContext, { pageId: "access-recovery.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;

    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    const {
        register,
        setValue,
        watch,
    } = useForm<IAccessRecoveryForm>({
        mode: "onChange",
        defaultValues: { login: ""}
    })

    const { message, url, oldLogin } = kcContext;
    const login = watch('login')

    const onSubmit = useConstCallback<FormEventHandler<HTMLFormElement>>(e => {
        e.preventDefault();

        const formElement = e.target as HTMLFormElement;

        formElement.submit();
    });

    const [isErrorMessage, setIsErrorMessage] = useState(false)

    const handleLoginRemember = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'recoveryType';
        hiddenField.value = 'recoveryByContactData';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    useEffect(() => {
        if (oldLogin !== undefined) {
            setValue('login', oldLogin)
        }

    }, [oldLogin]);

    useEffect(() => {
        if (message !== undefined) {
            setIsErrorMessage(true)
        }
    }, [message]);

    const disabledButton = login === '' || login === oldLogin;

    const backButtonAction = () => {
        window.location.href = url.loginUrl;
    };

    return (
        <Template
            {...{ kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                    <h1>Восстановление доступа</h1>
                </>
            }
            infoNode={<span>footer</span>}
        >
            <div id="kc-form">
                <div id="kc-form-wrapper">
                    <form id="kc-form-login" onSubmit={onSubmit} action={url.loginAction} method="post">
                        <div className={getClassName("kcFormGroupClass")}>
                            <label htmlFor="login" className={getClassName("kcLabelClass")}>
                                Логин
                            </label>
                            <div className={getClassName("kcInputWrapperClass")}>
                                <input
                                    {...register('login', {
                                        required: true
                                    })}
                                    tabIndex={1}
                                    id="login"
                                    className={clsx(getClassName("kcInputClass"), isErrorMessage && "inputErrorClass")}
                                    name="login"
                                    type="text"
                                    autoComplete="off"
                                    placeholder="Введите логин"
                                    required
                                    onClickCapture={() => {
                                        setIsErrorMessage(false)
                                    }}
                                />
                                {login !== '' && login && (
                                    <img 
                                        src={ClearInput} 
                                        className="clear" 
                                        alt="Очистить поле" 
                                        onClick={() => setValue('login', '')}
                                    />
                                )}
                                {isErrorMessage && (
                                    <div className={clsx("alert", `alert-error`)}>
                                        <span
                                            className="kc-feedback-text"
                                            dangerouslySetInnerHTML={{
                                                "__html": "Для этого пользователя операция недоступна. <br/>В заявке не был указан email или номер телефона"
                                            }}
                                        />
                                    </div>
                                )}
                            </div>
                            
                        </div>
                        <div id="kc-form-buttons" className={clsx(getClassName("kcFormGroupClass"), "buttons")}>
                            <input
                                tabIndex={2}
                                className={clsx(
                                    getClassName("kcButtonClass"),
                                    getClassName("kcButtonPrimaryClass"),
                                    getClassName("kcButtonBlockClass"),
                                    getClassName("kcButtonLargeClass"),
                                    disabledButton && "disabled"
                                )}
                                name="sendButton"
                                id="kc-login"
                                type="submit"
                                value="Продолжить"
                                disabled={disabledButton}
                            />
                            <div className={getClassName("kcFormOptionsWrapperClass")}>
                                <span>
                                    <a tabIndex={3} href={'#'} onClick={handleLoginRemember}>
                                        Не помню логин
                                    </a>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </Template>
    );
}
