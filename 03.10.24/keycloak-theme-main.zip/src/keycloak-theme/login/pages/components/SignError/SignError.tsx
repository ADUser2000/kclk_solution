import React from 'react';
import {clsx} from "keycloakify/tools/clsx";
import "./styles.css"

export default function SignError(props: {onClose: () => void}) {
    const {onClose} = props;

    return (
        <>
            <h2 className="modal-title">Доступ запрещен</h2>
            <div className="modal-subtitle">
                Результат подписания не прошел проверку.<br/>
                Повторите вход.
            </div>
            <button className={clsx("kcButtonClass", "kcButtonPrimaryClass")} onClick={onClose}>Понятно</button>
        </>
    );
}