import "./styles.css";

export default function LetterContent(props: any) {
    const { letterContentData } = props;

    return (
        <div className="container">
            <div className="titling">
                <h1 className="title">{letterContentData.title}</h1>
                <p className="text">{letterContentData.text}</p>
            </div>
            <form id="kc-form-login" method="post">
                {letterContentData.tableData && (
                    <div className="request">
                        <h2 className="request-title">Данные по заявке</h2>
                        <div className="request-table">
                            {letterContentData.tableData.map((row: any) => (
                                <div className="request-table-row">
                                    <span className="request-row-title">{row.title}</span>
                                    <span className="request-row-data">{row.data}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                {letterContentData.buttonText && (
                    <input
                        className='button'
                        name="set-login"
                        id="kc-login"
                        type="submit"
                        value={letterContentData.buttonText}
                    />
                )}
            </form>
        </div>
    );
}