import React from 'react';
import {clsx} from "keycloakify/tools/clsx";
import "./styles.css"

export default function AccessToContainerError(props: {onClose: () => void}) {
    const {onClose} = props;

    return (
        <>
            <h2 className="modal-title">Доступ запрещен</h2>
            <div className="modal-subtitle">
                Ошибка при получение доступа к контейнеру.
            </div>
            <button className={clsx("kcButtonClass", "kcButtonPrimaryClass")} onClick={onClose}>Понятно</button>
        </>
    );
}