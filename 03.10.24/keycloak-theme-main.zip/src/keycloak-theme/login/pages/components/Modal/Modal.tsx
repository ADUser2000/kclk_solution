import React, {ReactNode} from 'react';
import "./styles.css"
import closeIcon from "../../../assets/close.svg";
import { clsx } from 'keycloakify/tools/clsx';

interface IProps {
    isModalOpen: boolean; 
    onClose: () => void; 
    children: ReactNode;
    isBig?: boolean;
}

export default function Modal(props: IProps) {
    const {isModalOpen, onClose, children, isBig} = props;

    if (!isModalOpen) return null

    return (
        <div className="modal">
            <div className={clsx("modal-content", isBig && "big")}>
                <button className="modal-close" onClick={onClose}>
                    <img src={closeIcon} />
                </button>
                <div className="modal-wrapper">
                    {children}
                </div>
            </div>
        </div>
    );
}