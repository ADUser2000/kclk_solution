import React from 'react';
import {clsx} from "keycloakify/tools/clsx";
import "./styles.css"

export default function ServerError(props: { onClose: () => void, message: string }) {
    const {onClose, message} = props;

    console.log(message)
    return (
        <>
            <h2 className="modal-title">Ошибка</h2>
            <div className="modal-subtitle">
                {message}
            </div>
            <button className={clsx("kcButtonClass", "kcButtonPrimaryClass")} onClick={onClose}>Понятно</button>
        </>
    );
}