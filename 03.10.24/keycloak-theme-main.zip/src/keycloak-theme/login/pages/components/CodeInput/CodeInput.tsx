import { range } from 'lodash';
import React, { FC, useCallback, useEffect, useMemo, useRef } from 'react';
import './styles.css';
import {clsx} from "keycloakify/tools/clsx";

interface IProps {
    codeLength?: number;
    isDisabled?: boolean;
    isError?: boolean;
    message: {type: "success" | "warning" | "error" | "info", summary: string} | undefined;
    setValue: (value: string) => void;
    value: string;
    // onClearError: () => void;
}

/**
 * Компонент для ввода OTP-кода.
 */
export const OtpCodeInput: FC<IProps> = (props) => {
    const { value, setValue, isError = false, isDisabled = false, codeLength = 6, message } = props;
    // рефы нужны чтобы ставить фокус на каждый из элементов
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
    const indIndex = useRef(0);

    const dataArray = useMemo(() => range(0, codeLength), [codeLength]);

    const cbRef = useCallback((el: HTMLInputElement | null) => {
        if (indIndex.current === 0) {
            el?.focus();
        }
        inputRefs.current[indIndex.current] = el;

        indIndex.current += 1;
    }, []);

    useEffect(() => {
        if (isError) {
            inputRefs?.current?.[0]?.focus();
        }
    }, [isError]);

    const handleInputChange = (index: number, event: React.ChangeEvent<HTMLInputElement>) => {
        const code = event.target.value;
        if (code === '' || code === ' ') {
            return
        } else if (!Number.isNaN(Number(code))) {
            let newCode = '';
            if (value[index]) {
                const actualCode = code.replace(value[index], '');
                newCode = value.slice(0, index) + actualCode + value.slice(index + 1);
            } else {
                newCode = value.slice(0, index) + code;
            }
            if (index < codeLength - 1) {
                inputRefs.current[index + 1]?.removeAttribute('disabled');
                inputRefs.current[index + 1]?.focus();
                inputRefs.current[index]?.setAttribute('disabled', 'true');
            }
            setValue(newCode);
        }
    };

    const handleInputKeyPress = (index: number, event: React.KeyboardEvent<HTMLInputElement>) => {
        const code = event.currentTarget.value;
        if (event.key === 'Backspace' && code.length === 0) {
            if (index > 0 && inputRefs.current[index - 1]) {
                inputRefs.current[index -1]?.removeAttribute('disabled');
                inputRefs.current[index - 1]?.focus();
                (inputRefs.current[index - 1] as HTMLInputElement).value = '';
                inputRefs.current[index]?.setAttribute('disabled', 'true');
                setValue(value.slice(0, index-1) + value.slice(index))
            }
        }
    };

    return (
        <div className="code-input">
            {dataArray.map((elem) => (
                <input
                    className={clsx("input-el", message !== undefined && "input-el-error")}
                    disabled={isDisabled || elem !== 0}
                    key={elem}
                    maxLength={1}
                    onChange={(e) => handleInputChange(elem, e)}
                    onKeyDown={(e) => handleInputKeyPress(elem, e)}
                    ref={cbRef}
                    type="text"
                    value={value[elem] || ''}
                    name="code"
                    onPaste={(e) => e.preventDefault()}
                    autoComplete='off'
                />
            ))}
        </div>
    );
};
