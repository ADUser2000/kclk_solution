import "./styles.css";
import BlockAccountImg from "../../../assets/BlockAccount.svg"
import EmailIcon from "../../../assets/EmailIcon.svg";
import PhoneIcon from "../../../assets/Phone.svg";

export default function BlockAccount() {

    return (
        <div className="wrapper">
            <img src={BlockAccountImg} alt="Доступ заблокирован" />
            <h2 className="title">Доступ заблокирован</h2>
            <div className="text">
                Доступ к системе «Ваш банк онлайн» заблокирован 
                в соответсвии с п 6.2.6 Правил электронного документооборота и 
                дистанционного банковского обслуживания клиентов – юридических 
                лиц, индивидуальных предпринимателей и физических лиц, 
                занимающихся в установленном законодательством Российской Федерации 
                порядке частной практикой, 
                в ПАО «МОСКОВСКИЙ КРЕДИТНЫЙ БАНК».
                Обратитесь к своему клиентскому менеджеру.
            </div>
            <div className="contacts">
                <div className="contacts-item">
                    <img src={EmailIcon} alt="Электронная почта" className="contact-icon" />
                    <div className="contact-text">
                        <p className="contact">03@mkb.ru</p>
                        <p className="contact-time">пн-пт с 5:00 до 20:00</p>
                    </div>
                </div>
                <div className="contacts-item">
                    <img src={PhoneIcon} alt="Номер телефона" className="contact-icon" />
                    <div className="contact-text">
                        <p className="contact">8 800 200-34-74</p>
                        <p className="contact-time">пн-вс с 9:00 до 21:00</p>
                    </div>
                </div>
                <div className="contacts-item">
                    <img src={PhoneIcon} alt="Номер телефона" className="contact-icon" />
                    <div className="contact-text">
                        <p className="contact">+7 495 797-42-34</p>
                        <p className="contact-time">пн-пт с 5:00 до 20:00</p>
                    </div>
                </div>
            </div>
        </div>
    );
}