import React, {useEffect, useState} from 'react';
import {clsx} from "keycloakify/tools/clsx";
import "./styles.css"
import {useCountdownTimer} from "../../../hooks/useCountdownTimer";

export default function BlockContent(props: { onClose: () => void, temporarilyBlockSecond: number }) {
    const {onClose, temporarilyBlockSecond} = props;
    const [expireTime, setExpireTime] = useState(temporarilyBlockSecond);
    const { reset: countdownReset, timeLeft } = useCountdownTimer(expireTime);

    useEffect(() => {
        countdownReset();
    }, [expireTime]);

    const getFormattedTime = (time: number) => time.toString().padStart(2, '0')

    const minutes = getFormattedTime(Math.floor(timeLeft/60));
    const seconds = getFormattedTime(timeLeft % 60);

    return (
        <>
            <h2 className="modal-title">Доступ заблокирован</h2>
            <div className="modal-subtitle">
                Превышен лимит попыток.<br/>
                Вы сможете продолжить работу через {minutes}:{seconds}
            </div>
            <button className={clsx("kcButtonClass", "kcButtonPrimaryClass")} onClick={onClose}>Понятно</button>
        </>
    );
}