import React from "react";
import { clsx } from "keycloakify/tools/clsx";
import type { PageProps } from "keycloakify/login/pages/PageProps";
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import OkIcon from '../assets/ok_icon.svg';
import backArrow from "../assets/back_arrow.svg";

export default function LoginRestored(props: PageProps<Extract<KcContext, { pageId: "login-restored.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;

    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    const handleEvent = (event: string) => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = event;
        hiddenField.value = event;

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    const { url } = kcContext;

    return (
        <Template
            {...{ kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                    <h1>Восстановление доступа</h1>
                </>
            }
            infoNode={<span>footer</span>}
        >
            <div id="kc-form">
                <div id="kc-form-wrapper">
                        <div className="recoverSuccess">
                            <div className="titleWrapper">
                                <div className="recoveryIcon">
                                    <img src={OkIcon} alt="Логин восстановлен" />
                                </div>
                                <h4 className="title">Логин восстановлен</h4>
                                
                            </div>
                            <div className="text">Логин отправлен на email</div>
                        </div>
                        <div id="kc-form-buttons" className={clsx(getClassName("kcFormGroupClass"), "buttons", "left-buttons")}>
                            <input
                                tabIndex={3}
                                className={clsx(
                                    getClassName("kcButtonClass"),
                                    getClassName("kcButtonPrimaryClass"),
                                    getClassName("kcButtonBlockClass"),
                                    getClassName("kcButtonLargeClass"),
                                )}
                                name="login"
                                id="kc-login"
                                type="submit"
                                value="Войти"
                                onClick={() => handleEvent("login")}
                            />
                            <input
                                tabIndex={4}
                                className={clsx(
                                    getClassName("kcButtonClass"),
                                    getClassName("kcButtonPrimaryClass"),
                                    getClassName("kcButtonBlockClass"),
                                    getClassName("kcButtonLargeClass"),
                                    "kcAccessRecoveryBtn"
                                )}
                                name="access-recovery"
                                id="access-recovery"
                                type="submit"
                                value="Восстановить пароль"
                                onClick={() => handleEvent("resetFlow")}
                            />
                        </div>
                </div>
            </div>
        </Template>
    );
}
