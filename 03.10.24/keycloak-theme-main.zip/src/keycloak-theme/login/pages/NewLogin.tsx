// ejected using 'npx eject-keycloak-page'
import { clsx } from "keycloakify/tools/clsx";
import type { PageProps } from "keycloakify/login/pages/PageProps";
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import { useForm } from 'react-hook-form';
import ClearInput from "../assets/clear.svg";
import ValidNeutral from "../assets/valid_pass.svg";
import ValidSuccess from "../assets/Success_filled.svg";
import ValidError from "../assets/valid_pass_error.svg";
import {Autocomplete, ListSubheader, Paper, TextField, Tooltip, TooltipProps, styled, tooltipClasses} from "@mui/material";
import {useEffect, useState} from "react";

const CustomPaper = (props: any) => {
    return <Paper {...props} sx={{marginTop: '8px'}} />;
};

type TValidationType = 'success' | 'neutral' | 'error';

const icons: Record<TValidationType, JSX.Element> = {
    neutral: <img src={ValidNeutral} alt="Выполнение требования валидации логина"/>,
    success: <img src={ValidSuccess} alt="Требование выполнено"/>,
    error: <img src={ValidError} alt="Требование не выполнено"/>
};

const StyledTooltip = styled(({ className, ...props }: TooltipProps) => (
    <Tooltip {...props} arrow classes={{ popper: className }} />
))(() => ({
    width: '424px',
    [`& .${tooltipClasses.arrow}`]: {
        color: '#242729',
    },
    [`& .${tooltipClasses.tooltip}`]: {
        backgroundColor: '#242729',
        fontSize: '14px',
        maxWidth: '100%',
        padding: '8px 16px',
    },
}));

interface LoginRequirement {
    id: number;
    condition: (value: string) => boolean;
    message: string;
}

export default function NewLogin(props: PageProps<Extract<KcContext, { pageId: "new-login.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;
    const header = "Доступные варианты";
    const isValidInput = /^[a-zA-Z0-9 ]*$/;
    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    const conditions: LoginRequirement[] = [
        {
            id: 1,
            condition: (login: string) => login?.length >= 6 && login?.length <= 30,
            message: 'От 6 до 30 символов',
        },
        {
            id: 2,
            condition: (login: string) => /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]/.test(login),
            message: 'Цифры и латинские буквы',
        },
        {
            id: 3,
            condition: (login: string) => /^[a-zA-Z]/.test(login),
            message: 'Первый символ является буквой'
        }
    ];

    const { url, loginOptions, message, oldLogin } = kcContext;

    const {
        register,
        watch,
        setValue,
    } = useForm({
        mode: "onChange",
        defaultValues: { login: "" }
    })
    const [showTooltip, setShowTooltip] = useState(false);
    const login: string = watch('login');
    const [isLoginFocused, setIsUsernameFocused] = useState(false);
    const [isLoginValid, setIsLoginValid] = useState(false);
    const [loginString, setLoginString] = useState('');
    const [isErrorMessage, setIsErrorMessage] = useState(false);

    const handleSubmit = (e: { preventDefault: () => void; }) => {
        e.preventDefault()
        const formElement = document.getElementById('kc-register-form') as HTMLFormElement
        formElement.submit();
    };

    const checkCondition = (conditionItem: LoginRequirement) => {
        let key: TValidationType = 'neutral';
        if (conditionItem.condition(login) && login) {
            key = 'success';
        }
        if (!conditionItem.condition(login) && !isLoginFocused && login) {
            key = 'error';
        }
        return icons[key]
    }

    useEffect(() => {
        if (oldLogin && oldLogin !== '') {
            setLoginString(oldLogin)
            setIsLoginValid(true)
        }
    }, [oldLogin]);

    useEffect(() => {
        if (message) {
            setIsErrorMessage(true)
        }
    }, [message]);

    useEffect(() => {
        const regex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,}$/;
        const loginValid = regex.test(loginString);
        setShowTooltip(!loginValid);
        setIsLoginValid(loginValid);
    }, [loginString]);

    return (
        <Template {...{ kcContext, i18n, doUseDefaultCss, classes }} headerNode={<>Регистрация <br/>в «Ваш банк онлайн»</>}>
            <form id="kc-register-form" className={getClassName("kcFormClass")} action={url.loginAction} method="post">
                <div className={clsx(getClassName("kcFormGroupClass"))}>
                    <div className={getClassName("kcLabelWrapperClass")}>
                        <label htmlFor="login"
                               className={clsx(getClassName("kcLabelClass"), isErrorMessage && "labelErrorClass")}>
                            Новый логин
                        </label>
                    </div>
                    <>
                        <StyledTooltip
                            title="Логин должен состоять из латинских букв, быть не короче 6 символов и содержать хотя бы одну цифру"
                            open={showTooltip}
                            placement="top-start"
                            arrow
                        >
                            <Autocomplete
                                PaperComponent={CustomPaper}
                                onClickCapture={() => {
                                    setIsErrorMessage(false)
                                }}
                                disablePortal
                                id="controllable-states-demo"
                                options={[header, ...loginOptions]}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        {...register('login', {required: true})}
                                    />
                                )}
                                renderOption={(props, option) => {
                                    if (option === header) {
                                        return (
                                            <ListSubheader
                                                key="static-header"
                                                component="div"
                                                style={{
                                                    backgroundColor: '#F7F7F7',
                                                    fontWeight: '700',
                                                    fontSize: '16px',
                                                    color: '#242729'
                                                }}
                                            >
                                                {option}
                                            </ListSubheader>
                                        );
                                    }
                                    return <li {...props}>{option}</li>;
                                }}
                                value={loginString}
                                onChange={(event: any, newValue: string | null) => {
                                    if (newValue !== null) {
                                        setLoginString(newValue.replace(' ', ''));
                                        setValue('login', newValue.replace(' ', ''), {shouldDirty: true});
                                    }
                                }}
                                inputValue={loginString}
                                onInputChange={(event, newInputValue) => {
                                    if (isValidInput.test(newInputValue)) {
                                        setValue('login', newInputValue.replace(' ', ''));
                                        setLoginString(newInputValue.replace(' ', ''));
                                    }
                                }}
                                freeSolo
                                sx={{
                                    backgroundColor: (isErrorMessage || !isLoginValid) ? '#FEE9D8' : '#F7F7F7',
                                    borderRadius: '8px',
                                    width: '424px',
                                    marginBottom: !isErrorMessage ? '43px' : '0',
                                    '&:hover': {
                                        border: 'none',
                                    },
                                    '& .MuiOutlinedInput-notchedOutline': {
                                        border: 'none',
                                    },
                                    '& .MuiSelect-select': {
                                        padding: 0,
                                    },
                                    '.MuiAutocomplete-popper': {
                                        paddingTop: '8px',
                                    },
                                }}

                            />
                        </StyledTooltip>
                        {isErrorMessage &&
                            <div className={clsx("alert", `alert-error`)}>
                                    <span
                                        className="kc-feedback-text"
                                        dangerouslySetInnerHTML={{"__html": "Такой логин уже занят"}}
                                    />
                            </div>
                        }
                    </>

                </div>
                <div className="conditions">
                    {conditions.map((item) => (
                        <div className="condition-wrapper">
                            {checkCondition(item)}
                            <p className="condition-text">{item.message}</p>
                        </div>
                    ))}
                </div>

                <div className={clsx(getClassName("kcFormGroupClass"), "buttons")}>
                    <div id="kc-form-buttons" className={getClassName("kcFormButtonsClass")}>
                        <input
                            className={clsx(
                                getClassName("kcButtonClass"),
                                getClassName("kcButtonPrimaryClass"),
                                getClassName("kcButtonBlockClass"),
                                getClassName("kcButtonLargeClass"),
                                (!isLoginValid) && "disabled"
                            )}
                            type="submit"
                            value={"Продолжить"}
                            disabled={!isLoginValid}
                            onClick={handleSubmit}
                        />
                    </div>
                </div>
            </form>
        </Template>
    );
}