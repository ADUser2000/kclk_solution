import type { PageProps } from "keycloakify/login/pages/PageProps";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import React, {useEffect, useState} from "react";
import {useCountdownTimer} from "../hooks/useCountdownTimer";
import backArrow from "../assets/back_arrow.svg";
import Replay from "../assets/replay.svg"
import { clsx } from "keycloakify/tools/clsx";

export default function AccessByQRCode(props: PageProps<Extract<KcContext, { pageId: "access-by-qr-code.ftl"; }>, I18n>) {

    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;
    const { url, statusUrl, sessionId} = kcContext;

    const [expireTime, setExpireTime] = useState(60 * 2);
    const [QRCode, setQRCode] = useState<string>(""); // Состояние для хранения QR кода
    const [isLoading, setIsLoading] = useState(false);
    const { reset: countdownReset, timeLeft, isCountdownEnded } = useCountdownTimer(expireTime);

    const checkForRedirect = (sessionId: string) => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'sessionId';
        hiddenField.value = sessionId;

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    useEffect(() => {
        countdownReset();
    }, [expireTime]);

    useEffect(() => {
        const interval = setInterval(() => {
            fetch(statusUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ sessionId: sessionId })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.loginQR) {
                        setQRCode("data:image/gif;base64,"+data.loginQR);
                        setIsLoading(true); // Сохраняем QR код в состояние
                    } else if (data.redirect) {
                        checkForRedirect(data.redirect.sessionId);
                        clearInterval(interval); // Остановка интервала после переадресации
                    }
                })
                .catch(error => {
                    console.error('Ошибка при выполнении запроса:', error);
                    clearInterval(interval); // Остановка интервала в случае ошибки
                });
        }, 1000);

        return () => clearInterval(interval); // Очистка интервала при размонтировании компонента
    }, [statusUrl, sessionId]);

    const getFormattedTime = (time: number) => time.toString().padStart(2, '0')

    const minutes = getFormattedTime(Math.floor(timeLeft/60));
    const seconds = getFormattedTime(timeLeft % 60);

    const createAndSubmitForm = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'resend';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    }

    if (isLoading) {
        return (
            <Template
                {...{kcContext, i18n, doUseDefaultCss, classes}}
                headerNode={
                    <button className="backButton" onClick={backButtonAction}>
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                }
                infoNode={<span>footer</span>}
            >
                <div className="access-by-qr">
                    <div className="qr-wrapper">
                        <div className="img-wrapper">
                            <img src={QRCode} alt="QR-код" className="qr"/>
                            {isCountdownEnded && (
                                <div className="overlay">
                                    <button className="update-btn" onClick={createAndSubmitForm}>
                                        <img src={Replay} alt="Обновить QR-код" />
                                    </button>
                                </div>
                            )}
                        </div>
                        <div className="timer-wrapper">
                            <p className="timer-text">Время действия:</p>
                            <p className="timer-digits">{minutes}:{seconds}</p>
                        </div>
                    </div>
                    <ol className="instructions">
                        <li className="instructions-item">Откройте приложение МКБ Бизнес или PayControl<br/>(с установленным и подтвержденным мобильным ключом)</li>
                        <li className="instructions-item">Включите «Сканер QR» и наведите камеру на QR</li>
                        <li className="instructions-item">Подтвердите операцию</li>
                    </ol>
                </div>

            </Template>
        );
    } else {
        return (<></>);
    }
}