import type {PageProps} from "keycloakify/login/pages/PageProps";
import type {KcContext} from "../kcContext";
import type {I18n} from "../i18n";
import Modal from "./components/Modal/Modal";
import Info from "./components/ServerError/ServerError";

export default function Error(props: PageProps<Extract<KcContext, { pageId: "info.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;

    const { message, url, client } = kcContext;

    const { msg } = i18n;

    const navigateToUrl = () => {
        console.log(url.loginUrl)
        window.location.href = url.loginUrl;
    };

    const navigateToBaseUrl = () => {
        // @ts-ignore
        window.location.href = client.baseUrl;
    };

    let modalContent = <Info onClose={navigateToBaseUrl} />;

    return (
        <Template {...{ kcContext, i18n, doUseDefaultCss, classes }} displayMessage={false} headerNode={msg("errorTitle")}>
            <Modal isModalOpen={true} onClose={navigateToUrl}>
                {modalContent}
            </Modal>
        </Template>
    );
}
