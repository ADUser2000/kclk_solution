import { useEffect, useState, type FormEventHandler } from "react";
import { clsx } from "keycloakify/tools/clsx";
import { useConstCallback } from "keycloakify/tools/useConstCallback";
import type { PageProps } from "keycloakify/login/pages/PageProps";
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import type { KcContext } from "../kcContext";
import type { I18n } from "../i18n";
import passwordImg from "../assets/psw.svg";
import passwordVisibleImg from "../assets/psw_visible.svg";
import QRCode from "../assets/Qr_code.svg";
import {Controller, useForm} from 'react-hook-form';
import BlockAccount from "./components/BlockAccount/BlockAccount";
import Modal from "./components/Modal/Modal";
import ClearInput from "../assets/clear.svg";
import { Checkbox, FormControlLabel } from "@mui/material";

const my_custom_param= new URL(window.location.href).searchParams.get("my_custom_param");

if (my_custom_param !== null) {
    console.log("my_custom_param:", my_custom_param);
}

interface ILoginForm {
    username: string;
    password: string;
    rememberMe: string;
}

export default function Login(props: PageProps<Extract<KcContext, { pageId: "login.ftl" }>, I18n>) {
    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;

    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });
    const [isPasswordCleanButton, setIsPasswordCleanButton] = useState(false);
    const [isLoginCleanButton, setIsLoginCleanButton] = useState(false);
    const { message, social, realm, url, auth, registrationDisabled } = kcContext;
    
    const { msg } = i18n;

    const [isPasswordShown, setIsPasswordShown] = useState(false);

    const {
        register,
        formState: {
            isValid
        },
        setValue,
        watch,
        control
    } = useForm<ILoginForm>({
        mode: "onChange",
        defaultValues: { username: "", password: "", rememberMe: "off" }
    });

    const togglePasswordVisibility = () => {
        setIsPasswordShown((prev) => !prev);
    };

    const onSubmit = useConstCallback<FormEventHandler<HTMLFormElement>>(e => {
        e.preventDefault();

        const formElement = e.target as HTMLFormElement;
        formElement.querySelector("input[name='email']")?.setAttribute("name", "username");

        formElement.submit();
    });

    const navigateToUrl = () => {
        window.location.href = url.loginUrl;
    };

    const loginByQRAction = () => {
        const formElement = document.getElementById('kc-form-login') as HTMLFormElement

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'loginByQR';
        hiddenField.value = 'true';

        formElement.appendChild(hiddenField);
        formElement.submit();
    };

    const [isChecked, setIsChecked] = useState(false);

    useEffect(() => {
        const subscription = watch((value) => {
            setIsChecked(value.rememberMe === 'on');
        });
        return () => subscription.unsubscribe();
    }, [watch]);

    return (
        <Template
            {...{ kcContext, i18n, doUseDefaultCss, classes }}
            displayInfo={social.displayInfo}
            displayWide={realm.password && social.providers !== undefined}
            headerNode={"Войти в «Ваш банк онлайн»"}
            infoNode={
                realm.password &&
                realm.registrationAllowed &&
                !registrationDisabled && (
                    <div id="kc-registration">
                        <span>
                            {msg("noAccount")}
                            <a tabIndex={6} href={url.registrationUrl}>
                                {msg("doRegister")}
                            </a>
                        </span>
                    </div>
                )
            }
        >
            <div id="kc-form" className={clsx(realm.password && social.providers !== undefined && getClassName("kcContentWrapperClass"))}>
                <div
                    id="kc-form-wrapper"
                    className={clsx(
                        realm.password &&
                        social.providers && [getClassName("kcFormSocialAccountContentClass"), getClassName("kcFormSocialAccountClass")]
                    )}
                >
                    {realm.password && (
                        <form id="kc-form-login" onSubmit={onSubmit} action={url.loginAction} method="post" className="login-form">
                            <div className={getClassName("kcFormGroupClass")}>
                                <label htmlFor="login" className={clsx(getClassName("kcLabelClass"), message !== undefined && "labelErrorClass")}>
                                    Логин
                                </label>
                                <div className={clsx("login-input-wrapper", getClassName("kcInputWrapperClass"))}>
                                    <input
                                        {...register('username', {
                                            required: true
                                        })}
                                        tabIndex={1}
                                        id="username"
                                        className={clsx(getClassName("kcInputClass"), message !== undefined && "inputErrorClass")}
                                        name="username"
                                        type="text"
                                        autoFocus={true}
                                        autoComplete="off"
                                        placeholder="Введите логин"
                                        onKeyDown={(e) => {
                                            if (e.key === ' ') {
                                                e.preventDefault();
                                            }
                                        }}
                                    />
                                    {watch('username') !== '' && (
                                        <img 
                                            src={ClearInput} 
                                            className="clear" 
                                            alt="Очистить поле" 
                                            onClick={() => setValue('username', '')}
                                        />
                                    )}
                                    <button type="button" className="login-by-qr" onClick={loginByQRAction}>
                                        <img src={QRCode} alt="Войти по QR-коду" />
                                    </button>
                                </div>
                            </div>
                            <div className={clsx(getClassName("kcFormGroupClass"), "password")}>
                                <label htmlFor="password" className={clsx(getClassName("kcLabelClass"), message !== undefined && "labelErrorClass")}>
                                    Пароль
                                </label>
                                <div className={clsx(getClassName("kcInputWrapperClass"), 'password-input-wrapper')}>
                                    <input
                                        {...register('password', {
                                            required: true
                                        })}
                                        tabIndex={2}
                                        id="password"
                                        className={clsx(getClassName("kcInputClass"), message !== undefined && "inputErrorClass")}
                                        name="password"
                                        type={isPasswordShown? "text" : "password"}
                                        autoComplete="off"
                                        placeholder="Введите пароль"
                                        onKeyDown={(e) => {
                                            if (e.key === ' ') {
                                                e.preventDefault();
                                            }
                                        }}
                                    />
                                    <img
                                        src={isPasswordShown ? passwordVisibleImg : passwordImg}
                                        className="passwordImg"
                                        alt="Показать/скрыть пароль"
                                        onClick={togglePasswordVisibility}
                                    />
                                    {watch('password') !== '' && (
                                        <img 
                                            src={ClearInput} 
                                            className="clear" 
                                            alt="Очистить поле" 
                                            onClick={() => setValue('password', '')}
                                        />
                                    )}
                                    {message !== undefined &&
                                        (message.summary === 'Account is disabled, contact your administrator.' ||
                                        message.summary === 'Учетная запись заблокирована, свяжитесь с администратором.' ?
                                            <Modal isModalOpen={true} onClose={navigateToUrl} isBig={true}>
                                                <BlockAccount />
                                            </Modal>
                                        :
                                            <div className={clsx("alert", `alert-${message.type}`)}>
                                                <span
                                                    className="kc-feedback-text"
                                                    dangerouslySetInnerHTML={{"__html": message.summary === 'Неправильное имя пользователя или пароль.' ? 'Неверный логин или пароль, попробуйте еще раз' : message.summary}}
                                                />
                                            </div>
                                        )
                                    }
                                </div>

                            </div>
                            <div className={clsx(getClassName("kcFormGroupClass"), getClassName("kcFormSettingClass"))}>
                                <div id="kc-form-options" className='checkbox'>
                                    <Controller
                                        name="rememberMe"
                                        control={control}
                                        render={({ field }) => (
                                        <FormControlLabel
                                            label="Запомнить меня"
                                            control={
                                                <Checkbox
                                                    {...field}
                                                    checked={field.value === 'on'}
                                                    onChange={(e) => setValue('rememberMe', e.target.checked ? 'on' : 'off')}
                                                    sx={{
                                                        color: '#ccc',
                                                        padding: '0 8px 0',
                                                        '&.Mui-checked': {
                                                            color: '#DD0A34',
                                                        },
                                                        '& .PrivateSwitchBase-input': {
                                                            height: '24px',
                                                        },
                                                        '& .MuiTouchRipple-root': {
                                                            height: '24px',
                                                        },
                                                    }} 
                                                />
                                            }
                                        />
                                        )}
                                    />
                                </div>
                            </div>
                            <div id="kc-form-buttons" className={clsx(getClassName("kcFormGroupClass"), "buttons")}>
                                <input
                                    type="hidden"
                                    id="id-hidden-input"
                                    name="credentialId"
                                    {...(auth?.selectedCredential !== undefined
                                        ? {
                                            "value": auth.selectedCredential
                                        }
                                        : {})}
                                />
                                <input
                                    tabIndex={4}
                                    className={clsx(
                                        getClassName("kcButtonClass"),
                                        getClassName("kcButtonPrimaryClass"),
                                        getClassName("kcButtonBlockClass"),
                                        getClassName("kcButtonLargeClass"),
                                        !isValid && "disabled"
                                    )}
                                    name="login"
                                    id="kc-login"
                                    type="submit"
                                    value="Войти"
                                    disabled={!isValid}
                                />
                                <div className={getClassName("kcFormOptionsWrapperClass")}>
                                    <span>
                                        <a tabIndex={5} href={url.loginResetCredentialsUrl}>
                                            Восстановить доступ
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </Template>
    );
}
