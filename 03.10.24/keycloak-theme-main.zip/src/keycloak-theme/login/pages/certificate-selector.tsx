import type {PageProps} from "keycloakify/login/pages/PageProps";
import type {KcContext} from "../kcContext";
import {ICertificate} from "../kcContext";
import type {I18n} from "../i18n";
import React from "react";
import {clsx} from "keycloakify/tools/clsx";
// @ts-ignore
import ccpa from 'crypto-pro-cadesplugin';
import { useGetClassName } from "keycloakify/login/lib/useGetClassName";
import WarningImg from "../assets/warning.svg";
import DownArrow from "../assets/down_arrow.svg";
import backArrow from "../assets/back_arrow.svg";

export default function CertificateSelector(props: PageProps<Extract<KcContext, { pageId: "certificate-selector.ftl"; }>, I18n>) {

    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;
    const { certificates, digest, isNotAvailableCertificate, url} = kcContext;

    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    const createAndSubmitForm = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'two_factor_type';
        hiddenField.value = 'sms_otp';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    }

    const createAndSubmitFormWithError = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'crypto_container_not_available';
        hiddenField.value = 'crypto_container_not_available';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    }

    async function sign(thumbprint: string) {
        try {
            const certsApi = await ccpa();
            const sign = await certsApi.signBase64(thumbprint, digest);

            const formElement = document.getElementById('kc-form') as HTMLFormElement
            formElement.querySelector("input[name='sign']")?.setAttribute("value", sign);
            formElement.submit();
        } catch (error) {
            if (error instanceof Error && error.message.includes("PIN entry attempts has been reached")) {
                createAndSubmitFormWithError()
            }
            console.error(error);
        }
    }

    const onSubmit = (organizationId: string, certificateNumber: string, thumbprint: string) => {
        const formElement = document.getElementById('kc-form') as HTMLFormElement
        formElement.querySelector("input[name='organizationId']")?.setAttribute("value", organizationId);
        formElement.querySelector("input[name='certificateNumber']")?.setAttribute("value", certificateNumber);
        sign(thumbprint);
    };

    const formatDate = (dateString: string) => {
        const date = new Date(dateString);

        const formattedDay = ("0" + date.getDate()).slice(-2);
        const formattedMonth = ("0" + (date.getMonth() + 1)).slice(-2);
        const formattedYear = date.getFullYear();

        return `${formattedDay}.${formattedMonth}.${formattedYear}`;
    };

    const showCertificateStatus = (certificateItem: ICertificate) => {
        let certificateStatus: JSX.Element;
        const expireDate = new Date(certificateItem.certificateExpireDate);
        const today = new Date();
        const timeDiff: number = Math.floor((expireDate.getTime() - today.getTime())/(1000 * 60 * 60 * 24)); // в днях
        if (timeDiff > 30) {
            certificateStatus = (
                <h5 className="date">Сертификат действителен до {formatDate(certificateItem.certificateExpireDate)}</h5>
            );
        } else if (timeDiff > 0) {
            certificateStatus = (
                <h5 className={clsx("date", "warning")}>Сертификат истекает через {timeDiff} дней</h5>
            );
        } else if (timeDiff === 0) {
            certificateStatus = (
                <h5 className={clsx("date", "warning")}>Сертификат истекает сегодня</h5>
            );
        } else {
            certificateStatus = (
                <h5 className={clsx("date", "expired")}>Сертификат истек</h5>
            );
        }
        return certificateStatus;
    }


    return (
        <Template
            {...{kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                    {isNotAvailableCertificate ? null : (<h1>Выберите сертификат</h1>)}
                </>
            }
            infoNode={<span>footer</span>}
        >
            {
                isNotAvailableCertificate ?
                    (
                        <div className="certificate-wrapper">
                            <div className="title-wrapper">
                                <div className="img-wrapper">
                                    <img src={WarningImg} alt="Не найден сертификат" className="warning"/>
                                </div>
                                <h2 className="title">Не найден сертификат ключа<br/> электронной подписи</h2>
                            </div>
                            <p className="text">Сертификат ключа электронной подписи (КЭП)<br/>
                                можно скачать в личном кабинете сертификации<br/>
                                или установить с токена, на котором записана КЭП
                            </p>
                            <details>
                                <summary className="details-summary">
                                    Как получить новый сертификат?
                                    <img src={DownArrow} alt="Открыть" className="down-arrow"/>
                                </summary>
                                <p className="details-text">
                                    Для получения сертификата предоставьте в банк заявку
                                    на уполномоченное лицо. В системе «Ваш банк онлайн»,
                                    раздел «Услуги и сервисы», «Управление электронной
                                    подписью»
                                </p>
                            </details>
                        </div>
                    ) :
                    (
                        <>
                            <form id="kc-form" className="certificate-selector" action={url.loginAction} method="post">
                                <div className="certificate-list">
                                    {certificates.map((certificate) => (
                                        <div className="item-wrapper"
                                             onClick={() => onSubmit(certificate.id, certificate.certificateNumber, certificate.thumbprint)}
                                             key={certificate.id}>
                                            <h4 className="agentName">{certificate.agentName}</h4>
                                            <h5 className="name">{certificate.name}</h5>
                                            {showCertificateStatus(certificate)}
                                        </div>
                                    ))}
                                </div>
                                <input name="organizationId" type="hidden"/>
                                <input name="sign" type="hidden"/>
                                <input name="certificateNumber" type="hidden"/>
                            </form>

                            <div id="kc-form-buttons"
                                 className={clsx(getClassName("kcFormGroupClass"), "buttons", "left-buttons")}>
                                <input
                                    tabIndex={3}
                                    className={clsx(
                                        getClassName("kcButtonClass"),
                                        getClassName("kcButtonDefaultClass"),
                                        getClassName("kcButtonBlockClass"),
                                        getClassName("kcButtonLargeClass"),
                                    )}
                                    name="auth-by-sms"
                                    id="kc-sms"
                                    type="submit"
                                    value="Войти по смс"
                                    onClick={createAndSubmitForm}
                                />
                            </div>
                        </>
                    )
            }
        </Template>
    );
}
