import type {PageProps} from "keycloakify/login/pages/PageProps";
import type {KcContext} from "../kcContext";
import type {I18n} from "../i18n";
import {useGetClassName} from "keycloakify/login/lib/useGetClassName";
import React, {useState} from "react";
import {clsx} from "keycloakify/tools/clsx";
import passwordImg from "../assets/psw.svg";
import passwordVisibleImg from "../assets/psw_visible.svg";
import ValidPassNeutral from "../assets/valid_pass.svg";
import ValidPassSuccess from "../assets/Success_filled.svg";
import ValidPassError from "../assets/valid_pass_error.svg";
import ClearInput from "../assets/clear.svg";
import {useForm} from 'react-hook-form';
import backArrow from "../assets/back_arrow.svg";

type TValidationType = 'success' | 'neutral' | 'error';

const icons: Record<TValidationType, JSX.Element> = {
    neutral: <img src={ValidPassNeutral} alt="Выполнение требования валидации пароля"/>,
    success: <img src={ValidPassSuccess} alt="Требование выполнено"/>,
    error: <img src={ValidPassError} alt="Требование не выполнено"/>
};

interface IPasswordVisibleStates {
    password: boolean;
    confirmPassword: boolean;
};

interface INewPasswordForm {
    password: string;
    confirmPassword: string;
}

interface PasswordRequirement {
    id: number;
    condition: (value: string) => boolean;
    message: string;
}

export default function NewPassword(props: PageProps<Extract<KcContext, { pageId: "new-password.ftl"; }>, I18n>) {

    const {kcContext, i18n, doUseDefaultCss, Template, classes} = props;
    const { url, pageTitle, oldLogin } = kcContext;
    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });

    const {
        register,
        formState: {
            errors,
            isValid,
        },
        setValue,
        watch
    } = useForm<INewPasswordForm>({
        mode: "onChange"
    })

    const conditions: PasswordRequirement[] = [
        {
            id: 1,
            condition: (password: string) => password?.length >= 8,
            message: 'От 8 символов',
        },
        {
            id: 2,
            condition: (password: string) => /\d/.test(password),
            message: 'Цифры',
        },
        {
            id: 3,
            condition: (password: string) => /[a-z]/.test(password),
            message: 'Строчные латинские буквы',
        },
        {
            id: 4,
            condition: (password: string) => /[A-Z]/.test(password),
            message: 'Заглавные латинские буквы',
        },
        {
            id: 5,
            condition: (password: string) => {
                const specialChars = '!«»#$%&()*+,-./:;<=>?@[\]^_`{|}~';
                return password?.split('').some((char) => specialChars.includes(char));
            },
            message: 'Спецсимволы !«»#$%&()*+,-./:;<=>?@[\]^_`{|}~',
        },
        {
            id: 6,
            condition: (password: string) => password !== oldLogin,
            message: 'Не совпадает с логином',
        },
    ];

    const password: string = watch('password')
    const confirmPassword: string = watch('confirmPassword')

    const [passwordsVisibility, setPasswordsVisibility] = useState<IPasswordVisibleStates>({
        password: false,
        confirmPassword: false,
    });

    const isPasswordValid = conditions.every((item) => item.condition(password)) && !errors.password;
    const isConfirmPasswordValid = confirmPassword !== '' && password === confirmPassword && !errors.confirmPassword;

    const [isPasswordFocused, setIsPasswordFocused] = useState(false);
    const [isConfirmPasswordFocused, setIsConfirmPasswordFocused] = useState(false);

    const handleChangePasswordVisibility = () => {
        setPasswordsVisibility((prev) => ({ ...prev, password: !prev.password }));
    };

    const handleChangeConfirmPasswordVisibility = () => {
        setPasswordsVisibility((prev) => ({ ...prev, confirmPassword: !prev.confirmPassword }));
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) =>{
        const name = e.target.name as keyof INewPasswordForm;
        const value = e.target.value.replace(' ', '');
        setValue(name, value)
    };
    
    const checkCondition = (conditionItem: PasswordRequirement) => {
        let key: TValidationType = 'neutral';
        if (conditionItem.condition(password) && password) {
            key = 'success';
        }
        if (!conditionItem.condition(password) && !isPasswordFocused && password) {
            key = 'error';
        }
        return icons[key]
    }

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    return (
        <Template
            {...{kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                    <h1>{pageTitle.includes('<br/>') ? (
                        pageTitle.split('<br/>').map((line, index, array) => (
                            <React.Fragment key={index}>
                                {line}{index < array.length - 1 && <br />}
                            </React.Fragment>
                        ))
                    ) : (
                        pageTitle
                    )}</h1>
                </>
            }
            // headerNode={isRegister !== undefined ? <h1>Регистрация<br/> в «Ваш банк онлайн»</h1> : <h1>Восстановление доступа</h1>}
            infoNode={<span>footer</span>}
        >
            <form id="kc-form" className="new-password" method="post" action={url.loginAction}>
                <div className={clsx(getClassName("kcFormGroupClass"), "password")}>
                    <label htmlFor="password" className={clsx(getClassName("kcLabelClass"), errors.password && "labelErrorClass")}>
                        Новый пароль
                    </label>
                    <div className={clsx(getClassName("kcInputWrapperClass"), 'password-input-wrapper')}>
                        <input
                            {...register('password', {
                                required: "Обязательное поле",
                                pattern: {
                                    value: /^[^а-яА-ЯёЁ]*$/,
                                    message: "В пароле может быть только латиница"
                                },
                                validate: {
                                    length: (password) => password?.length >= 8 || 'Ненадежный пароль',
                                    numbers: (password: string) => /\d/.test(password) || 'Ненадежный пароль',
                                    smallLetters: (password: string) => /[a-z]/.test(password) || 'Ненадежный пароль',
                                    bigLetters: (password: string) => /[A-Z]/.test(password) || 'Ненадежный пароль',
                                    chars: (password: string) => password?.split('').some((char) => '!«»#$%&()*+,-./:;<=>?@[\]^_`{|}~'.includes(char)) || 'Ненадежный пароль',
                                    old: (password: string) => password !== oldLogin || 'Ненадежный пароль',
                                },
                                onChange: (e) => handleChange(e)
                            })}
                            tabIndex={2}
                            id="password"
                            className={clsx(getClassName("kcInputClass"), errors.password && "inputErrorClass", isPasswordValid && "valid")}
                            name="password"
                            type={passwordsVisibility.password ? 'text' : 'password'}
                            autoComplete="off"
                            placeholder="Придумайте новый пароль"
                            required
                            onFocus={() => {
                                setIsPasswordFocused(true)
                            }}
                            onBlur={() => {
                                setIsPasswordFocused(false)
                            }}
                        />
                        <img
                            src={passwordsVisibility.password ? passwordVisibleImg : passwordImg}
                            className="passwordImg"
                            alt="Показать/скрыть пароль"
                            onClick={handleChangePasswordVisibility}
                        />
                        {password !== '' && password && (
                            <img src={ClearInput} className="clear" alt="Очистить поле"
                                 onClick={() => setValue('password', '')}/>
                        )}
                        {errors?.password &&
                            <p className="kc-feedback-text"><span>{String(errors.password?.message)}</span></p>}
                    </div>
                </div>
                <div className="conditions">
                {conditions.map((item) => (
                        <div className="condition-wrapper">
                            {checkCondition(item)}
                            <p className="condition-text">{item.message}</p>
                        </div>
                    ))}
                </div>
                <div className={clsx(getClassName("kcFormGroupClass"), "password")}>
                    <label htmlFor="password" className={clsx(getClassName("kcLabelClass"), errors.confirmPassword && "labelErrorClass")}>
                        Повторите новый пароль
                    </label>
                    <div className={clsx(getClassName("kcInputWrapperClass"), 'password-input-wrapper')}>
                        <input
                            {...register('confirmPassword', {
                                required: "Введите пароль еще раз",
                                validate: {
                                    isSameSame: (str: string) => str === password || "Пароли не совпадают"
                                },
                                pattern: {
                                    value: /^[^а-яА-ЯёЁ]*$/,
                                    message: "В пароле может быть только латиница"
                                },
                                onChange: (e) => handleChange(e)
                            })}
                            tabIndex={2}
                            id="confirmPassword"
                            className={clsx(
                                getClassName("kcInputClass"),
                                isConfirmPasswordValid && confirmPassword && "valid",
                                errors.confirmPassword && "inputErrorClass"
                            )}
                            name="confirmPassword"
                            type={passwordsVisibility.confirmPassword ? 'text' : 'password'}
                            autoComplete="off"
                            placeholder="Введите новый пароль еще раз"
                            required
                            onFocus={() => {
                                setIsConfirmPasswordFocused(true)
                            }}
                            onBlur={() => {
                                setIsConfirmPasswordFocused(false)
                            }}
                        />
                        <img
                            src={passwordsVisibility.confirmPassword ? passwordVisibleImg : passwordImg}
                            className="passwordImg"
                            alt="Показать/скрыть пароль"
                            onClick={handleChangeConfirmPasswordVisibility}
                        />
                        {confirmPassword !== '' && confirmPassword && (
                            <img
                                src={ClearInput}
                                className="clear"
                                alt="Очистить поле"
                                onClick={() => setValue('confirmPassword', '')}
                            />
                        )}
                        {errors?.confirmPassword &&
                            <p className="kc-feedback-text">{String(errors.confirmPassword?.message)}</p>}
                    </div>
                </div>
                <div id="kc-form-buttons" className={clsx(getClassName("kcFormGroupClass"), "buttons")}>
                    <input
                        tabIndex={4}
                        className={clsx(
                            getClassName("kcButtonClass"),
                            getClassName("kcButtonPrimaryClass"),
                            getClassName("kcButtonBlockClass"),
                            getClassName("kcButtonLargeClass"),
                            !isValid && "disabled"
                        )}
                        name="changePassword"
                        id="changePassword"
                        type="submit"
                        value="Продолжить"
                        disabled={!isValid}
                    />
                </div>
            </form>
        </Template>
    );

}
