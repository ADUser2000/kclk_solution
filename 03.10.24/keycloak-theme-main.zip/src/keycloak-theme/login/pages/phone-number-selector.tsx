import type {PageProps} from "keycloakify/login/pages/PageProps";
import type {KcContext} from "../kcContext";
import type {I18n} from "../i18n";
import {clsx} from "keycloakify/tools/clsx";
import {useGetClassName} from "keycloakify/login/lib/useGetClassName";
import {useEffect, useState} from "react";
import { Select, SelectChangeEvent } from '@mui/material';
import { MenuItem } from '@mui/material';
import backArrow from "../assets/back_arrow.svg";

export default function PhoneNumberSelector(props: PageProps<Extract<KcContext, { pageId: "phone-number-selector.ftl"; }>, I18n>) {

    const { kcContext, i18n, doUseDefaultCss, Template, classes } = props;
    const { getClassName } = useGetClassName({
        doUseDefaultCss,
        classes
    });
    const { phones , authByCertificateButton, url} = kcContext;
    const [isDisabled, setIsDisabled] = useState(true);

    const [selectedPhone, setSelectedPhone] = useState(phones[0]);

    const handleChange = (event: SelectChangeEvent) => {
        setSelectedPhone(event.target.value);
    };

    const createAndSubmitForm = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'two_factor_type';
        hiddenField.value = 'certificate';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    }

    useEffect(() => {
        setIsDisabled(phones.length === 1)
    }, [selectedPhone]);

    useEffect(() => {
        console.log("authByCertificateButton: " + authByCertificateButton)
    }, []);

    const submitForm = () => {
        const formElement = document.getElementById('kc-form') as HTMLFormElement;

        if (isDisabled) {
            const newInput = document.createElement('input');
            newInput.type = 'hidden';
            newInput.name = 'phone';
            newInput.value = selectedPhone;
            formElement.appendChild(newInput);
        }

        formElement.submit();
    };

    function maskPhoneNumber(phoneNumber: string) {
        const countryCode = phoneNumber.slice(0, 1);
        const areaCode = phoneNumber.slice(1, 4);
        const hiddenPart = " ***-**-";
        const lastDigits = phoneNumber.slice(9);

        return "+" + countryCode + " " + areaCode + " " + hiddenPart + lastDigits;
    }

    const backButtonAction = () => {
        const form = document.createElement('form');
        form.action = url.loginAction;
        form.method = 'POST';

        // Создать скрытое поле
        const hiddenField = document.createElement('input');
        hiddenField.type = 'hidden';
        hiddenField.name = 'backButton';
        hiddenField.value = 'true';

        form.appendChild(hiddenField);
        document.body.appendChild(form);
        form.submit();
    };

    return (
        <Template
            {...{ kcContext, i18n, doUseDefaultCss, classes }}
            headerNode={
                <>
                    <button onClick={backButtonAction} className="backButton">
                        <img src={backArrow}/>
                        <span>Назад</span>
                    </button>
                    <h1>Способ подтверждения</h1>
                </>
            }
            infoNode={<span>footer</span>}
        >
            <form id="kc-form" action={url.loginAction} method="post">
                <div className={clsx(getClassName("kcFormGroupClass"), "phone")}>
                    <label htmlFor="phone-select" className={getClassName("kcLabelClass")}>
                        Номер телефона
                    </label>
                    <Select name="phone"
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={selectedPhone}
                        onChange={handleChange}
                        className={getClassName("kcInputClass")}
                        MenuProps={{ style: { marginTop: '8px', maxHeight: '280px', } }}
                        sx={{
                            backgroundColor: '#F7F7F7',
                            borderRadius: '8px',
                            '&:hover': {
                                border: 'none',
                            },
                            '& .MuiOutlinedInput-notchedOutline': {
                                border: 'none',
                            },
                            '& .MuiSelect-select': {
                                padding: 0,
                            },
                            '&.Mui-disabled': {
                                backgroundColor: '#E3E3E8',
                                color: '#48484B'
                            },
                        }}
                        disabled={isDisabled}
                    >
                        {phones.map((phone, index) => (
                            <MenuItem
                                key={index}
                                value={phone}
                                className='select-item'
                                sx={{
                                    padding: '16px',
                                    '&.Mui-selected': {
                                        backgroundColor: 'white',
                                        color: '#DD0A34',
                                    }
                                }}
                            >
                                {maskPhoneNumber(phone)}
                            </MenuItem>
                        ))}
                    </Select>
                </div>
            </form>
            <div id="kc-form-buttons" className={clsx(getClassName("kcFormGroupClass"), "buttons", "left-buttons")}>
                <input
                    tabIndex={2}
                    className={clsx(
                        getClassName("kcButtonClass"),
                        getClassName("kcButtonPrimaryClass"),
                        getClassName("kcButtonBlockClass"),
                        getClassName("kcButtonLargeClass"),
                    )}
                    name="send"
                    id="kc-send"
                    type="submit"
                    value="Отправить смс"
                    onClick={submitForm}
                />
                {authByCertificateButton === true && (
                    <input
                        tabIndex={3}
                        className={clsx(
                            getClassName("kcButtonClass"),
                            getClassName("kcButtonDefaultClass"),
                            getClassName("kcButtonBlockClass"),
                            getClassName("kcButtonLargeClass"),
                        )}
                        name="auth-by-certificate"
                        id="kc-sertificate"
                        type="submit"
                        value="Войти по сертификату"
                        onClick={createAndSubmitForm}
                    />
                )}
            </div>
        </Template>
    );

}
