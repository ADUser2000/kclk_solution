package ru.mkb.consentverification.dto;

// ConsentVerificationRequestDto.java (запрос к Consents_service)
class ConsentVerificationRequestDto {
    private String consentId;
    private String ssoId; // или userId
    private String organizationId;
    private String signedData; // Подписанные данные в Base64 или др. формате
    private String selectedAccounts; // Строка или список выбранных счетов
    // getters and setters
    public ConsentVerificationRequestDto(String consentId, String ssoId, String organizationId, String signedData, String selectedAccounts) { /* ... */ }
}
