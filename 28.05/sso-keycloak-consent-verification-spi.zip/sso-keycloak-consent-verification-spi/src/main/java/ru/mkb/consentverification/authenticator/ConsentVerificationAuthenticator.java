package ru.mkb.consentverification.authenticator;

import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.jboss.logging.Logger;
// import com.fasterxml.jackson.databind.ObjectMapper;

public class ConsentVerificationAuthenticator implements Authenticator {
    private static final Logger logger = Logger.getLogger(ConsentVerificationAuthenticator.class);

    public static final String AUTH_NOTE_SIGNED_CONSENT_DATA = "signedConsentDataFromForm";
    public static final String AUTH_NOTE_SELECTED_ACCOUNTS_DATA = "selectedAccountsFromForm";
    public static final String AUTH_NOTE_ORGANIZATION_ID = "organizationId";

    public static final String CONFIG_CONSENTS_SERVICE_VERIFY_URL = "consents.service.verify.url";

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        logger.info("ConsentVerificationSpi: authenticate called");

        String signedData = context.getAuthenticationSession().getAuthNote(AUTH_NOTE_SIGNED_CONSENT_DATA);
        String selectedAccounts = context.getAuthenticationSession().getAuthNote(AUTH_NOTE_SELECTED_ACCOUNTS_DATA);
        String consentId = context.getAuthenticationSession().getClientNote("consent_id");
        String organizationId = context.getAuthenticationSession().getAuthNote(AUTH_NOTE_ORGANIZATION_ID); // Из ConsentManagementSpi
        String ssoId = context.getUser().getId(); // Или другой идентификатор пользователя

        if (signedData == null || signedData.isEmpty()) {
            logger.error("Signed data is missing for verification.");
            context.failure(AuthenticationFlowError.INVALID_CREDENTIALS,
                    context.form().setError("Missing signed data for verification.").createErrorPage(Response.Status.BAD_REQUEST));
            return;
        }

        // Формируем запрос к Consents_service (шаг 22-23)
        String consentsServiceVerifyUrl = context.getAuthenticatorConfig().getConfig().get(CONFIG_CONSENTS_SERVICE_VERIFY_URL);
        // ConsentVerificationRequestDto requestDto = new ConsentVerificationRequestDto(consentId, ssoId, organizationId, signedData, selectedAccounts);
        // ConsentVerificationResponseDto responseDto = makeHttpPostCall(consentsServiceVerifyUrl, requestDto, ConsentVerificationResponseDto.class);

        // Заглушка ответа
        boolean verificationSuccess = true; // Предположим, что заглушка всегда успешна
        // if (responseDto != null && "OK".equals(responseDto.getStatus())) { // Проверяем ответ от Consents_service (шаг 26)
        //    verificationSuccess = true;
        // }

        if (verificationSuccess) {
            logger.info("Consent verification successful for consentId: " + consentId);
            // Очистить временные authNotes, если они больше не нужны
            context.getAuthenticationSession().removeAuthNote(AUTH_NOTE_SIGNED_CONSENT_DATA);
            context.getAuthenticationSession().removeAuthNote(AUTH_NOTE_SELECTED_ACCOUNTS_DATA);
            // другие auth_notes можно оставить, если они нужны для Claims в id_token, или тоже почистить

            context.success(); // Успешное завершение, далее Keycloak выдаст токены
        } else {
            logger.warn("Consent verification failed for consentId: " + consentId);
            // responseDto может содержать детали ошибки
            context.failure(AuthenticationFlowError.INVALID_CREDENTIALS, // или другой подходящий AuthenticationFlowError
                    context.form().setError("Consent verification failed.").createErrorPage(Response.Status.BAD_REQUEST));
        }
    }

    // private <T, R> R makeHttpPostCall(String url, T requestBody, Class<R> responseType) { /* ... реализация ... */ return null;}

    @Override
    public void action(AuthenticationFlowContext context) {
        // Не используется
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}