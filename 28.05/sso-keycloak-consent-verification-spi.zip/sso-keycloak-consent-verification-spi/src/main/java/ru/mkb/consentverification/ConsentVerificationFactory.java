package ru.mkb.consentverification;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.consentverification.authenticator.ConsentVerificationAuthenticator;

import java.util.Collections;
import java.util.List;

public class ConsentVerificationFactory implements AuthenticatorFactory {

    public static final String PROVIDER_ID = "consent-verification-spi";
    private static final ConsentVerificationAuthenticator SINGLETON = new ConsentVerificationAuthenticator();

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getDisplayType() {
        return "Consent Verification";
    }

    @Override
    public String getHelpText() {
        return "Verifies the signed consent by calling an external Consents service.";
    }
    @Override
    public String getReferenceCategory() {
        return "Consent";
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return Collections.singletonList(
                new ProviderConfigProperty(ConsentVerificationAuthenticator.CONFIG_CONSENTS_SERVICE_VERIFY_URL, "Consents Service Verify URL",
                        "URL for the Consents Service to verify/store signed consent (e.g., http://localhost:8081/api/consents/verify).", ProviderConfigProperty.STRING_TYPE, null)
        );
    }

    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public void init(Config.Scope config) {
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {
    }

    @Override
    public void close() {
    }
}