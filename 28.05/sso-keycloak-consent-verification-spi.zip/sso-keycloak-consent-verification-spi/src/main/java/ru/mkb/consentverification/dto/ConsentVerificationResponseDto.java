package ru.mkb.consentverification.dto;

// ConsentVerificationResponseDto.java (ответ от Consents_service)
class ConsentVerificationResponseDto {
    private String status; // "OK", "ERROR"
    private String message;
    // getters and setters
}
