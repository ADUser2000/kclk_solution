package ru.mkb.consentformdisplay.dto;

import java.util.List;

// ConsentDataDto.java (ответ от Consents_service)
class ConsentDataDto {
    private String status;
    private List<String> accounts; // Список счетов
    private String organizationId;
    private List<String> authorizedPersons;
    // private boolean userEio; // Флаг, является ли пользователь ЕИО
    // getters and setters
}
