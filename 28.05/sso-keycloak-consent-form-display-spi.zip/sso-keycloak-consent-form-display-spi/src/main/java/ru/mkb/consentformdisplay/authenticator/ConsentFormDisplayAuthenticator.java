package ru.mkb.consentformdisplay.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.extern.java.Log;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.forms.login.LoginFormsProvider;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.sessions.AuthenticationSessionModel;
// import com.fasterxml.jackson.databind.ObjectMapper; // Для JSON

@Log
public class ConsentFormDisplayAuthenticator implements Authenticator {

    public static final String FORM_FTL = "consent-form.ftl"; // Имя вашего FreeMarker шаблона

    // Ключи для параметров формы
    public static final String FORM_PARAM_SIGNED_DATA = "signedConsentData";
    public static final String FORM_PARAM_SELECTED_ACCOUNTS = "selectedAccounts"; // Может быть несколько
    public static final String FORM_PARAM_ACTION = "formAction"; // "submit" или "decline"

    // Ключи для authNotes (результат работы формы)
    public static final String AUTH_NOTE_CONSENT_DATA = "consentData";
    public static final String AUTH_NOTE_CRYPTO_PROFILES = "cryptoProfiles";
    public static final String AUTH_NOTE_DOCUMENT_ACTIONS = "documentActions";
    public static final String AUTH_NOTE_SIGNED_CONSENT_DATA = "signedConsentDataFromForm";
    public static final String AUTH_NOTE_SELECTED_ACCOUNTS_DATA = "selectedAccountsFromForm";

    // Ключ для конфигурации (URL для Consents_service при отказе)
    public static final String CONFIG_CONSENTS_SERVICE_DECLINE_URL = "consents.service.decline.url";


    @Override
    public void authenticate(AuthenticationFlowContext context) {

        // Получаем данные, подготовленные ConsentManagementSpi
        String consentDataJson = context.getAuthenticationSession().getAuthNote(AUTH_NOTE_CONSENT_DATA);
        String cryptoProfilesJson = context.getAuthenticationSession().getAuthNote(AUTH_NOTE_CRYPTO_PROFILES);
        String documentActionsJson = context.getAuthenticationSession().getAuthNote(AUTH_NOTE_DOCUMENT_ACTIONS);

        // ObjectMapper mapper = new ObjectMapper();
        // ConsentDataDto consentData = mapper.readValue(consentDataJson, ConsentDataDto.class);
        // CryptoProfilesDto cryptoProfiles = ...
        // DocumentActionsResponseDto docActions = ...

        // Получаем redirect_uri для кнопки "Отказать"
        AuthenticationSessionModel authSession = context.getAuthenticationSession();
        String declineRedirectUri = authSession.getRedirectUri(); // Базовый redirect_uri
        // Возможно, нужно добавить параметры ошибки к declineRedirectUri, например:
        // declineRedirectUri += (declineRedirectUri.contains("?") ? "&" : "?") + "error=access_denied&error_description=consent_declined";


        LoginFormsProvider form = context.form()
                .setAttribute("consentDataJson", consentDataJson) // Передаем как JSON строки или распарсенные DTO
                .setAttribute("cryptoProfilesJson", cryptoProfilesJson)
                .setAttribute("documentActionsJson", documentActionsJson)
                .setAttribute("declineRedirectUri", declineRedirectUri) // Для кнопки "Отказаться" на форме
                .setActionUri(context.getActionUrl(authSession.getParentSession().getId())); // URL для POST формы

        // Можно передать и распарсенные объекты, если FreeMarker их сможет обработать
        // form.setAttribute("consentData", consentData);

        Response challenge = form.createForm(FORM_FTL);
        context.challenge(challenge);
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        log.info("ConsentFormDisplaySpi: action called - processing form submission");
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
        String formAction = formData.getFirst(FORM_PARAM_ACTION);

        if ("decline".equals(formAction)) {
            handleDecline(context);
            return;
        }

        // Пользователь подтвердил согласие
        String signedData = formData.getFirst(FORM_PARAM_SIGNED_DATA);
        // List<String> selectedAccounts = formData.get(FORM_PARAM_SELECTED_ACCOUNTS); // Если это список
        String selectedAccountsConcatenated = formData.getFirst(FORM_PARAM_SELECTED_ACCOUNTS); // Если передается как одна строка

        if (signedData == null || signedData.isEmpty()) {
            // Ошибка: нет данных подписи
            context.failureChallenge(AuthenticationFlowError.INVALID_CREDENTIALS,
                    context.form().setError("Missing signed consent data.").createErrorPage(Response.Status.BAD_REQUEST));
            return;
        }

        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_SIGNED_CONSENT_DATA, signedData);
        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_SELECTED_ACCOUNTS_DATA, selectedAccountsConcatenated);

        log.info("ConsentFormDisplaySpi: consent submitted, proceeding to verification.");
        context.success(); // Переход к ConsentVerificationSpi
    }

    private void handleDecline(AuthenticationFlowContext context) {
        log.info("ConsentFormDisplaySpi: user declined consent.");
        AuthenticationSessionModel authSession = context.getAuthenticationSession();
        String consentId = authSession.getClientNote("consent_id");
        String ssoId = context.getUser().getId();

        // 1. Уведомить Consents_service об отказе (шаг 23 альт. потока)
        // POST /consents/decline (или аналогичный endpoint)
        // String consentsServiceDeclineUrl = context.getAuthenticatorConfig().getConfig().get(CONFIG_CONSENTS_SERVICE_DECLINE_URL);
        // makeHttpPostCall(consentsServiceDeclineUrl, new DeclineRequestDto(consentId, ssoId), Void.class);
        log.info("Mock call to Consents_service: consent " + consentId + " declined by user " + ssoId);


        // 2. Редирект пользователя на redirect_uri с ошибкой (шаг 22 альт. потока)
        String baseRedirectUri = authSession.getRedirectUri();
        String state = authSession.getClientNote("state"); // OIDC state parameter

        String errorRedirectUri = baseRedirectUri +
                (baseRedirectUri.contains("?") ? "&" : "?") +
                "error=access_denied" +
                "&error_description=User+declined+the+consent";
        if (state != null && !state.isEmpty()) {
            errorRedirectUri += "&state=" + state;
        }

        log.info("Redirecting user to: " + errorRedirectUri);
        context.cancelLogin(); // Прерываем текущий flow
        // Важно: context.cancelLogin() может не делать редирект сам.
        // Редирект делается через Response, который Keycloak отправит браузеру.
        // Обычно OIDC ошибки обрабатываются Keycloak автоматически, если flow завершается с ошибкой.
        // Если нужен явный редирект на 302 no redirect_uri:
        // context.challenge(Response.status(Response.Status.FOUND).location(URI.create(errorRedirectUri)).build());
        // Но лучше использовать стандартные механизмы Keycloak для завершения потока с ошибкой,
        // чтобы он сам сформировал корректный редирект в соответствии с OIDC.
        // Например, можно установить ошибку в сессии, чтобы стандартный обработчик OIDC ее подхватил:
        authSession.setAuthNote("error_type", "access_denied");
        authSession.setAuthNote("error_message", "User declined the consent");
        // И затем вызвать метод, который приведет к обработке этой ошибки стандартным OIDC механизмом.
        // Это может потребовать кастомной настройки flow error handling.
        // Простейший вариант - если `context.cancelLogin()` правильно обрабатывается и приводит к редиректу с ошибкой.
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}
