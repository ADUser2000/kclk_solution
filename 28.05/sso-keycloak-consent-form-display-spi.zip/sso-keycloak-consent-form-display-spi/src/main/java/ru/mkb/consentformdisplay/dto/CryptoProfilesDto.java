package ru.mkb.consentformdisplay.dto;

import java.util.List;

class CryptoProfilesDto {
    private List<CryptoProfile> profiles;
    // getters and setters
}
