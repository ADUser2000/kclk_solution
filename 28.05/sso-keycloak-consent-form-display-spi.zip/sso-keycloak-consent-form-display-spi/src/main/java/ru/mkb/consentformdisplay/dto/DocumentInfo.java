package ru.mkb.consentformdisplay.dto;

class DocumentInfo {
    private String documentId;
    // amount, accountNumber (если нужны для ACCOUNTS_CONSENT)
    // getters and setters
}
