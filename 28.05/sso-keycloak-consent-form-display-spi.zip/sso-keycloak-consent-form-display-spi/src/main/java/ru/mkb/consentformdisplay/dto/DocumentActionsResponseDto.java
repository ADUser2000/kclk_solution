package ru.mkb.consentformdisplay.dto;

class DocumentActionsResponseDto {
    private String error; // None, Exception, etc.
    private DocumentActionsResult result;

    // getters and setters

//    public boolean canSign() {
//        return result != null && result.getActions() != null && !result.getActions().isEmpty() && result.getActions().get(0).isCanSign();
//    }
}