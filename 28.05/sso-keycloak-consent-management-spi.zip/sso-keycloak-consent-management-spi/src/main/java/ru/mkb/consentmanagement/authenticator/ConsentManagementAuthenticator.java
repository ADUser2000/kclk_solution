package ru.mkb.consentmanagement.authenticator;

import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.jboss.logging.Logger;
// import com.fasterxml.jackson.databind.ObjectMapper; // Для JSON
// import org.keycloak.broker.provider.util.SimpleHttp; // Для HTTP запросов

public class ConsentManagementAuthenticator implements Authenticator {

    private static final Logger logger = Logger.getLogger(ConsentManagementAuthenticator.class);
    // Ключи для хранения URL в конфигурации AuthenticatorConfigModel
    public static final String CONFIG_CONSENTS_SERVICE_URL = "consents.service.url";
    public static final String CONFIG_USER_IDENTIFY_DATA_CRYPTO_URL = "useridentifydata.crypto.url";
    public static final String CONFIG_USER_IDENTIFY_DATA_ACTIONS_URL = "useridentifydata.actions.url";

    // Ключи для authNotes
    public static final String AUTH_NOTE_CONSENT_DATA = "consentData";
    public static final String AUTH_NOTE_CRYPTO_PROFILES = "cryptoProfiles";
    public static final String AUTH_NOTE_DOCUMENT_ACTIONS = "documentActions";
    public static final String AUTH_NOTE_ORGANIZATION_ID = "organizationId"; // Из ответа Consents_service
    public static final String AUTH_NOTE_OFFICIAL_ID = "officialId"; // ID уполномоченного лица, вероятно sso_id


    @Override
    public void authenticate(AuthenticationFlowContext context) {
        logger.info("ConsentManagementSpi: authenticate called");
        UserModel user = context.getUser();
        RealmModel realm = context.getRealm();
        KeycloakSession session = context.getSession();

        // 1. Получить consent_id и sso_id (user_id)
        // consent_id мог быть передан как параметр в /authorize и сохранен в clientSession или authSession
        String consentId = context.getAuthenticationSession().getClientNote("consent_id"); // или другой источник
        String ssoId = user.getId(); // или другой атрибут пользователя, если sso_id - это не Keycloak user ID

        if (consentId == null || consentId.isEmpty()) {
            logger.error("Consent ID is missing.");
            // Определить, как обрабатывать ошибку - возможно, context.failure(...)
            context.attempted(); // или другой статус, если это не критическая ошибка, а ожидание другого шага
            return;
        }

        String organizationIdFromInitialRequest = context.getAuthenticationSession().getClientNote("inn"); // Предполагаем, что ИНН/КПП сохраняются

        // 2. Запрос в Consents_service (шаг 8)
        // GET /consent/{consentId} (с ssoId/ИНН/КПП в параметрах или заголовках, если нужно)
        String consentsServiceUrl = context.getAuthenticatorConfig().getConfig().get(CONFIG_CONSENTS_SERVICE_URL);
        // Пример: String consentServiceFullUrl = consentsServiceUrl + "/" + consentId + "?sso_id=" + ssoId;
        // ConsentDataDto consentData = makeHttpCall(consentServiceFullUrl, ConsentDataDto.class);
        // if (consentData == null || !consentData.isUserEio()) { // Проверка ЕИО (шаг 9)
        //    logger.warnf("Failed to get consent data or user %s is not EIO for consent %s", ssoId, consentId);
        //    context.failure(AuthenticationFlowError.ACCESS_DENIED, Response.status(Response.Status.FORBIDDEN)
        //        .entity("User is not authorized for this consent.").type(MediaType.TEXT_PLAIN).build());
        //    return;
        // }
        // context.getAuthenticationSession().setAuthNote(AUTH_NOTE_CONSENT_DATA, convertToJson(consentData));
        // context.getAuthenticationSession().setAuthNote(AUTH_NOTE_ORGANIZATION_ID, consentData.getOrganizationId()); // Нужно для след. запросов
        // context.getAuthenticationSession().setAuthNote(AUTH_NOTE_OFFICIAL_ID, ssoId); // или другой ID пользователя, который является УЛ

        String mockConsentDataJson = "{\"status\":\"PENDING\", \"accounts\":[\"123\",\"456\"], \"organizationId\":\"org123\", \"authorizedPersons\":[\"userABC\"]}"; // Заглушка
        String mockOrganizationId = "org123"; // Заглушка из ответа Consents_service
        String mockOfficialId = ssoId; // Заглушка - ID пользователя Keycloak

        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_CONSENT_DATA, mockConsentDataJson);
        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_ORGANIZATION_ID, mockOrganizationId);
        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_OFFICIAL_ID, mockOfficialId);


        // 3. Запрос в UserIdentifyData за криптопрофилями (шаги 11-14)
        // GET /GetActiveCryptoProfiles (через BFF_UserIdentifyData)
        // Параметры: officialId, organizationId (полученные на шаге 10)
        String cryptoUrl = context.getAuthenticatorConfig().getConfig().get(CONFIG_USER_IDENTIFY_DATA_CRYPTO_URL);
        // CryptoProfilesDto cryptoProfiles = makeHttpCall(cryptoUrl + "?officialId=" + mockOfficialId + "&organizationId=" + mockOrganizationId, CryptoProfilesDto.class);
        // if (cryptoProfiles == null) {
        //    logger.warnf("Failed to get crypto profiles for user %s, org %s", mockOfficialId, mockOrganizationId);
        //    // Обработка ошибки
        //    return;
        // }
        // context.getAuthenticationSession().setAuthNote(AUTH_NOTE_CRYPTO_PROFILES, convertToJson(cryptoProfiles));
        String mockCryptoProfilesJson = "{\"profiles\":[{\"id\":\"profile1\", \"name\":\"CryptoPro CSP\"}]}"; // Заглушка
        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_CRYPTO_PROFILES, mockCryptoProfilesJson);


        // 4. Запрос в UserIdentifyData за возможностью подписания документа (шаги 16-19)
        // POST /GetDocumentsActions (через BFF_UserIdentifyData)
        // Тело запроса: officialId, organizationId, documentType="ACCOUNTS_CONSENT", documents=[{documentId:"<ID документа согласия>", ...}]
        // documentId может быть равен consentId или генерироваться на лету
        String actionsUrl = context.getAuthenticatorConfig().getConfig().get(CONFIG_USER_IDENTIFY_DATA_ACTIONS_URL);
        // DocumentActionsRequestDto actionsRequest = new DocumentActionsRequestDto(mockOfficialId, mockOrganizationId, "ACCOUNTS_CONSENT", consentId);
        // DocumentActionsResponseDto docActions = makeHttpPostCall(actionsUrl, actionsRequest, DocumentActionsResponseDto.class);
        // if (docActions == null || !docActions.canSign()) { // Проверяем, есть ли canSign в ответе
        //    logger.warnf("Document signing not possible for user %s, org %s, consent %s", mockOfficialId, mockOrganizationId, consentId);
        //    // Обработка ошибки
        //    return;
        // }
        // context.getAuthenticationSession().setAuthNote(AUTH_NOTE_DOCUMENT_ACTIONS, convertToJson(docActions));
        String mockDocActionsJson = "{\"result\":{\"actions\":[{\"documentId\":\"" + consentId + "\", \"canSign\":true, \"canRevokeSign\":false, \"canSendAfterSign\":false, \"canCancelProcessSign\":false, \"message\":\"OK\"}]}}"; // Заглушка
        context.getAuthenticationSession().setAuthNote(AUTH_NOTE_DOCUMENT_ACTIONS, mockDocActionsJson);

        logger.info("ConsentManagementSpi: data fetched and stored in auth notes.");
        context.success(); // Переход к следующему шагу (ConsentFormDisplaySpi)
    }

    // private <T> T makeHttpCall(String url, Class<T> responseType) { /* ... реализация ... */ return null;}
    // private <T, R> R makeHttpPostCall(String url, T requestBody, Class<R> responseType) { /* ... реализация ... */ return null;}
    // private String convertToJson(Object dto) { /* ... ObjectMapper().writeValueAsString(dto) ... */ return ""; }


    @Override
    public void action(AuthenticationFlowContext context) {
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}
