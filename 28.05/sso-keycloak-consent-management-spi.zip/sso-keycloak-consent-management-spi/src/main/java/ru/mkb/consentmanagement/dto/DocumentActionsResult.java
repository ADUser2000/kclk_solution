package ru.mkb.consentmanagement.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
class DocumentActionsResult {
    private List<DocumentAction> actions;
    // getters and setters
}
