package ru.mkb.consentmanagement.dto;

import java.util.List;

// DocumentActionsRequestDto.java (запрос к UserIdentifyData/GetDocumentsActions)
class DocumentActionsRequestDto {
    private String officialId;
    private String organizationId;
    private String documentType; // "ACCOUNTS_CONSENT"
    private List<DocumentInfo> documents;
    public DocumentActionsRequestDto(String officialId, String organizationId, String documentType, String documentId) { /* ... */ }
    // getters and setters
}
