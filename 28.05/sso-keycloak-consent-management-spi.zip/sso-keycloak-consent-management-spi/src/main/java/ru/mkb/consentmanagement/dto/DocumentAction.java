package ru.mkb.consentmanagement.dto;

// DocumentActionsResponseDto.java (ответ от UserIdentifyData/GetDocumentsActions)
class DocumentAction {
    private String documentId;
    private boolean canSign;
    // ... другие поля canRevokeSign, canSendAfterSign, etc.
    private String message;
    // getters and setters
}