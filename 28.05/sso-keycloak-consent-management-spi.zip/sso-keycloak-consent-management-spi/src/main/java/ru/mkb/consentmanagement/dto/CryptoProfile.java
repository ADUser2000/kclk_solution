package ru.mkb.consentmanagement.dto;

// CryptoProfilesDto.java (ответ от UserIdentifyData/GetActiveCryptoProfiles)
class CryptoProfile {
    private String id;
    private String name;
    // getters and setters
}