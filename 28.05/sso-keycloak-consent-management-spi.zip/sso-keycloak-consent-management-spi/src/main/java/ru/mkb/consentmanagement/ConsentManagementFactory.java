package ru.mkb.consentmanagement;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.consentmanagement.authenticator.ConsentManagementAuthenticator;

import java.util.Arrays;
import java.util.List;

public class ConsentManagementFactory implements AuthenticatorFactory {

    public static final String PROVIDER_ID = "consent-management-spi";
    private static final ConsentManagementAuthenticator SINGLETON = new ConsentManagementAuthenticator();

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getDisplayType() {
        return "Consent Data Management";
    }

    @Override
    public String getHelpText() {
        return "Fetches consent details and signing capabilities before displaying the consent form.";
    }

    @Override
    public String getReferenceCategory() {
        return "Consent";
    }

    @Override
    public boolean isConfigurable() {
        return true; // Да, нужны URL внешних сервисов
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES; // REQUIRED, ALTERNATIVE, DISABLED, CONDITIONAL
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        return Arrays.asList(
                new ProviderConfigProperty(ConsentManagementAuthenticator.CONFIG_CONSENTS_SERVICE_URL, "Consents Service URL",
                        "Base URL for the Consents BFF service (e.g., http://localhost:8081/api/consents).", ProviderConfigProperty.STRING_TYPE, null),
                new ProviderConfigProperty(ConsentManagementAuthenticator.CONFIG_USER_IDENTIFY_DATA_CRYPTO_URL, "UserIdentifyData Crypto Profiles URL",
                        "URL for UserIdentifyData service to get active crypto profiles (e.g., http://localhost:8082/api/useridentify/GetActiveCryptoProfiles).", ProviderConfigProperty.STRING_TYPE, null),
                new ProviderConfigProperty(ConsentManagementAuthenticator.CONFIG_USER_IDENTIFY_DATA_ACTIONS_URL, "UserIdentifyData Document Actions URL",
                        "URL for UserIdentifyData service to get document actions (e.g., http://localhost:8082/api/useridentify/GetDocumentsActions).", ProviderConfigProperty.STRING_TYPE, null)
        );
    }

    @Override
    public Authenticator create(KeycloakSession session) {
        return SINGLETON;
    }

    @Override
    public void init(Config.Scope config) {
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {
    }

    @Override
    public void close() {
    }
}