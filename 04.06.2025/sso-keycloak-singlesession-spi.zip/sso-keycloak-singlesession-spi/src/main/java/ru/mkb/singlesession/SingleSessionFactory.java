package ru.mkb.singlesession;

import org.keycloak.Config;
import org.keycloak.authentication.Authenticator;
import org.keycloak.authentication.AuthenticatorFactory;
import org.keycloak.models.AuthenticationExecutionModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.provider.ProviderConfigProperty;
import ru.mkb.singlesession.authenticator.SingleSessionAuthenticator;

import java.util.ArrayList;
import java.util.List;

public class SingleSessionFactory implements AuthenticatorFactory {

    public static final String PROVIDER_ID = "custom-single-session";
    public static final String REALM_SESSION_LIMIT = "realmSessionLimit";
    public static final String CLIENT_SESSION_LIMIT = "clientSessionLimit";

    private static final AuthenticationExecutionModel.Requirement[] REQUIREMENT_CHOICES = {
            AuthenticationExecutionModel.Requirement.REQUIRED,
            AuthenticationExecutionModel.Requirement.ALTERNATIVE,
            AuthenticationExecutionModel.Requirement.DISABLED,
            AuthenticationExecutionModel.Requirement.CONDITIONAL
    };

    @Override
    public String getId() {
        return PROVIDER_ID;
    }

    @Override
    public String getDisplayType() {
        return "SPI: custom-single-session";
    }

    @Override
    public String getHelpText() {
        return "SPI: custom-single-session";
    }

    @Override
    public Authenticator create(KeycloakSession session) {
        return new SingleSessionAuthenticator(session);
    }

    @Override
    public boolean isConfigurable() {
        return true;
    }

    @Override
    public AuthenticationExecutionModel.Requirement[] getRequirementChoices() {
        return REQUIREMENT_CHOICES;
    }

    @Override
    public boolean isUserSetupAllowed() {
        return false;
    }

    @Override
    public List<ProviderConfigProperty> getConfigProperties() {
        List<ProviderConfigProperty> configProperties = new ArrayList<>();

        ProviderConfigProperty realmLimit = new ProviderConfigProperty();
        realmLimit.setName(REALM_SESSION_LIMIT);
        realmLimit.setLabel("Maximum concurrent sessions for user in realm");
        realmLimit.setHelpText("Maximum number of concurrent sessions a user can have in this realm. Enter 0 or negative to disable realm limit. If exceeded, user will be prompted.");
        realmLimit.setType(ProviderConfigProperty.STRING_TYPE);
        realmLimit.setDefaultValue("1");
        configProperties.add(realmLimit);

        ProviderConfigProperty clientLimit = new ProviderConfigProperty();
        clientLimit.setName(CLIENT_SESSION_LIMIT);
        clientLimit.setLabel("Maximum concurrent sessions for user per client");
        clientLimit.setHelpText("Maximum number of concurrent sessions a user can have for a single client. Enter 0 or negative to disable client limit. If exceeded, user will be prompted.");
        clientLimit.setType(ProviderConfigProperty.STRING_TYPE);
        clientLimit.setDefaultValue("0");
        configProperties.add(clientLimit);

        return configProperties;
    }

    @Override
    public String getReferenceCategory() {
        return "sessionManagement";
    }

    @Override
    public void init(Config.Scope config) {
    }

    @Override
    public void postInit(KeycloakSessionFactory factory) {
    }

    @Override
    public void close() {
    }
}
