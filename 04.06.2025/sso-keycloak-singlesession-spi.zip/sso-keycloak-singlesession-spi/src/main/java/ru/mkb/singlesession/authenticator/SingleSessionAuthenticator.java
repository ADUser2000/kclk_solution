package ru.mkb.singlesession.authenticator;

import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.events.Details;
import org.keycloak.events.Errors;
import org.keycloak.models.AuthenticatorConfigModel;
import org.keycloak.models.ClientModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;
import org.keycloak.models.UserSessionModel;
import org.keycloak.services.managers.AuthenticationManager;
import org.keycloak.utils.StringUtil;
import ru.mkb.singlesession.SingleSessionFactory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SingleSessionAuthenticator implements Authenticator {
    private static final Logger logger = Logger.getLogger(SingleSessionAuthenticator.class);
    public static final String CHOICE_FORM = "session-choice.ftl";
    public static final String SESSION_CHOICE_PARAM = "session_choice";
    public static final String CHOICE_KEEP_OLD = "keep_old";
    public static final String CHOICE_START_NEW = "start_new";

    protected final KeycloakSession session;

    public SingleSessionAuthenticator(KeycloakSession session) {
        this.session = session;
    }

    private int getIntConfigProperty(String key, Map<String, String> config, int defaultValue) {
        String value = config.get(key);
        if (StringUtil.isBlank(value)) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            logger.warnf("Failed to parse configuration property '%s' value '%s' as integer. Using default %d.", key, value, defaultValue);
            return defaultValue;
        }
    }

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        UserModel user = context.getUser();
        RealmModel realm = context.getRealm();
        ClientModel currentClient = context.getAuthenticationSession().getClient();


        if (user == null) {
            context.success();
            return;
        }

        AuthenticatorConfigModel authenticatorConfig = context.getAuthenticatorConfig();
        Map<String, String> config = null;
        if (authenticatorConfig != null && authenticatorConfig.getConfig() != null) {
            config = authenticatorConfig.getConfig();
        } else {
            logger.warn("No configuration found for Interactive Single Session Control. Using default behavior (prompt if >0 sessions).");
        }

        int realmSessionLimit = 1;
        int clientSessionLimit = 0;

        if (config != null) {
            realmSessionLimit = getIntConfigProperty(SingleSessionFactory.REALM_SESSION_LIMIT, config, 1);
            clientSessionLimit = getIntConfigProperty(SingleSessionFactory.CLIENT_SESSION_LIMIT, config, 0);
        }

        logger.debugf("Configured limits for user %s: RealmLimit=%d, ClientLimit=%d", user.getUsername(), realmSessionLimit, clientSessionLimit);

        AuthenticationManager.AuthResult authResult = AuthenticationManager.authenticateIdentityCookie(context.getSession(), realm, true);
        final boolean isNewUserSessionAttempt = authResult == null || authResult.getSession() == null;
        final boolean isNewClientSessionAttempt = isNewUserSessionAttempt ||
                (authResult != null && authResult.getSession() != null &&
                        authResult.getSession().getAuthenticatedClientSessionByClient(currentClient.getId()) == null);


        List<UserSessionModel> userSessionsInRealm = session.sessions()
                .getUserSessionsStream(realm, user)
                .collect(Collectors.toList());
        int currentRealmSessionsCount = userSessionsInRealm.size();

        List<UserSessionModel> userSessionsForCurrentClient = userSessionsInRealm.stream()
                .filter(s -> s.getAuthenticatedClientSessionByClient(currentClient.getId()) != null)
                .collect(Collectors.toList());
        int currentClientSessionsCount = userSessionsForCurrentClient.size();

        logger.debugf("User '%s' current sessions: RealmCount=%d, ClientCount=%d (for client %s). NewUserSessionAttempt: %s, NewClientSessionAttempt: %s",
                user.getUsername(), currentRealmSessionsCount, currentClientSessionsCount, currentClient.getClientId(), isNewUserSessionAttempt, isNewClientSessionAttempt);

        boolean showChoiceForm = false;

        if (realmSessionLimit > 0 && isNewUserSessionAttempt && currentRealmSessionsCount >= realmSessionLimit) {
            logger.infof("User '%s' meets/exceeds realm session limit (%d/%d). Presenting choice.",
                    user.getUsername(), currentRealmSessionsCount, realmSessionLimit);
            showChoiceForm = true;
        }

        if (!showChoiceForm && clientSessionLimit > 0 && isNewClientSessionAttempt && currentClientSessionsCount >= clientSessionLimit) {
            logger.infof("User '%s' meets/exceeds client session limit (%d/%d) for client '%s'. Presenting choice.",
                    user.getUsername(), currentClientSessionsCount, clientSessionLimit, currentClient.getClientId());
            showChoiceForm = true;
        }


        if (showChoiceForm) {
            context.getEvent().user(user)
                    .detail(Details.USERNAME, user.getUsername())
                    .detail("existing_sessions_realm_count", String.valueOf(currentRealmSessionsCount))
                    .detail("existing_sessions_client_count", String.valueOf(currentClientSessionsCount))
                    .detail("configured_realm_limit", String.valueOf(realmSessionLimit))
                    .detail("configured_client_limit", String.valueOf(clientSessionLimit));

            Response challenge = context.form()
                    .setAttribute("currentRealmSessionsCount", currentRealmSessionsCount)
                    .setAttribute("currentClientSessionsCount", currentClientSessionsCount)
                    .createForm(CHOICE_FORM);
            context.challenge(challenge);
        } else {
            context.success();
        }
    }

    @Override
    public void action(AuthenticationFlowContext context) {
        MultivaluedMap<String, String> formData = context.getHttpRequest().getDecodedFormParameters();
        String choice = formData.getFirst(SESSION_CHOICE_PARAM);
        UserModel user = context.getUser();
        RealmModel realm = context.getRealm();

        if (user == null) {
            context.failure(AuthenticationFlowError.INVALID_USER,
                    context.form().setError("User not found during session choice action.").createErrorPage(Response.Status.BAD_REQUEST));
            return;
        }

        if (CHOICE_KEEP_OLD.equals(choice)) {
            logger.infof("User '%s' chose to keep old session(s). Aborting current login.", user.getUsername());
            context.getEvent().user(user)
                    .detail(Details.USERNAME, user.getUsername())
                    .detail("action_taken", CHOICE_KEEP_OLD)
                    .success();
            context.resetFlow();

        } else if (CHOICE_START_NEW.equals(choice)) {
            logger.infof("User '%s' chose to start a new session. Terminating all old session(s) in realm '%s'.",
                    user.getUsername(), realm.getName());

            List<UserSessionModel> sessionsToTerminate = session.sessions()
                    .getUserSessionsStream(realm, user)
                    .toList();
            int terminatedCount = sessionsToTerminate.size();

            if (!sessionsToTerminate.isEmpty()) {
                logger.debugf("Terminating %d old session(s) for user '%s' in realm '%s'.",
                        terminatedCount, user.getUsername(), realm.getName());
                for (UserSessionModel userSession : sessionsToTerminate) {
                    logger.tracef("Terminating user session: ID=%s, ClientIP=%s, Started=%s, LastRefresh=%s, Clients=[%s]",
                            userSession.getId(),
                            userSession.getIpAddress(),
                            new java.util.Date(userSession.getStarted() * 1000L),
                            new java.util.Date(userSession.getLastSessionRefresh() * 1000L),
                            userSession.getAuthenticatedClientSessions().keySet().stream().map(clientId -> realm.getClientById(clientId).getClientId()).collect(Collectors.joining(", ")));
                    AuthenticationManager.backchannelLogout(session, realm, userSession, context.getUriInfo(), context.getConnection(), context.getHttpRequest().getHttpHeaders(), true);
                }
            }
            context.getEvent().user(user)
                    .detail(Details.USERNAME, user.getUsername())
                    .detail("action_taken", CHOICE_START_NEW)
                    .detail("terminated_sessions_count", String.valueOf(terminatedCount))
                    .success();
            context.success();
        } else {
            logger.warnf("Invalid choice '%s' received from user '%s'. Showing choice form again.", choice, user.getUsername());
            context.getEvent().user(user).error(Errors.INVALID_INPUT);

            Response challenge = context.form()
                    .setError("invalidSessionChoice")
                    .createForm(CHOICE_FORM);
            context.challenge(challenge);
        }
    }

    @Override
    public boolean requiresUser() {
        return true;
    }

    @Override
    public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
        return true;
    }

    @Override
    public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
    }

    @Override
    public void close() {
    }
}
